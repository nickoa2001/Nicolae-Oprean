﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormTreatments : Form
    {
        int treatments_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormTreatments()
        {
            InitializeComponent();
        }

        private void FormTreatments_Load(object sender, EventArgs e)
        {
            this.comboviewDataTabletaxesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletaxes);
            this.comboviewDataTabletreatmentscategoriesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletreatmentscategories);
            this.comboviewDataTabletaxesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletaxes);
            this.comboviewDataTabletreatmentscategoriesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletreatmentscategories);

            this.viewDataTabletreatmentsTableAdapter.Fill(this.dataSet01V.viewDataTabletreatments);

            viewDataTabletreatmentsBindingSource.Sort = "treatments_name";

            comboBox_filter_treatmentscategories_id.Items.Clear();
            comboBox_filter_treatmentscategories_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletreatmentscategoriesRow r in dataSet01V.comboviewDataTabletreatmentscategories.Select("", "treatmentscategories_name"))
            {
                comboBox_filter_treatmentscategories_id.Items.Add(new CLItemA(r.treatmentscategories_id.ToString(), r.treatmentscategories_name.ToString()));
            }
            comboBox_filter_treatmentscategories_id.SelectedIndex = 0;

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTabletreatmentsBindingSource_CurrentChanged(null, null);
        }

        private void FormTreatments_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormTreatments_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormTreatments_Load(sender, e);
        }

        private void FormTreatments_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                treatments_nameTextBox.ReadOnly = false;
                treatments_codeTextBox.ReadOnly = false;
                treatments_priceTextBox.ReadOnly = false;
                treatments_descTextBox.ReadOnly = false;
                treatments_durationTextBox.ReadOnly = false;
                treatmentscategories_idComboBox.Enabled = true;
                taxes_idComboBox.Enabled = true;
                button_notax.Enabled = true;

                dataGridView_main.Enabled = false;

                panel_filter.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                treatments_nameTextBox.ReadOnly = true;
                treatments_codeTextBox.ReadOnly = true;
                treatments_priceTextBox.ReadOnly = true;
                treatments_descTextBox.ReadOnly = true;
                treatments_durationTextBox.ReadOnly = true;
                treatmentscategories_idComboBox.Enabled = false;
                taxes_idComboBox.Enabled = false;
                button_notax.Enabled = false;

                dataGridView_main.Enabled = true;

                panel_filter.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            treatmentsBindingSource.AddNew();

            if(comboBox_filter_treatmentscategories_id.SelectedIndex != -1 && comboBox_filter_treatmentscategories_id.SelectedIndex != 0)
                treatmentscategories_idComboBox.SelectedValue = Convert.ToInt32(((CLItemA)comboBox_filter_treatmentscategories_id.SelectedItem).id);
            treatments_priceTextBox.Text = "0";
            treatments_durationTextBox.Text = "0";
            taxes_idComboBox.SelectedIndex = -1;
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (treatments_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);

                if (((DataRowView)treatmentsBindingSource.Current).Row["treatments_duration"].ToString().CompareTo(string.Empty) == 0)
                    treatments_durationTextBox.Text = "0";
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (treatments_id != -1 && treatments_id != 1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    treatmentsBindingSource.RemoveCurrent();
                    treatmentsTableAdapter.Update(dataSet01S.treatments);
                    dataSet01S.treatments.AcceptChanges();

                    viewDataTabletreatmentsTableAdapter.Fill(dataSet01V.viewDataTabletreatments);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (treatments_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            if (treatments_codeTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid code" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.treatmentsTableAdapter t = new DataSet01STableAdapters.treatmentsTableAdapter();
                if (t.GetDataBy1(treatments_codeTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "code already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1(treatments_codeTextBox.Text).Select("treatments_id <> " + treatments_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "code already exists" + Environment.NewLine;
                }
            }
            if (treatments_descTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid desc" + Environment.NewLine;
            }
            if (treatmentscategories_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a category" + Environment.NewLine;
            }
            if (treatments_priceTextBox.Text.CompareTo(string.Empty) == 0)
            {
                try
                {
                    decimal d = Convert.ToDecimal(treatments_priceTextBox.Text);
                    if (d < 0)
                    {
                        valid_b = false;
                        valid_s += "invalid price" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid price" + Environment.NewLine;
                }
            }
            if (treatments_durationTextBox.Text.CompareTo(string.Empty) != 0)
            {
                try
                {
                    int i = Convert.ToInt16(treatments_durationTextBox.Text);
                    if (i < 0 || i > 48)
                    {
                        valid_b = false;
                        valid_s += "invalid duration" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid duration" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }

            if(treatments_durationTextBox.Text.CompareTo(string.Empty) != 0)
                if (Convert.ToInt16(treatments_durationTextBox.Text) == 0)
                    ((DataRowView)treatmentsBindingSource.Current).Row["treatments_duration"] = DBNull.Value;

            treatmentsBindingSource.EndEdit();
            treatmentsTableAdapter.Update(dataSet01S.treatments);
            dataSet01S.treatments.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = treatmentsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = treatments_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTabletreatmentsTableAdapter.Fill(dataSet01V.viewDataTabletreatments);
            viewDataTabletreatmentsBindingSource.Position = viewDataTabletreatmentsBindingSource.Find("treatments_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            treatmentsBindingSource.CancelEdit();
            dataSet01S.families.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTabletreatmentsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            treatments_id = -1;

            treatmentsBindingSource.Filter = "treatments_id = -1";

            try
            {
                treatments_id = (int)((DataSet01V.viewDataTabletreatmentsRow)((DataRowView)viewDataTabletreatmentsBindingSource.Current).Row).treatments_id;
            }
            catch { }

            treatmentscategories_idComboBox.SelectedIndex = -1;
            taxes_idComboBox.SelectedIndex = -1;

            if (treatments_id != -1)
            {
                treatmentsTableAdapter.Fill(dataSet01S.treatments, treatments_id);

                treatmentsBindingSource.RemoveFilter();
                treatmentsBindingSource.Position = treatmentsBindingSource.Find("treatments_id", treatments_id);
            }
        }

        private void setFilter()
        {
            try
            {
                string filter_s = string.Empty;
                if (textBox_filter_treatments_code.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "treatments_code LIKE '%" + textBox_filter_treatments_code.Text + "%'";
                }
                if (textBox_filter_treatments_name.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "treatments_name LIKE '%" + textBox_filter_treatments_name.Text + "%'";
                }
                if (comboBox_filter_treatmentscategories_id.SelectedIndex != -1 && comboBox_filter_treatmentscategories_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "treatmentscategories_id = '" + Convert.ToInt32(((CLItemA)comboBox_filter_treatmentscategories_id.SelectedItem).id) + "'";
                }

                viewDataTabletreatmentsBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void textBox_filter_treatments_TextChanged(object sender, EventArgs e)
        {
            setFilter();
        }

        private void comboBox_filter_treatmentscategories_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            setFilter();
        }

        private void textBox_filter_treatments_name_TextChanged(object sender, EventArgs e)
        {
            setFilter();
        }

        private void button_notax_Click(object sender, EventArgs e)
        {
            taxes_idComboBox.SelectedIndex = -1;
        }

        private void treatments_durationTextBox_Leave(object sender, EventArgs e)
        {
            if (!treatments_durationTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToInt16(treatments_durationTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric integer value");
                }
            }

        }

        private void treatments_priceTextBox_Leave(object sender, EventArgs e)
        {
            if (!treatments_priceTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(treatments_priceTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }
    }
}
