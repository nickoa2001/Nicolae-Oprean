﻿//VERSION 1.0.0.1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace vettev
{
    class CLOptions
    {
        public CLOptions()
        {
        }

        public static string ReadValue(string name)
        {
            string value = "";
            value = ConfigurationManager.AppSettings[name];
            return value;
        }

        public static void WriteValue(string name, string value)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            string t = config.AppSettings.Settings[name].Value;
            config.AppSettings.Settings[name].Value = value;
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");
        }
    }
}
