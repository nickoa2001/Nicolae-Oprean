﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace vettev
{
    public partial class FormFamilies : Form
    {
        int families_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormFamilies()
        {
            InitializeComponent();
        }

        private void FormFamilies_Load(object sender, EventArgs e)
        {
            this.viewDataTablefamiliesTableAdapter.Fill(this.dataSet01V.viewDataTablefamilies);

            viewDataTablefamiliesBindingSource.Sort = "families_name";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTablefamiliesBindingSource_CurrentChanged(null, null);
        }

        private void FormFamilies_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormFamilies_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormFamilies_Load(sender, e);
        }

        private void FormFamilies_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                families_nameTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                families_nameTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            familiesBindingSource.AddNew();
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (families_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (families_id != -1 && families_id != 1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    {
                        DataSet01STableAdapters.breedsTableAdapter t = new DataSet01STableAdapters.breedsTableAdapter();
                        foreach (DataSet01S.breedsRow r in t.GetDataBy(families_id).Select())
                        {
                            r.families_id = 1;
                            t.Update(r);
                        }
                    }

                    familiesBindingSource.RemoveCurrent();
                    familiesTableAdapter.Update(dataSet01S.families);
                    dataSet01S.families.AcceptChanges();

                    viewDataTablefamiliesTableAdapter.Fill(dataSet01V.viewDataTablefamilies);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (families_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.familiesTableAdapter t = new DataSet01STableAdapters.familiesTableAdapter();
                if (t.GetDataBy1(families_nameTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1(families_nameTextBox.Text).Select("families_id <> " + families_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            familiesBindingSource.EndEdit();
            familiesTableAdapter.Update(dataSet01S.families);
            dataSet01S.families.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = familiesTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = families_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTablefamiliesTableAdapter.Fill(dataSet01V.viewDataTablefamilies);
            viewDataTablefamiliesBindingSource.Position = viewDataTablefamiliesBindingSource.Find("families_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            familiesBindingSource.CancelEdit();
            dataSet01S.families.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTablefamiliesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            families_id = -1;

            familiesBindingSource.Filter = "families_id = -1";

            try
            {
                families_id = (int)((DataSet01V.viewDataTablefamiliesRow)((DataRowView)viewDataTablefamiliesBindingSource.Current).Row).families_id;
            }
            catch { }

            if (families_id != -1)
            {
                familiesTableAdapter.Fill(dataSet01S.families, families_id);

                familiesBindingSource.RemoveFilter();
                familiesBindingSource.Position = familiesBindingSource.Find("families_id", families_id);
            }
        }
    }
}
