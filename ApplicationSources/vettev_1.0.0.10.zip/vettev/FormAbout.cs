﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormAbout : Form
    {
        public FormAbout()
        {
            InitializeComponent();
        }

        private void FormAbout_Load(object sender, EventArgs e)
        {
            string info_s =
    "----------------------------------------------------------------------------" + Environment.NewLine +
    "vettev" + Environment.NewLine +
    "----------------------------------------------------------------------------" + Environment.NewLine +
    "version: " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString() + Environment.NewLine +
    "----------------------------------------------------------------------------" + Environment.NewLine +
    "copyright (c) Davide Gironi" + Environment.NewLine +
    "http://code.google.com/p/vettev" + Environment.NewLine +
    "----------------------------------------------------------------------------" + Environment.NewLine +
    "By loading or using the Software, you agree to the terms of the License provided." + Environment.NewLine +
    "----------------------------------------------------------------------------";

            textBox_Info.Text = info_s;
            button_Ok.Select();
        }

        private void button_Ok_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
