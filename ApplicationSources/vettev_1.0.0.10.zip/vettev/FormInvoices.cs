﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Resources;
using System.Diagnostics;

namespace vettev
{
    public partial class FormInvoices : Form
    {
        int invoices_id = -1;
        int invoicespayments_id = -1;
        int invoicesitems_id = -1;
        int animalstreatments_id = -1;

        private static int IS_ACTION = 0;
        private static int IS_ACTIONSUB = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormInvoices()
        {
            InitializeComponent();
        }

        private void FormInvoices_Load(object sender, EventArgs e)
        {
            this.comboviewDataTablecomputedrowsdocsTableAdapter.Fill(this.dataSet01V.comboviewDataTablecomputedrowsdocs);
            this.comboviewDataTabletaxesdeductionTableAdapter.Fill(this.dataSet01V.comboviewDataTabletaxesdeduction);
            this.comboviewDataTablefootersdocsTableAdapter.Fill(this.dataSet01V.comboviewDataTablefootersdocs);
            this.comboviewDataTabletreatmentscategoriesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletreatmentscategories);
            this.comboviewDataTabletreatmentsTableAdapter.Fill(this.dataSet01V.comboviewDataTabletreatments);
            this.comboviewDataTabletaxesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletaxes);
            this.comboviewDataTableusersTableAdapter.Fill(this.dataSet01V.comboviewDataTableusers);
            this.comboviewDataTablepaymentsTableAdapter.Fill(this.dataSet01V.comboviewDataTablepayments);
            this.comboviewDataTablepaystatusTableAdapter.Fill(this.dataSet01V.comboviewDataTablepaystatus);
            this.comboviewDataTablecustomersTableAdapter.Fill(this.dataSet01V.comboviewDataTablecustomers);

            viewDataTableinvoicesBindingSource.Sort = "invoices_date DESC";

            subviewDataTableinvoicesitemsBindingSource.Sort = "invoicesitems_id";
            subviewDataTableinvoicespaymentsBindingSource.Sort = "invoicespayments_date DESC";
            subviewDataTableinvoicestreatmentsBindingSource.Sort = "animalstreatments_date DESC";
            comboviewDataTabletreatmentsBindingSource.Sort = "treatments_name";
            comboviewDataTableanimalstreatmentsinvoiceableBindingSource.Sort = "animalstreatments_date DESC";
            
            comboBox_filter_users_id.Items.Clear();
            comboBox_filter_users_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTableusersRow r in dataSet01V.comboviewDataTableusers.Select("", "users_alias"))
            {
                comboBox_filter_users_id.Items.Add(new CLItemA(r.users_id.ToString(), r.users_alias.ToString()));
            }
            if(comboBox_filter_users_id.Items.Count == 2)
                comboBox_filter_users_id.SelectedIndex = 1;
            else
                comboBox_filter_users_id.SelectedIndex = 0;

            comboBox_taxesdeduction.Items.Clear();
            comboBox_taxesdeduction.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletaxesdeductionRow r in dataSet01V.comboviewDataTabletaxesdeduction.Select("", "taxesdeduction_name"))
            {
                comboBox_taxesdeduction.Items.Add(new CLItemA(r.taxesdeduction_id.ToString(), r.taxesdeduction_name.ToString()));
            }
            comboBox_taxesdeduction.SelectedIndex = 0;

            comboBox_fillfrompayments.Items.Clear();
            comboBox_fillfrompayments.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablepaymentsRow r in dataSet01V.comboviewDataTablepayments.Select("", "payments_name"))
            {
                comboBox_fillfrompayments.Items.Add(new CLItemA(r.payments_id.ToString(), r.payments_name.ToString()));
            }
            comboBox_fillfrompayments.SelectedIndex = 0;

            comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.Items.Clear();
            comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletreatmentscategoriesRow r in dataSet01V.comboviewDataTabletreatmentscategories.Select("", "treatmentscategories_name"))
            {
                comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.Items.Add(new CLItemA(r.treatmentscategories_id.ToString(), r.treatmentscategories_name.ToString()));
            }
            comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex = 0;

            comboBox_fillfrompayments.Items.Clear();
            comboBox_fillfrompayments.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablepaymentsRow r in dataSet01V.comboviewDataTablepayments.Select("", "payments_name"))
            {
                comboBox_fillfrompayments.Items.Add(new CLItemA(r.payments_id.ToString(), r.payments_name.ToString()));
            }
            comboBox_fillfrompayments.SelectedIndex = 0;

            comboBox_fillfromfootersdocs.Items.Clear();
            comboBox_fillfromfootersdocs.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablefootersdocsRow r in dataSet01V.comboviewDataTablefootersdocs.Select("", "footersdocs_desc"))
            {
                comboBox_fillfromfootersdocs.Items.Add(new CLItemA(r.footersdocs_id.ToString(), (r.footersdocs_desc.ToString().Length > 100 ? r.footersdocs_desc.ToString().Substring(0, 100) : r.footersdocs_desc.ToString())));
            }
            comboBox_fillfromfootersdocs.SelectedIndex = 0;

            comboBox_invoicesitemstaxes.Items.Clear();
            comboBox_invoicesitemstaxes.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletaxesRow r in dataSet01V.comboviewDataTabletaxes.Select("", "taxes_name"))
            {
                comboBox_invoicesitemstaxes.Items.Add(new CLItemA(r.taxes_id.ToString(), r.taxes_name.ToString()));
            }
            comboBox_invoicesitemstaxes.SelectedIndex = 0;

            comboBox_invoicesitemscomputedrowsdocs.Items.Clear();
            comboBox_invoicesitemscomputedrowsdocs.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablecomputedrowsdocsRow r in dataSet01V.comboviewDataTablecomputedrowsdocs.Select("", "computedrowsdocs_name"))
            {
                comboBox_invoicesitemscomputedrowsdocs.Items.Add(new CLItemA(r.computedrowsdocs_id.ToString(), r.computedrowsdocs_name.ToString()));
            }
            comboBox_invoicesitemscomputedrowsdocs.SelectedIndex = 0;

            DateTime datemin = DateTime.Now;
            if(invoicesTableAdapter.ScalarQuery2() != null)
                datemin = invoicesTableAdapter.ScalarQuery2().Value;
            int yearmin = datemin.Year;
            DateTime datemax = DateTime.Now;
            if(invoicesTableAdapter.ScalarQuery3() != null)
                datemax = invoicesTableAdapter.ScalarQuery3().Value;
            int yearmax = datemax.Year;
            if (datemax.Year < DateTime.Now.Year)
                yearmax = DateTime.Now.Year;
            comboBox_filter_year.Items.Clear();
            comboBox_filter_year.Items.Add(new CLItemA("0", ""));
            for (int i = yearmin; i <= yearmax; i++)
            {
                comboBox_filter_year.Items.Add(i.ToString());
            }
            comboBox_filter_year.SelectedIndex = comboBox_filter_year.Items.Count-1;
            
            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            tabControl_main.SelectedIndex = 0;

            loading = 0;
            reload_invoices();
        }

        private void FormInvoices_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormInvoices_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormInvoices_Load(sender, e);
        }

        private void FormInvoices_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (IS_ACTION == IS_EDIT)
            {
                setEditingMode_invoicesitems(false, true);
                setEditingMode_invoicespayments(false, true);
                setEditingMode_invoicestreatments(false, true);
            }
            else
            {
                setEditingMode_invoicesitems(false, false);
                setEditingMode_invoicespayments(false, false);
                setEditingMode_invoicestreatments(false, false);
            }

            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;
                button_Print.Enabled = false;

                if (tabControl_main.SelectedTab == tabPage1)
                {
                    button_Save.Enabled = true;
                    button_Undo.Enabled = true;
                    button_Stopedit.Enabled = false;
                }
                else
                {
                    button_Save.Enabled = false;
                    button_Undo.Enabled = false;
                    button_Stopedit.Enabled = true;
                }

                invoices_numberTextBox.ReadOnly = false;
                invoices_paymentstextTextBox.ReadOnly = false;
                invoices_customerstextTextBox.ReadOnly = false;
                invoices_userstextTextBox.ReadOnly = false;
                invoices_footerstextTextBox.ReadOnly = false;
                invoices_dateDateTimePicker.Enabled = true;
                invoices_deductiontaxTextBox.ReadOnly = false;
                paystatus_idComboBox.Enabled = true;
                customers_idComboBox.Enabled = true;
                comboBox_fillfrompayments.Enabled = true;
                comboBox_fillfromfootersdocs.Enabled = true;
                comboBox_taxesdeduction.Enabled = true;
                button_fillfrompayments.Enabled = true;
                button_fillfromcustomers.Enabled = true;
                button_fillfromusers.Enabled = true;
                button_fillfromfootersdocs.Enabled = true;

                dataGridView_main.Enabled = false;

                panel_filter.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;
                button_Print.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = false;

                invoices_numberTextBox.ReadOnly = true;
                invoices_paymentstextTextBox.ReadOnly = true;
                invoices_customerstextTextBox.ReadOnly = true;
                invoices_userstextTextBox.ReadOnly = true;
                invoices_footerstextTextBox.ReadOnly = true;
                invoices_dateDateTimePicker.Enabled = false;
                invoices_deductiontaxTextBox.ReadOnly = true;
                paystatus_idComboBox.Enabled = false;
                customers_idComboBox.Enabled = false;
                comboBox_fillfrompayments.Enabled = false;
                comboBox_fillfromfootersdocs.Enabled = false;
                comboBox_taxesdeduction.Enabled = false;
                button_fillfrompayments.Enabled = false;
                button_fillfromcustomers.Enabled = false;
                button_fillfromusers.Enabled = false;
                button_fillfromfootersdocs.Enabled = false;

                dataGridView_main.Enabled = true;

                panel_filter.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = false;
            tabPage1.Enabled = true;
            tabControl_main.SelectedIndex = 0;

            IS_ACTION = IS_NEW;
            setEditingMode(true);

            invoicesBindingSource.AddNew();

            DateTime datefrom = new DateTime(Convert.ToInt32(comboBox_filter_year.SelectedItem), 1, 1, 0, 0, 0);
            DateTime dateto = new DateTime(Convert.ToInt32(comboBox_filter_year.SelectedItem), 1, 1, 0, 0, 0).AddYears(1).AddTicks(-1);
            int invoices_number = 1;
            try
            {
                invoices_number = Convert.ToInt32(invoicesTableAdapter.ScalarQuery1(datefrom, dateto, (Convert.ToInt32(((CLItemA)comboBox_filter_users_id.SelectedItem).id))));
                invoices_number++;
            }
            catch { }
            invoices_numberTextBox.Text = invoices_number.ToString();

            invoices_deductiontaxTextBox.Text = "0";
            DataSet01STableAdapters.taxesdeductionTableAdapter t = new DataSet01STableAdapters.taxesdeductionTableAdapter();
            if (t.GetDataBy2().First()["taxesdeduction_id"].ToString().CompareTo(string.Empty) != 0)
            {
                if (t.GetDataBy2().First().taxesdeduction_default == 1)
                {
                    foreach (CLItemA item in comboBox_taxesdeduction.Items)
                    {
                        if (Convert.ToInt32(item.id) == t.GetDataBy2().First().taxesdeduction_id)
                        {
                            comboBox_taxesdeduction.SelectedItem = item;
                            break;
                        }
                    }
                }
            }

            customers_idComboBox.SelectedIndex = -1;
            
            if (comboBox_filter_users_id.SelectedIndex != -1)
                users_idComboBox.SelectedValue = Convert.ToInt32(((CLItemA)comboBox_filter_users_id.SelectedItem).id);

            invoices_dateDateTimePicker.Value = DateTime.Now;
            invoices_totalTextBox.Text = "0";
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (invoices_id != -1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                { 
                    if(tabControl_main.SelectedTab == tp)
                        tp.Enabled = true;
                    else
                        tp.Enabled = false;
                }
                
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (invoices_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    {
                        DataSet01STableAdapters.animalstreatmentsTableAdapter t = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                        foreach (DataSet01S.animalstreatmentsRow r in t.GetDataBy1(invoices_id).Select())
                        {
                            r["invoices_id"] = DBNull.Value;
                            t.Update(r);
                        }
                    }

                    {
                        DataSet01STableAdapters.invoicesitemsTableAdapter t = new DataSet01STableAdapters.invoicesitemsTableAdapter();
                        DataSet01S.invoicesitemsDataTable d = t.GetDataBy1(invoices_id);
                        foreach (DataSet01S.invoicesitemsRow r in d.Select())
                        {
                            r.Delete();
                        }
                        t.Update(d);
                    }

                    {
                        DataSet01STableAdapters.invoicespaymentsTableAdapter t = new DataSet01STableAdapters.invoicespaymentsTableAdapter();
                        DataSet01S.invoicespaymentsDataTable d = t.GetDataBy1(invoices_id);
                        foreach (DataSet01S.invoicespaymentsRow r in d.Select())
                        {
                            r.Delete();
                        }
                        t.Update(d);
                    }

                    invoicesBindingSource.RemoveCurrent();
                    invoicesTableAdapter.Update(dataSet01S.invoices);
                    dataSet01S.animals.AcceptChanges();

                    reload_invoices();
                }
            }
        }

        private void button_Print_Click(object sender, EventArgs e)
        {
            if (invoices_id != -1)
            {
                print_invoices(invoices_id);
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (users_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a user" + Environment.NewLine;
                return valid_b;
            }
            if (invoices_numberTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid number" + Environment.NewLine;
            }
            else
            {
                try
                {
                    int invoices_number = Convert.ToInt32(invoices_numberTextBox.Text);
                    DateTime datefrom = new DateTime(invoices_dateDateTimePicker.Value.Year, 1, 1, 0, 0, 0);
                    DateTime dateto = new DateTime(invoices_dateDateTimePicker.Value.Year, 1, 1, 0, 0, 0).AddYears(1).AddTicks(-1);
                    DataSet01STableAdapters.invoicesTableAdapter t = new DataSet01STableAdapters.invoicesTableAdapter();
                    if (t.GetDataBy4(invoices_number, Convert.ToInt32(users_idComboBox.SelectedValue), datefrom, dateto).Select().Count() > 0 && IS_ACTION == IS_NEW)
                    {
                        valid_b = false;
                        valid_s += "invoice number already exists" + Environment.NewLine;
                    }
                    if (t.GetDataBy4(invoices_number, Convert.ToInt32(users_idComboBox.SelectedValue), datefrom, dateto).Select("invoices_id <> " + invoices_id).Count() > 0 && IS_ACTION == IS_EDIT)
                    {
                        valid_b = false;
                        valid_s += "invoice number already exists" + Environment.NewLine;
                    }
                    if (invoices_number <= 0)
                    {
                        valid_b = false;
                        valid_s += "invalid number" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid number" + Environment.NewLine;
                }
            }
            if (invoices_deductiontaxTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid deduction tax" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(invoices_deductiontaxTextBox.Text);
                    if (d < 0 || d > 100)
                    {
                        valid_b = false;
                        valid_s += "invalid deduction tax" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid deduction tax" + Environment.NewLine;
                }
            }
            if (paystatus_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a payment status" + Environment.NewLine;
            }
            if (customers_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a customer" + Environment.NewLine;
            }
            if (invoices_userstextTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid user description" + Environment.NewLine;
            }
            if (invoices_customerstextTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid user description" + Environment.NewLine;
            }
            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            if (tabControl_main.SelectedTab == tabPage1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;

                string valid_s = string.Empty;
                if (!validateUpdate(ref valid_s))
                {
                    MessageBox.Show(valid_s);
                    return;
                }

                invoicesBindingSource.EndEdit();
                invoicesTableAdapter.Update(dataSet01S.invoices);
                dataSet01S.invoices.AcceptChanges();

                int sel_id = -1;
                switch (IS_ACTION)
                {
                    case IS_NEW:
                        sel_id = invoicesTableAdapter.ScalarQuery().Value;
                        break;
                    case IS_EDIT:
                        sel_id = invoices_id;
                        break;
                }

                IS_ACTION = IS_VIEW;
                setEditingMode(false);

                decimal totalnotax = 0;
                decimal totaltax = 0;
                decimal totaldeductiontax = 0;
                decimal total = 0;
                calculate_total(invoices_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
                textBox_invoicesitemstotalnotax.Text = totalnotax.ToString();
                textBox_invoicesitemstotaltax.Text = totaltax.ToString();
                textBox_invoicesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                textBox_invoicesitemstotal.Text = total.ToString();

                DataSet01STableAdapters.invoicesTableAdapter ttttt = new DataSet01STableAdapters.invoicesTableAdapter();
                DataSet01S.invoicesRow rrrrr = ttttt.GetData(invoices_id).First();
                rrrrr.invoices_total = total;
                ttttt.Update(rrrrr);

                reload_invoices();
                viewDataTableinvoicesBindingSource.Position = viewDataTableinvoicesBindingSource.Find("invoices_id", sel_id);
            }
            else if (tabControl_main.SelectedTab == tabPage2)
            {
                invoicesitems_Save();
            }
            else if (tabControl_main.SelectedTab == tabPage3)
            {
                invoicespayments_Save();
            }
            else if (tabControl_main.SelectedTab == tabPage4)
            {
                invoicestreatments_Save();
            }
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            if (tabControl_main.SelectedTab == tabPage1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;

                invoicesBindingSource.CancelEdit();
                dataSet01S.invoices.RejectChanges();
                
                reload_invoices();
                viewDataTableinvoicesBindingSource.Position = viewDataTableinvoicesBindingSource.Find("invoices_id", invoices_id);

                IS_ACTION = IS_VIEW;
                setEditingMode(false);

                comboBox_taxesdeduction.SelectedIndex = -1;
                comboBox_fillfrompayments.SelectedIndex = -1;
                comboBox_fillfromfootersdocs.SelectedIndex = -1;
            }
            else if (tabControl_main.SelectedTab == tabPage2)
            {
                invoicesitems_Undo();
            }
            else if (tabControl_main.SelectedTab == tabPage3)
            {
                invoicespayments_Undo();
            }
            else if (tabControl_main.SelectedTab == tabPage4)
            {
                invoicestreatments_Undo();
            }
        }

        private void button_Stopedit_Click(object sender, EventArgs e)
        {
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = true;

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            if (tabControl_main.SelectedTab == tabPage2)
            {
                int sel_id = invoices_id;
                reload_invoices();
                viewDataTableinvoicesBindingSource.Position = viewDataTableinvoicesBindingSource.Find("invoices_id", sel_id);
            }
        }

        #region pdf

        private void print_invoices(int invoices_id)
        {
            //delete old temp
            string tmplocation = "tmp";
            if (!Directory.Exists(tmplocation))
            {
                Directory.CreateDirectory(tmplocation);
            }
            DirectoryInfo di = new DirectoryInfo(tmplocation);
            FileInfo[] fis = di.GetFiles("*.*");
            foreach (FileInfo fi in fis)
            {
                try
                {
                    if (fi.LastWriteTime < DateTime.Now.AddDays(-1))
                        fi.Delete();
                }
                catch { }
            }
            
            DataSet01STableAdapters.invoicesTableAdapter t = new DataSet01STableAdapters.invoicesTableAdapter();
            DataSet01S.invoicesRow r = t.GetData(invoices_id).First();
            DataSet01STableAdapters.invoicesitemsTableAdapter tt = new DataSet01STableAdapters.invoicesitemsTableAdapter();
            DataSet01S.invoicesitemsDataTable dd = tt.GetDataBy1(invoices_id);
            
            //make new filename
            string pdffilename = string.Empty;
            do
            {
                pdffilename = tmplocation + "\\invoice_" + r.invoices_date.Year.ToString().PadLeft(4, '0') + "-" + r.invoices_date.Month.ToString().PadLeft(2, '0') + "-" + r.invoices_date.Day.ToString().PadLeft(2, '0') + "_" + r.invoices_number.ToString() + "_" + CLGeneric.make_random_string(12) + ".pdf";
            } while (File.Exists(pdffilename));

            //fill infos
            Document document = new Document(PageSize.A4);
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(pdffilename, FileMode.Create));
            writer.ViewerPreferences = PdfWriter.PageModeUseOutlines;
            PrintPageN printPageN = new PrintPageN();
            writer.PageEvent = printPageN;
            document.Open();

            iTextSharp.text.Font b10Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font b12Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font n10Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL);
            iTextSharp.text.Font n8Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL);

            PdfPTable aTable = null;
            PdfPTable bTable = null;
            PdfPCell aCell = null;
            Phrase phrase = null;

            //title
            aTable = new PdfPTable(new float[] { 1 });
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicestitle"), b12Font));
            aCell = new PdfPCell(phrase);
            aCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aCell.PaddingBottom = 10;
            aCell.HorizontalAlignment = Element.ALIGN_CENTER;
            aTable.AddCell(aCell);
            document.Add(aTable);

            //info
            aTable = new PdfPTable(new float[] { 1, 1, 1});
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] { 250, aTable.TotalWidth - 400, 150});
            phrase = new Phrase();
            phrase.Add(new Chunk(r.invoices_userstext, n10Font));
            aTable.AddCell(phrase);
            aTable.AddCell(new Paragraph(" "));
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicesnumber") + ": ", b10Font));
            phrase.Add(new Chunk(r.invoices_number.ToString(), n10Font));
            phrase.Add(new Chunk("/", n10Font));
            phrase.Add(new Chunk(r.invoices_date.Year.ToString(), n10Font));
            phrase.Add(new Chunk("\n"));
            phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicesdate") + ": ", b10Font));
            phrase.Add(new Chunk(r.invoices_date.ToShortDateString(), n10Font));
            aTable.AddCell(phrase);
            document.Add(aTable);

            //to
            aTable = new PdfPTable(new float[] { 1, 1 });
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] {aTable.TotalWidth - 250, 250 });
            aTable.AddCell(new Paragraph(" "));
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("invoices_pdf_customerstext") + ":", b10Font));
            aCell = new PdfPCell(phrase);
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            aTable.AddCell(new Paragraph(""));
            phrase = new Phrase();
            phrase.Add(new Chunk(r.invoices_customerstext, n10Font));
            aTable.AddCell(phrase);
            document.Add(aTable);
            document.Add(new Paragraph(" "));

            //items
            aTable = new PdfPTable(new float[] { 1, 1, 1, 1});
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] { 70, aTable.TotalWidth - 210, 70, 70 });

            aCell = new PdfPCell(new Paragraph(Strings.T("invoices_pdf_thinvoicescode"), b10Font));
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            aCell = new PdfPCell(new Paragraph(Strings.T("invoices_pdf_thinvoicesdesc"), b10Font)); 
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            aCell = new PdfPCell(new Paragraph(Strings.T("invoices_pdf_thinvoicesprice"), b10Font)); 
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            aCell = new PdfPCell(new Paragraph(Strings.T("invoices_pdf_thinvoicestax"), b10Font));
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            foreach (DataSet01S.invoicesitemsRow rr in dd.Select())
            {
                if (rr["invoicesitems_code"].ToString().CompareTo(string.Empty) != 0)
                    if(rr.invoicesitems_code.CompareTo(string.Empty) != 0)
                        aTable.AddCell(new Paragraph(rr.invoicesitems_code, n10Font));
                    else
                        aTable.AddCell(new Paragraph("/"));
                else
                    aTable.AddCell(new Paragraph("/"));
                aTable.AddCell(new Paragraph(rr.invoicesitems_desc, n10Font));
                aTable.AddCell(new Paragraph(rr.invoicesitems_price.ToString(), n10Font));
                if (rr.invoicesitems_tax != 0)
                    aTable.AddCell(new Paragraph(rr.invoicesitems_tax + "%", n10Font));
                else
                    aTable.AddCell(new Paragraph("/"));
            }
            document.Add(aTable);

            if (writer.GetVerticalPosition(false) < 230)
            {
                float currentvert = writer.GetVerticalPosition(false);
                document.Add(new Paragraph(" "));
                while (writer.GetVerticalPosition(false) < currentvert)
                    document.Add(new Paragraph(" "));
            }
            while (writer.GetVerticalPosition(false) > (float)230)
                document.Add(new Paragraph(" "));

            decimal totalnotax = 0;
            decimal totaltax = 0;
            decimal totaldeductiontax = 0;
            decimal total = 0;
            calculate_total(invoices_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);

            //payment
            aTable = new PdfPTable(new float[] { 1, 1 });
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] { aTable.TotalWidth / 2, aTable.TotalWidth / 2 });

            bTable = new PdfPTable(new float[] { 1 });
            bTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            bTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            bTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;

            if (r["invoices_paymentstext"].ToString().CompareTo(string.Empty) != 0)
            {
                if (r.invoices_paymentstext.Trim().ToString().CompareTo(string.Empty) != 0)
                {
                    phrase = new Phrase();
                    phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicespaymentext") + ":", b10Font));
                    aCell = new PdfPCell(phrase);
                    aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
                    aCell.PaddingBottom = 5;
                    bTable.AddCell(aCell);
                    bTable.AddCell(new Paragraph(""));
                    phrase = new Phrase();
                    phrase.Add(new Chunk(r.invoices_paymentstext, n10Font));
                    bTable.AddCell(phrase);
                }
            }

            aTable.AddCell(bTable);

            bTable = new PdfPTable(new float[] { 1 });
            bTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            bTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            bTable.DefaultCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicestotals") + ":", b10Font));
            aCell = new PdfPCell(phrase);
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            bTable.AddCell(aCell);
            bTable.AddCell(new Paragraph(""));

            phrase = new Phrase();

            List<decimal> taxvaluel = new List<decimal>();
            foreach (DataSet01S.invoicesitemsRow rr in dd.OrderByDescending(a => a.invoicesitems_tax))
            {
                if (rr["invoicesitems_tax"].ToString().CompareTo(string.Empty) != 0)
                {
                    if (!taxvaluel.Contains(Convert.ToDecimal(rr.invoicesitems_tax)))
                        taxvaluel.Add(Convert.ToDecimal(rr.invoicesitems_tax));
                }
            }
            
            phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicestotalnotax") + ": ", b10Font));
            foreach (decimal taxvalue in taxvaluel)
            {
                string valuestring = "";
                decimal valuetotal = 0;
                foreach (DataSet01S.invoicesitemsRow rr in dd.Select("invoicesitems_tax = '" + taxvalue + "'"))
                {
                    valuetotal += Convert.ToDecimal(rr.invoicesitems_price);
                }
                if (valuetotal != 0)
                {
                    valuestring += "(" + taxvalue.ToString() + "%) " + Math.Round(valuetotal, 2);
                    phrase.Add(new Chunk(valuestring.ToString() + "\n", n10Font));
                }
            }
            phrase.Add(new Chunk(totalnotax.ToString() + "\n", n10Font));

            phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicestotaltax") + ": ", b10Font));
            foreach (decimal taxvalue in taxvaluel)
            {
                string taxvaluestring = "";
                decimal taxvaluetotal = 0;
                foreach (DataSet01S.invoicesitemsRow rr in dd.Select("invoicesitems_tax = '" + taxvalue + "'"))
                {
                    taxvaluetotal += Convert.ToDecimal(rr.invoicesitems_price) * Convert.ToDecimal(rr.invoicesitems_tax) / 100;
                }
                if (taxvaluetotal != 0)
                {
                    taxvaluestring += "(" + taxvalue.ToString() + "%) " + Math.Round(taxvaluetotal, 2);
                    phrase.Add(new Chunk(taxvaluestring.ToString() + "\n", n10Font));
                }
            }
            phrase.Add(new Chunk(totaltax.ToString() + "\n", n10Font));

            bTable.AddCell(phrase);

            if (totaldeductiontax != 0)
            {
                decimal totalnodeductiontax = total - totaldeductiontax;

                phrase = new Phrase();              

                phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicestotalnodeductiontax") + ": ", b10Font));
                phrase.Add(new Chunk(totalnodeductiontax.ToString() + "\n", n10Font));

                phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicestotaldeductiontax") + ": ", b10Font));
                phrase.Add(new Chunk("(" + Math.Round(Convert.ToDecimal(r["invoices_deductiontax"]), 2).ToString() + "%) " + totaldeductiontax.ToString() + "\n", n10Font));

                aCell = new PdfPCell(phrase);
                aCell.Border = iTextSharp.text.Rectangle.TOP_BORDER;
                aCell.HorizontalAlignment = Element.ALIGN_RIGHT;
                aCell.PaddingTop = 4;
                aCell.PaddingBottom = 4;
                bTable.AddCell(aCell);
            }
            
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("invoices_pdf_invoicestotal") + ": ", b10Font));
            phrase.Add(new Chunk(total.ToString() + "\n", b10Font));
            aCell = new PdfPCell(phrase);
            aCell.Border = iTextSharp.text.Rectangle.TOP_BORDER;
            aCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            aCell.PaddingTop = 4;
            aCell.PaddingBottom = 4;
            bTable.AddCell(aCell);

            aTable.AddCell(bTable);

            document.Add(aTable);

            //footer
            if(r["invoices_footerstext"].ToString().CompareTo(string.Empty) != 0)
            {
                aTable = new PdfPTable(new float[] { 1 });
                aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
                aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
                phrase = new Phrase();
                phrase.Add(new Chunk(r.invoices_footerstext, n8Font));
                aCell = new PdfPCell(phrase);
                aCell.Border = iTextSharp.text.Rectangle.TOP_BORDER;
                aCell.PaddingTop = 5;
                aTable.AddCell(aCell);
                document.Add(aTable);
            }            

            document.Close();

            try
            {
                Process.Start(pdffilename);
            }
            catch { }
        }

        #endregion

        private void viewDataTableinvoicesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            invoices_id = -1;

            invoicesBindingSource.Filter = "invoices_id = -1";

            try
            {
                invoices_id = (int)((DataSet01V.viewDataTableinvoicesRow)((DataRowView)viewDataTableinvoicesBindingSource.Current).Row).invoices_id;
            }
            catch { }

            textBox_total.Text = "0";
            textBox_totalpaid.Text = "0";
            comboBox_taxesdeduction.SelectedIndex = -1;
            comboBox_fillfrompayments.SelectedIndex = -1;
            comboBox_fillfromfootersdocs.SelectedIndex = -1;
            customers_idComboBox.SelectedIndex = -1;
            paystatus_idComboBox.SelectedIndex = -1;
            invoices_dateDateTimePicker.Value = DateTime.Now;

            if (invoices_id != -1)
            {
                invoicesTableAdapter.Fill(dataSet01S.invoices, invoices_id);

                invoicesBindingSource.RemoveFilter();
                invoicesBindingSource.Position = invoicesBindingSource.Find("invoices_id", invoices_id);

                decimal invoices_total = 0;
                decimal invoices_totalpaid = 0; 
                foreach (DataSet01V.viewDataTableinvoicesRow r in dataSet01V.viewDataTableinvoices)
                {
                    if(r.paystatus_id == 3)
                        invoices_totalpaid += r.invoices_total;
                    invoices_total += r.invoices_total;
                }
                textBox_total.Text = Math.Round(invoices_total, 2).ToString();
                textBox_totalpaid.Text = Math.Round(invoices_totalpaid, 2).ToString();

                decimal totalnotax = 0;
                decimal totaltax = 0;
                decimal totaldeductiontax = 0;
                decimal total = 0;
                calculate_total(invoices_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
                textBox_invoicesitemstotalnotax.Text = totalnotax.ToString();
                textBox_invoicesitemstotaltax.Text = totaltax.ToString();
                textBox_invoicesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                textBox_invoicesitemstotal.Text = total.ToString();
            }

            loading = 1;
            subviewDataTableinvoicespaymentsTableAdapter.Fill(dataSet01V.subviewDataTableinvoicespayments, invoices_id);
            loading = 0;
            subviewDataTableinvoicespaymentsBindingSource_CurrentChanged(null, null);

            loading = 1;
            subviewDataTableinvoicesitemsTableAdapter.Fill(dataSet01V.subviewDataTableinvoicesitems, invoices_id);
            loading = 0;
            subviewDataTableinvoicesitemsBindingSource_CurrentChanged(null, null);

            reload_animalstreatmentsinvoiceable();
        }

        private void reload_invoices()
        {
            load_invoices();
        }
        
        private void comboBox_filter_year_SelectedIndexChanged(object sender, EventArgs e)
        {
            load_invoices();
        }

        private void comboBox_filter_users_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            load_invoices();
        }

        private void load_invoices()
        {
            if (loading == 1)
                return;
            
            button_New.Enabled = false;
            button_Edit.Enabled = false;
            button_Delete.Enabled = false;
            button_Print.Enabled = false;
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = false;
            loading = 1;
            textBox_filter_number.Enabled = false;
            textBox_filter_customers.Enabled = false;
            textBox_filter_number.Text = string.Empty;
            textBox_filter_customers.Text = string.Empty;
            this.dataSet01V.viewDataTableinvoices.Rows.Clear();
            if (comboBox_filter_year.SelectedIndex != -1 && comboBox_filter_year.SelectedIndex != 0
                &&
                comboBox_filter_users_id.SelectedIndex != -1 && comboBox_filter_users_id.SelectedIndex != 0)
            {
                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;
                button_Print.Enabled = true;
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;
                textBox_filter_number.Enabled = true;
                textBox_filter_customers.Enabled = true;
                DateTime datefrom = new DateTime(Convert.ToInt32(comboBox_filter_year.SelectedItem), 1, 1, 0, 0, 0);
                DateTime dateto = new DateTime(Convert.ToInt32(comboBox_filter_year.SelectedItem), 1, 1, 0, 0, 0).AddYears(1).AddTicks(-1);
                this.viewDataTableinvoicesTableAdapter.Fill(this.dataSet01V.viewDataTableinvoices, datefrom, dateto, (Convert.ToInt32(((CLItemA)comboBox_filter_users_id.SelectedItem).id)));
            }
            loading = 0;
            viewDataTableinvoicesBindingSource_CurrentChanged(null, null);
        }

        private void tabControl_main_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!e.TabPage.Enabled)
                e.Cancel = true;
        }

        private void setFilter()
        {
            try
            {
                string filter_s = string.Empty;
                if (textBox_filter_number.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "invoices_number = '" + textBox_filter_number.Text + "'";
                }
                if (textBox_filter_customers.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "customers_alias LIKE '%" + textBox_filter_customers.Text + "%'";
                }

                viewDataTableinvoicesBindingSource.Filter = filter_s;
            }
            catch { }
        }
        
        private void textBox_filter_number_TextChanged(object sender, EventArgs e)
        {
            setFilter();
        }

        private void textBox_filter_customers_TextChanged(object sender, EventArgs e)
        {
            setFilter();
        }

        private void button_fillfrompayments_Click(object sender, EventArgs e)
        {
            invoices_paymentstextTextBox.Text = "";
            if (comboBox_fillfrompayments.SelectedIndex != -1 && comboBox_fillfrompayments.SelectedIndex != 0)
            {
                DataSet01STableAdapters.paymentsTableAdapter t = new DataSet01STableAdapters.paymentsTableAdapter();
                DataSet01S.paymentsRow r = t.GetData(Convert.ToInt32(((CLItemA)comboBox_fillfrompayments.SelectedItem).id)).First();
                string s = string.Empty;
                if (r["payments_desc"].ToString().CompareTo(string.Empty) != 0)
                    if (r.payments_desc.CompareTo(string.Empty) != 0)
                        s += r.payments_desc;
                invoices_paymentstextTextBox.Text = s;
            }
        }

        private void button_fillfromcustomers_Click(object sender, EventArgs e)
        {
            invoices_customerstextTextBox.Text = "";
            if (customers_idComboBox.SelectedIndex != -1)
            {
                DataSet01STableAdapters.customersTableAdapter t = new DataSet01STableAdapters.customersTableAdapter();
                DataSet01S.customersRow r = t.GetData(Convert.ToInt32(customers_idComboBox.SelectedValue)).First();
                string s = string.Empty;
                if (r["customers_invoicestext"].ToString().CompareTo(string.Empty) != 0)
                    if (r.customers_invoicestext.CompareTo(string.Empty) != 0)
                        s += r.customers_invoicestext + Environment.NewLine;
                invoices_customerstextTextBox.Text = s;
            }
        }

        private void button_fillfromusers_Click(object sender, EventArgs e)
        {
            invoices_userstextTextBox.Text = "";
            if (users_idComboBox.SelectedIndex != -1)
            {
                DataSet01STableAdapters.usersTableAdapter t = new DataSet01STableAdapters.usersTableAdapter();
                DataSet01S.usersRow r = t.GetData(Convert.ToInt32(users_idComboBox.SelectedValue)).First();
                string s = string.Empty;
                if (r["users_invoicestext"].ToString().CompareTo(string.Empty) != 0)
                    if (r.users_invoicestext.CompareTo(string.Empty) != 0)
                        s += r.users_invoicestext + Environment.NewLine;
                invoices_userstextTextBox.Text = s;
            }
        }

        private void button_fillfromfootersdocs_Click(object sender, EventArgs e)
        {
            invoices_footerstextTextBox.Text = "";
            if (comboBox_fillfromfootersdocs.SelectedIndex != -1 && comboBox_fillfromfootersdocs.SelectedIndex != 0)
            {
                DataSet01STableAdapters.footersdocsTableAdapter t = new DataSet01STableAdapters.footersdocsTableAdapter();
                DataSet01S.footersdocsRow r = t.GetData(Convert.ToInt32(Convert.ToInt32(((CLItemA)comboBox_fillfromfootersdocs.SelectedItem).id))).First();
                string s = string.Empty;
                if (r["footersdocs_desc"].ToString().CompareTo(string.Empty) != 0)
                    if (r.footersdocs_desc.CompareTo(string.Empty) != 0)
                        s += r.footersdocs_desc + Environment.NewLine;
                invoices_footerstextTextBox.Text = s;
            }
        }

        private void comboBox_taxesdeduction_SelectedIndexChanged(object sender, EventArgs e)
        {
            invoices_deductiontaxTextBox.Text = "0";
            if (comboBox_taxesdeduction.SelectedIndex != -1 && comboBox_taxesdeduction.SelectedIndex != 0)
            {
                DataSet01STableAdapters.taxesdeductionTableAdapter t = new DataSet01STableAdapters.taxesdeductionTableAdapter();
                decimal deductiontax = t.GetData(Convert.ToInt32(((CLItemA)comboBox_taxesdeduction.SelectedItem).id)).First().taxesdeduction_percent;
                if (IS_ACTION == IS_NEW)
                {
                    invoices_deductiontaxTextBox.Text = deductiontax.ToString();
                }
                else if (IS_ACTION == IS_EDIT)
                {
                    ((DataSet01S.invoicesRow)((DataRowView)invoicesBindingSource.Current).Row).invoices_deductiontax = deductiontax;
                }

                decimal totalnotax = 0;
                decimal totaltax = 0;
                decimal totaldeductiontax = 0;
                decimal total = 0;
                calculate_total(invoices_id, deductiontax, out totalnotax, out totaltax, out totaldeductiontax, out total);
                textBox_invoicesitemstotalnotax.Text = totalnotax.ToString();
                textBox_invoicesitemstotaltax.Text = totaltax.ToString();
                textBox_invoicesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                textBox_invoicesitemstotal.Text = total.ToString();
                ((DataSet01S.invoicesRow)((DataRowView)invoicesBindingSource.Current).Row).invoices_total = total;
            }
        }

        private void invoices_numberTextBox_Leave(object sender, EventArgs e)
        {
            if (!invoices_numberTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToInt32(invoices_numberTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric integer value");
                }
            }
        }

        private void invoices_deductiontaxTextBox_Leave(object sender, EventArgs e)
        {
            if (!invoices_deductiontaxTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(invoices_deductiontaxTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }

        private void calculate_total(int invoices_id, decimal deductiontax, out decimal totalnotax, out decimal totaltax, out decimal totaldeductiontax, out decimal total)
        {
            totalnotax = 0;
            totaltax = 0;
            totaldeductiontax = 0;
            total = 0;

            if (invoices_id != -1)
            {
                DataSet01STableAdapters.invoicesTableAdapter t = new DataSet01STableAdapters.invoicesTableAdapter();
                DataSet01S.invoicesRow r = t.GetData(invoices_id).First();
                DataSet01STableAdapters.invoicesitemsTableAdapter tt = new DataSet01STableAdapters.invoicesitemsTableAdapter();
                DataSet01S.invoicesitemsDataTable dd = tt.GetDataBy1(invoices_id);

                decimal invoicesitems_totalnotax = 0;
                decimal invoicesitems_totaltax = 0;
                decimal invoicesitems_totaldeductiontax = 0;
                decimal invoicesitems_total = 0;
                decimal invoices_deductiontax = 0;
                if(deductiontax != 0)
                    invoices_deductiontax = deductiontax;
                else
                    invoices_deductiontax = r.invoices_deductiontax;

                foreach (DataSet01S.invoicesitemsRow rr in dd)
                {
                    decimal rowinvoicesitems_price = 0;
                    decimal rowinvoicesitems_tax = 0;
                    decimal rowinvoicesitems_totaltax = 0;
                    decimal rowinvoicesitems_totaldeduction = 0;
                    decimal rowinvoicesitems_total = 0;
                    rowinvoicesitems_price = Convert.ToDecimal(rr.invoicesitems_price);
                    if (rr["invoicesitems_tax"].ToString().CompareTo(string.Empty) != 0)
                        rowinvoicesitems_tax = Convert.ToDecimal(rr.invoicesitems_tax);

                    rowinvoicesitems_total = rowinvoicesitems_price;
                    rowinvoicesitems_totaltax = rowinvoicesitems_price * rowinvoicesitems_tax / 100;
                    rowinvoicesitems_totaldeduction = rowinvoicesitems_price * invoices_deductiontax / 100;

                    invoicesitems_totaltax += Math.Round(rowinvoicesitems_totaltax, 2);
                    invoicesitems_totaldeductiontax += Math.Round(rowinvoicesitems_totaldeduction, 2);
                    invoicesitems_totalnotax += Math.Round(rowinvoicesitems_total, 2);
                    invoicesitems_total += Math.Round(rowinvoicesitems_total + rowinvoicesitems_totaltax - rowinvoicesitems_totaldeduction, 2);
                }

                totalnotax = invoicesitems_totalnotax;
                totaltax = invoicesitems_totaltax;
                totaldeductiontax = invoicesitems_totaldeductiontax;
                total = invoicesitems_total;
            }
        }


        #region invoicespayments

        private void setEditingMode_invoicespayments(bool editing_mode, bool subediting_mode)
        {
            if (editing_mode)
            {
                button_invoicespaymentsNew.Enabled = false;
                button_invoicespaymentsEdit.Enabled = false;
                button_invoicespaymentsDelete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;
                button_Stopedit.Enabled = false;

                invoicespayments_totalTextBox.ReadOnly = false;
                invoicespayments_notesTextBox.ReadOnly = false;
                invoicespayments_dateDateTimePicker.Enabled = true;
                
                dataGridView_invoicespaymentsmain.Enabled = false;
            }
            else
            {
                if (subediting_mode)
                {
                    button_invoicespaymentsNew.Enabled = true;
                    button_invoicespaymentsEdit.Enabled = true;
                    button_invoicespaymentsDelete.Enabled = true;
                }
                else
                {
                    button_invoicespaymentsNew.Enabled = false;
                    button_invoicespaymentsEdit.Enabled = false;
                    button_invoicespaymentsDelete.Enabled = false;
                }

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = true;

                invoicespayments_totalTextBox.ReadOnly = true;
                invoicespayments_notesTextBox.ReadOnly = true;
                invoicespayments_dateDateTimePicker.Enabled = false;

                dataGridView_invoicespaymentsmain.Enabled = true;
            }
        }

        private void subviewDataTableinvoicespaymentsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            invoicespayments_id = -1;

            invoicespaymentsBindingSource.Filter = "invoicespayments_id = -1";

            try
            {
                invoicespayments_id = (int)((DataSet01V.subviewDataTableinvoicespaymentsRow)((DataRowView)subviewDataTableinvoicespaymentsBindingSource.Current).Row).invoicespayments_id;
            }
            catch { }

            textBox_invoicespaymentstotal.Text = "0";
            invoicespayments_dateDateTimePicker.Value = DateTime.Now;

            if (invoicespayments_id != -1)
            {
                invoicespaymentsTableAdapter.Fill(dataSet01S.invoicespayments, invoicespayments_id);

                invoicespaymentsBindingSource.RemoveFilter();
                invoicespaymentsBindingSource.Position = invoicespaymentsBindingSource.Find("invoicespayments_id", invoicespayments_id);

                decimal invoicespayments_total = 0;
                foreach (DataSet01V.subviewDataTableinvoicespaymentsRow r in dataSet01V.subviewDataTableinvoicespayments)
                {
                    invoicespayments_total += r.invoicespayments_total;
                }
                textBox_invoicespaymentstotal.Text = Math.Round(invoicespayments_total, 2).ToString();
            }
        }

        private void button_invoicespaymentsNew_Click(object sender, EventArgs e)
        {
            IS_ACTIONSUB = IS_NEW;
            setEditingMode_invoicespayments(true, true);

            invoicespaymentsBindingSource.AddNew();

            invoicespayments_dateDateTimePicker.Value = DateTime.Now;
            invoicespayments_totalTextBox.Text = "0";
        }

        private void button_invoicespaymentsEdit_Click(object sender, EventArgs e)
        {
            if (invoicespayments_id != -1)
            {
                IS_ACTIONSUB = IS_EDIT;
                setEditingMode_invoicespayments(true, true);
            }
        }

        private void button_invoicespaymentsDelete_Click(object sender, EventArgs e)
        {
            if (invoicespayments_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    invoicespaymentsBindingSource.RemoveCurrent();
                    invoicespaymentsTableAdapter.Update(dataSet01S.invoicespayments);
                    dataSet01S.invoicespayments.AcceptChanges();

                    subviewDataTableinvoicespaymentsTableAdapter.Fill(dataSet01V.subviewDataTableinvoicespayments, invoices_id);
                }
            }
        }

        private bool validateUpdate_invoicespayments(ref string valid_s)
        {
            bool valid_b = true;

            if (invoicespayments_totalTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid total" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(invoicespayments_totalTextBox.Text);
                    if (d < 0)
                    {
                        valid_b = false;
                        valid_s += "invalid total" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid total" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void invoicespayments_Save()
        {
            string valid_s = string.Empty;
            if (!validateUpdate_invoicespayments(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }

            ((DataSet01S.invoicespaymentsRow)((DataRowView)invoicespaymentsBindingSource.Current).Row).invoices_id = invoices_id;

            invoicespaymentsBindingSource.EndEdit();
            invoicespaymentsTableAdapter.Update(dataSet01S.invoicespayments);
            dataSet01S.invoicespayments.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTIONSUB)
            {
                case IS_NEW:
                    sel_id = invoicespaymentsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = invoicespayments_id;
                    break;
            }

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_invoicespayments(false, true);

            subviewDataTableinvoicespaymentsTableAdapter.Fill(dataSet01V.subviewDataTableinvoicespayments, invoices_id);
            subviewDataTableinvoicespaymentsBindingSource.Position = subviewDataTableinvoicespaymentsBindingSource.Find("invoicespayments_id", sel_id);
        }

        private void invoicespayments_Undo()
        {
            invoicespaymentsBindingSource.CancelEdit();
            dataSet01S.invoicespayments.RejectChanges();

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_invoicespayments(false, true);
        }

        private void invoicespayments_totalTextBox_Leave(object sender, EventArgs e)
        {
            if (!invoicespayments_totalTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(invoicespayments_totalTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }

        #endregion


        #region invoicestreatments

        private void setEditingMode_invoicestreatments(bool editing_mode, bool subediting_mode)
        {
            if (editing_mode)
            {
                button_invoicestreatmentsAdd.Enabled = false;
                button_invoicestreatmentsRemove.Enabled = false;
                button_invoicestreatmentsMarkPaied.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;
                button_Stopedit.Enabled = false;

                dataGridView_invoicestreatmentsinvoiceable.Enabled = true;

                dataGridView_invoicestreatmentsmain.Enabled = false;
            }
            else
            {
                if (subediting_mode)
                {
                    button_invoicestreatmentsAdd.Enabled = true;
                    button_invoicestreatmentsRemove.Enabled = true;
                    button_invoicestreatmentsMarkPaied.Enabled = true;
                }
                else
                {
                    button_invoicestreatmentsAdd.Enabled = false;
                    button_invoicestreatmentsRemove.Enabled = false;
                    button_invoicestreatmentsMarkPaied.Enabled = false;
                }

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = true;

                dataGridView_invoicestreatmentsinvoiceable.Enabled = false;

                dataGridView_invoicestreatmentsmain.Enabled = true;
            }
        }

        private void subviewDataTableinvoicestreatmentsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            animalstreatments_id = -1;

            try
            {
                animalstreatments_id = (int)((DataSet01V.subviewDataTableinvoicestreatmentsRow)((DataRowView)subviewDataTableinvoicestreatmentsBindingSource.Current).Row).animalstreatments_id;
            }
            catch { }
        }

        private void invoicestreatments_Save()
        { 
        
        }
        
        private void invoicestreatments_Undo()
        {

        }

        private void button_invoicestreatmentsAdd_Click(object sender, EventArgs e)
        {
            int selanimalstreatments_id = -1;
            try
            {
                selanimalstreatments_id = (int)((DataSet01V.comboviewDataTableanimalstreatmentsinvoiceableRow)((DataRowView)comboviewDataTableanimalstreatmentsinvoiceableBindingSource.Current).Row).animalstreatments_id;
            }
            catch { }

            if (selanimalstreatments_id != -1)
            {
                DataSet01STableAdapters.animalstreatmentsTableAdapter t = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                DataSet01S.animalstreatmentsRow r = t.GetData(selanimalstreatments_id).First();
                r.invoices_id = invoices_id;
                t.Update(r);

                reload_animalstreatmentsinvoiceable();
            }
        }

        private void button_invoicestreatmentsRemove_Click(object sender, EventArgs e)
        {
            if (animalstreatments_id != -1)
            {
                DataSet01STableAdapters.animalstreatmentsTableAdapter t = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                DataSet01S.animalstreatmentsRow r = t.GetData(animalstreatments_id).First();
                r["invoices_id"] = DBNull.Value;
                t.Update(r);

                reload_animalstreatmentsinvoiceable();
            }
        }

        private void button_invoicestreatmentsMarkPaied_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you shure?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                foreach (DataSet01V.subviewDataTableinvoicestreatmentsRow r in dataSet01V.subviewDataTableinvoicestreatments.Select())
                {
                    DataSet01STableAdapters.animalstreatmentsTableAdapter t = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                    DataSet01S.animalstreatmentsRow r2 = t.GetData(r.animalstreatments_id).First();
                    if (r2.paystatus_id == 2 || r2.paystatus_id == 4)
                        r2.paystatus_id = 3;
                    t.Update(r2);
                }

                reload_animalstreatmentsinvoiceable();
            }
        }

        private void reload_animalstreatmentsinvoiceable()
        { 
            if(invoices_id != -1)
            {
                DataSet01STableAdapters.invoicesTableAdapter t = new DataSet01STableAdapters.invoicesTableAdapter();
                int customers_id = t.GetData(invoices_id).First().customers_id;
                this.comboviewDataTableanimalstreatmentsinvoiceableTableAdapter.Fill(this.dataSet01V.comboviewDataTableanimalstreatmentsinvoiceable, customers_id);
            }

            loading = 1;
            subviewDataTableinvoicestreatmentsTableAdapter.Fill(dataSet01V.subviewDataTableinvoicestreatments, invoices_id);
            loading = 0;
            subviewDataTableinvoicestreatmentsBindingSource_CurrentChanged(null, null);
        }

        #endregion


        #region invoicesitems

        private void setEditingMode_invoicesitems(bool editing_mode, bool subediting_mode)
        {
            if (editing_mode)
            {
                button_invoicesitemsNew.Enabled = false;
                button_invoicesitemsEdit.Enabled = false;
                button_invoicesitemsDelete.Enabled = false;
                button_invoicesitemsLoadfromtreatments.Enabled = false;
                button_invoicesitemsAddcomputedrowsdocs.Enabled = false;
                comboBox_invoicesitemscomputedrowsdocs.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;
                button_Stopedit.Enabled = false;

                groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Enabled = true;
                groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Visible = true;
                comboBox_invoicesitemstaxes.Enabled = true;
                invoicesitems_codeTextBox.ReadOnly = false;
                invoicesitems_descTextBox.ReadOnly = false;
                invoicesitems_priceTextBox.ReadOnly = false;
                invoicesitems_taxTextBox.ReadOnly = false;

                dataGridView_invoicesitemsmain.Enabled = false;
            }
            else
            {
                if (subediting_mode)
                {
                    button_invoicesitemsNew.Enabled = true;
                    button_invoicesitemsEdit.Enabled = true;
                    button_invoicesitemsDelete.Enabled = true;
                    button_invoicesitemsLoadfromtreatments.Enabled = true;
                    button_invoicesitemsAddcomputedrowsdocs.Enabled = true;
                    comboBox_invoicesitemscomputedrowsdocs.Enabled = true;
                }
                else
                {
                    button_invoicesitemsNew.Enabled = false;
                    button_invoicesitemsEdit.Enabled = false;
                    button_invoicesitemsDelete.Enabled = false;
                    button_invoicesitemsLoadfromtreatments.Enabled = false;
                    button_invoicesitemsAddcomputedrowsdocs.Enabled = false;
                    comboBox_invoicesitemscomputedrowsdocs.Enabled = false;
                }

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = true;

                groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Enabled = false;
                groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Visible = false;
                comboBox_invoicesitemstaxes.Enabled = false;
                invoicesitems_codeTextBox.ReadOnly = true;
                invoicesitems_descTextBox.ReadOnly = true;
                invoicesitems_priceTextBox.ReadOnly = true;
                invoicesitems_taxTextBox.ReadOnly = true;

                dataGridView_invoicesitemsmain.Enabled = true;
            }
        }
        
        private void subviewDataTableinvoicesitemsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            invoicesitems_id = -1;

            invoicesitemsBindingSource.Filter = "invoicesitems_id = -1";

            try
            {
                invoicesitems_id = (int)((DataSet01V.subviewDataTableinvoicesitemsRow)((DataRowView)subviewDataTableinvoicesitemsBindingSource.Current).Row).invoicesitems_id;
            }
            catch { }
            
            comboBox_invoicesitemscomputedrowsdocs.SelectedIndex = -1;
            comboBox_invoicesitemstaxes.SelectedIndex = -1;

            if (invoicesitems_id != -1)
            {
                invoicesitemsTableAdapter.Fill(dataSet01S.invoicesitems, invoicesitems_id);

                invoicesitemsBindingSource.RemoveFilter();
                invoicesitemsBindingSource.Position = invoicesitemsBindingSource.Find("invoicesitems_id", invoicesitems_id);
            }
        }

        private void button_invoicesitemsNew_Click(object sender, EventArgs e)
        {
            IS_ACTIONSUB = IS_NEW;
            setEditingMode_invoicesitems(true, true);

            invoicesitemsBindingSource.AddNew();

            invoicesitems_taxTextBox.Text = "0";
            DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
            if (t.GetDataBy2().First()["taxes_id"].ToString().CompareTo(string.Empty) != 0)
            {
                if (t.GetDataBy2().First().taxes_default == 1)
                {
                    foreach (CLItemA item in comboBox_invoicesitemstaxes.Items)
                    {
                        if (Convert.ToInt32(item.id) == t.GetDataBy2().First().taxes_id)
                        {
                            comboBox_invoicesitemstaxes.SelectedItem = item;
                            break;
                        }
                    }
                }
            }
            invoicesitems_priceTextBox.Text = "0";
        }

        private void button_invoicesitemsEdit_Click(object sender, EventArgs e)
        {
            if (invoicesitems_id != -1)
            {
                IS_ACTIONSUB = IS_EDIT;
                setEditingMode_invoicesitems(true, true);
            }
        }

        private void button_invoicesitemsDelete_Click(object sender, EventArgs e)
        {
            if (invoicesitems_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    invoicesitemsBindingSource.RemoveCurrent();
                    invoicesitemsTableAdapter.Update(dataSet01S.invoicesitems);
                    dataSet01S.animalstreatments.AcceptChanges();

                    subviewDataTableinvoicesitemsTableAdapter.Fill(dataSet01V.subviewDataTableinvoicesitems, invoices_id);

                    decimal totalnotax = 0;
                    decimal totaltax = 0;
                    decimal totaldeductiontax = 0;
                    decimal total = 0;
                    calculate_total(invoices_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
                    textBox_invoicesitemstotalnotax.Text = totalnotax.ToString();
                    textBox_invoicesitemstotaltax.Text = totaltax.ToString();
                    textBox_invoicesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                    textBox_invoicesitemstotal.Text = total.ToString();

                    DataSet01STableAdapters.invoicesTableAdapter ttttt = new DataSet01STableAdapters.invoicesTableAdapter();
                    DataSet01S.invoicesRow rrrrr = ttttt.GetData(invoices_id).First();
                    rrrrr.invoices_total = total;
                    ttttt.Update(rrrrr);
                }
            }
        }

        private bool validateUpdate_invoicesitems(ref string valid_s)
        {
            bool valid_b = true;

            if (invoicesitems_priceTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "select a price" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(invoicesitems_priceTextBox.Text);
                    if (d < 0)
                    {
                        valid_b = false;
                        valid_s += "invalid price" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid price" + Environment.NewLine;
                }
            }
            if (invoicesitems_taxTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid tax" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(invoicesitems_taxTextBox.Text);
                    if (d < 0 || d > 100)
                    {
                        valid_b = false;
                        valid_s += "invalid tax" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid tax" + Environment.NewLine;
                }
            }
            if (invoicesitems_descTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid description" + Environment.NewLine;
            }

            return valid_b;
        }

        private void invoicesitems_Save()
        {
            string valid_s = string.Empty;
            if (!validateUpdate_invoicesitems(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }

            ((DataSet01S.invoicesitemsRow)((DataRowView)invoicesitemsBindingSource.Current).Row).invoices_id = invoices_id;

            invoicesitemsBindingSource.EndEdit();
            invoicesitemsTableAdapter.Update(dataSet01S.invoicesitems);
            dataSet01S.invoicesitems.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTIONSUB)
            {
                case IS_NEW:
                    sel_id = invoicesitemsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = invoicesitems_id;
                    break;
            }

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_invoicesitems(false, true);

            subviewDataTableinvoicesitemsTableAdapter.Fill(dataSet01V.subviewDataTableinvoicesitems, invoices_id);
            subviewDataTableinvoicesitemsBindingSource.Position = subviewDataTableinvoicesitemsBindingSource.Find("invoicesitems_id", sel_id);

            decimal totalnotax = 0;
            decimal totaltax = 0;
            decimal totaldeductiontax = 0;
            decimal total = 0;
            calculate_total(invoices_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
            textBox_invoicesitemstotalnotax.Text = totalnotax.ToString();
            textBox_invoicesitemstotaltax.Text = totaltax.ToString();
            textBox_invoicesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
            textBox_invoicesitemstotal.Text = total.ToString();

            DataSet01STableAdapters.invoicesTableAdapter ttttt = new DataSet01STableAdapters.invoicesTableAdapter();
            DataSet01S.invoicesRow rrrrr = ttttt.GetData(invoices_id).First();
            rrrrr.invoices_total = total;
            ttttt.Update(rrrrr);
        }

        private void invoicesitems_Undo()
        {
            invoicesitemsBindingSource.CancelEdit();
            dataSet01S.invoicesitems.RejectChanges();

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_invoicesitems(false, true);

            comboBox_invoicesitemstaxes.SelectedIndex = -1;
            comboBox_invoicesitemscomputedrowsdocs.SelectedIndex = -1;
        }

        private void setFilter_invoicesitemsfillfromtreatments()
        {
            try
            {
                string filter_s = string.Empty;
                if (textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "treatments_code LIKE '%" + textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code.Text + "%'";
                }
                if (comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex != -1 && comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "treatmentscategories_id = '" + Convert.ToInt32(((CLItemA)comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedItem).id) + "'";
                }
                if (textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "treatments_name LIKE '%" + textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name.Text + "%'";
                }

                comboviewDataTabletreatmentsBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name_TextChanged(object sender, EventArgs e)
        {
            setFilter_invoicesitemsfillfromtreatments();
        }

        private void textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code_TextChanged(object sender, EventArgs e)
        {
            setFilter_invoicesitemsfillfromtreatments();
        }

        private void comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            setFilter_invoicesitemsfillfromtreatments();
        }

        private void button_invoicesitemsfillfromtreatments_Click(object sender, EventArgs e)
        {
            int treatments_id = -1;
            try
            {
                treatments_id = ((DataSet01V.comboviewDataTabletreatmentsRow)((DataRowView)comboviewDataTabletreatmentsBindingSource.Current).Row).treatments_id;
            }
            catch { }

            if (treatments_id != -1)
            {
                DataSet01STableAdapters.treatmentsTableAdapter t = new DataSet01STableAdapters.treatmentsTableAdapter();
                DataSet01S.treatmentsRow r = t.GetData(treatments_id).First();
                if (r["treatments_code"].ToString().CompareTo(string.Empty) != 0)
                {
                    invoicesitems_codeTextBox.Text = r.treatments_code.ToString();
                }
                if (r["treatments_desc"].ToString().CompareTo(string.Empty) != 0)
                {
                    invoicesitems_descTextBox.Text = r.treatments_desc.ToString();
                }
                if (r["treatments_price"].ToString().CompareTo(string.Empty) != 0)
                {
                    if (r.treatments_price > 0)
                    {
                        invoicesitems_priceTextBox.Text = r.treatments_price.ToString();
                    }
                }
                comboBox_invoicesitemstaxes.SelectedIndex = -1;
                if (r["taxes_id"].ToString().CompareTo(string.Empty) != 0)
                {
                    foreach (CLItemA item in comboBox_invoicesitemstaxes.Items)
                    { 
                        if(Convert.ToInt32(item.id) == r.taxes_id)
                        {
                            comboBox_invoicesitemstaxes.SelectedItem = item;
                            break;
                        }
                    }
                }
            }
        }

        private void comboBox_invoicesitemstaxes_SelectedIndexChanged(object sender, EventArgs e)
        {
            invoicesitems_taxTextBox.Text = "0";
            if (comboBox_invoicesitemstaxes.SelectedIndex != -1 && comboBox_invoicesitemstaxes.SelectedIndex != 0)
            {
                DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
                decimal tax = t.GetData(Convert.ToInt32(((CLItemA)comboBox_invoicesitemstaxes.SelectedItem).id)).First().taxes_percent;
                if (IS_ACTIONSUB == IS_NEW)
                {
                    invoicesitems_taxTextBox.Text = tax.ToString();
                }
                else if (IS_ACTIONSUB == IS_EDIT)
                {
                    ((DataSet01S.invoicesitemsRow)((DataRowView)invoicesitemsBindingSource.Current).Row).invoicesitems_tax = tax;
                }
            }
        }


        private void button_invoicesitemsAddcomputedrowsdocs_Click(object sender, EventArgs e)
        {
            if (comboBox_invoicesitemscomputedrowsdocs.SelectedIndex != -1 && comboBox_invoicesitemscomputedrowsdocs.SelectedIndex != 0)
            {
                IS_ACTIONSUB = IS_NEW;
                setEditingMode_invoicesitems(true, true);

                invoicesitemsBindingSource.AddNew();

                invoicesitems_taxTextBox.Text = "0";
                DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
                if (t.GetDataBy2().First()["taxes_id"].ToString().CompareTo(string.Empty) != 0)
                {
                    if (t.GetDataBy2().First().taxes_default == 1)
                    {
                        foreach (CLItemA item in comboBox_invoicesitemstaxes.Items)
                        {
                            if (Convert.ToInt32(item.id) == t.GetDataBy2().First().taxes_id)
                            {
                                comboBox_invoicesitemstaxes.SelectedItem = item;
                                break;
                            }
                        }
                    }
                }

                DataSet01STableAdapters.computedrowsdocsTableAdapter tt = new DataSet01STableAdapters.computedrowsdocsTableAdapter();
                decimal computedrowsdocs_percent = tt.GetData(Convert.ToInt32(((CLItemA)comboBox_invoicesitemscomputedrowsdocs.SelectedItem).id)).First().computedrowsdocs_percent;

                decimal totalnotax = 0;
                decimal totaltax = 0;
                decimal totaldeductiontax = 0;
                decimal total = 0;
                calculate_total(invoices_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
                textBox_invoicesitemstotalnotax.Text = totalnotax.ToString();
                textBox_invoicesitemstotaltax.Text = totaltax.ToString();
                textBox_invoicesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                textBox_invoicesitemstotal.Text = total.ToString();

                DataSet01STableAdapters.invoicesTableAdapter ttttt = new DataSet01STableAdapters.invoicesTableAdapter();
                DataSet01S.invoicesRow rrrrr = ttttt.GetData(invoices_id).First();
                rrrrr.invoices_total = total;
                ttttt.Update(rrrrr);

                invoicesitems_priceTextBox.Text = Math.Round(totalnotax * computedrowsdocs_percent / 100, 2).ToString();
                invoicesitems_descTextBox.Text = tt.GetData(Convert.ToInt32(((CLItemA)comboBox_invoicesitemscomputedrowsdocs.SelectedItem).id)).First().computedrowsdocs_name;
            }
        }
        
        private void button_invoicesitemsLoadfromtreatments_Click(object sender, EventArgs e)
        {
            DataSet01STableAdapters.animalstreatmentsTableAdapter tttt = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
            foreach (DataSet01S.animalstreatmentsRow rrrr in tttt.GetDataBy1(invoices_id).Select())
            {
                if (rrrr["animalstreatments_desc"].ToString().CompareTo(string.Empty) != 0 &&
                    rrrr["animalstreatments_price"].ToString().CompareTo(string.Empty) != 0)
                {
                    DataSet01S.invoicesitemsRow ri = dataSet01S.invoicesitems.NewinvoicesitemsRow();
                    ri.invoices_id = invoices_id;
                    ri.invoicesitems_desc = rrrr.animalstreatments_desc;
                    ri.invoicesitems_price = rrrr.animalstreatments_price;
                    if (rrrr["animalstreatments_code"].ToString().CompareTo(string.Empty) != 0)
                    {
                        ri.invoicesitems_code = rrrr.animalstreatments_code;
                        ri.invoicesitems_tax = 0;
                        DataSet01STableAdapters.treatmentsTableAdapter tt = new DataSet01STableAdapters.treatmentsTableAdapter();
                        DataSet01S.treatmentsDataTable td = tt.GetDataBy1(rrrr.animalstreatments_code);
                        if (td.Select().Count() > 0)
                        {
                            DataSet01S.treatmentsRow rr = (DataSet01S.treatmentsRow)td.Select().First();
                            if (rr["taxes_id"].ToString().CompareTo(string.Empty) != 0)
                            {
                                DataSet01STableAdapters.taxesTableAdapter ttt = new DataSet01STableAdapters.taxesTableAdapter();
                                ri.invoicesitems_tax = ttt.GetData(rr.taxes_id).First().taxes_percent;
                            }
                        }
                    }
                    else
                    {
                        ri.invoicesitems_tax = 0;
                        DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
                        if (t.GetDataBy2().First()["taxes_id"].ToString().CompareTo(string.Empty) != 0)
                        {
                            if (t.GetDataBy2().First().taxes_default == 1)
                            {
                                ri.invoicesitems_tax = t.GetDataBy2().First().taxes_percent;
                            }
                        }
                    }
                    dataSet01S.invoicesitems.AddinvoicesitemsRow(ri);
                    invoicesitemsTableAdapter.Update(dataSet01S.invoicesitems);
                }
            }
            subviewDataTableinvoicesitemsTableAdapter.Fill(dataSet01V.subviewDataTableinvoicesitems, invoices_id);
            subviewDataTableinvoicesitemsBindingSource_CurrentChanged(null, null);

            decimal totalnotax = 0;
            decimal totaltax = 0;
            decimal totaldeductiontax = 0;
            decimal total = 0;
            calculate_total(invoices_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
            textBox_invoicesitemstotalnotax.Text = totalnotax.ToString();
            textBox_invoicesitemstotaltax.Text = totaltax.ToString();
            textBox_invoicesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
            textBox_invoicesitemstotal.Text = total.ToString();

            DataSet01STableAdapters.invoicesTableAdapter ttttt = new DataSet01STableAdapters.invoicesTableAdapter();
            DataSet01S.invoicesRow rrrrr = ttttt.GetData(invoices_id).First();
            rrrrr.invoices_total = total;
            ttttt.Update(rrrrr);
        }
        
        private void invoicesitems_taxTextBox_Leave(object sender, EventArgs e)
        {
            if (!invoicesitems_taxTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(invoicesitems_taxTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }

        private void invoicesitems_priceTextBox_Leave(object sender, EventArgs e)
        {
            if (!invoicesitems_priceTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(invoicesitems_priceTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }

        #endregion

    }
}
