﻿namespace vettev
{
    partial class FormBreeds
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label breeds_nameLabel;
            System.Windows.Forms.Label families_idLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBreeds));
            this.panel6 = new System.Windows.Forms.Panel();
            this.families_idComboBox = new System.Windows.Forms.ComboBox();
            this.breedsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01S = new vettev.DataSet01S();
            this.comboviewDataTablefamiliesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01V = new vettev.DataSet01V();
            this.breeds_nameTextBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Undo = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.familiesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.breedsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTablebreedsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_New = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel_filter = new System.Windows.Forms.Panel();
            this.comboBox_filter_families_id = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.viewDataTablebreedsTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTablebreedsTableAdapter();
            this.breedsTableAdapter = new vettev.DataSet01STableAdapters.breedsTableAdapter();
            this.comboviewDataTablefamiliesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablefamiliesTableAdapter();
            breeds_nameLabel = new System.Windows.Forms.Label();
            families_idLabel = new System.Windows.Forms.Label();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.breedsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablefamiliesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablebreedsBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel_filter.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // breeds_nameLabel
            // 
            breeds_nameLabel.AutoSize = true;
            breeds_nameLabel.Location = new System.Drawing.Point(10, 55);
            breeds_nameLabel.Name = "breeds_nameLabel";
            breeds_nameLabel.Size = new System.Drawing.Size(36, 13);
            breeds_nameLabel.TabIndex = 0;
            breeds_nameLabel.Text = "name:";
            // 
            // families_idLabel
            // 
            families_idLabel.AutoSize = true;
            families_idLabel.Location = new System.Drawing.Point(10, 15);
            families_idLabel.Name = "families_idLabel";
            families_idLabel.Size = new System.Drawing.Size(44, 13);
            families_idLabel.TabIndex = 2;
            families_idLabel.Text = "families:";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(families_idLabel);
            this.panel6.Controls.Add(this.families_idComboBox);
            this.panel6.Controls.Add(breeds_nameLabel);
            this.panel6.Controls.Add(this.breeds_nameTextBox);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(300, 422);
            this.panel6.TabIndex = 1;
            // 
            // families_idComboBox
            // 
            this.families_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.breedsBindingSource, "families_id", true));
            this.families_idComboBox.DataSource = this.comboviewDataTablefamiliesBindingSource;
            this.families_idComboBox.DisplayMember = "families_name";
            this.families_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.families_idComboBox.FormattingEnabled = true;
            this.families_idComboBox.Location = new System.Drawing.Point(13, 31);
            this.families_idComboBox.Name = "families_idComboBox";
            this.families_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.families_idComboBox.TabIndex = 3;
            this.families_idComboBox.ValueMember = "families_id";
            // 
            // breedsBindingSource
            // 
            this.breedsBindingSource.DataMember = "breeds";
            this.breedsBindingSource.DataSource = this.dataSet01S;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboviewDataTablefamiliesBindingSource
            // 
            this.comboviewDataTablefamiliesBindingSource.DataMember = "comboviewDataTablefamilies";
            this.comboviewDataTablefamiliesBindingSource.DataSource = this.dataSet01V;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // breeds_nameTextBox
            // 
            this.breeds_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.breedsBindingSource, "breeds_name", true));
            this.breeds_nameTextBox.Location = new System.Drawing.Point(13, 71);
            this.breeds_nameTextBox.MaxLength = 100;
            this.breeds_nameTextBox.Name = "breeds_nameTextBox";
            this.breeds_nameTextBox.Size = new System.Drawing.Size(275, 20);
            this.breeds_nameTextBox.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(384, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 462);
            this.panel2.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 422);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 35);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(384, 387);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.familiesnameDataGridViewTextBoxColumn,
            this.breedsnameDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTablebreedsBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(384, 387);
            this.dataGridView_main.TabIndex = 0;
            // 
            // familiesnameDataGridViewTextBoxColumn
            // 
            this.familiesnameDataGridViewTextBoxColumn.DataPropertyName = "families_name";
            this.familiesnameDataGridViewTextBoxColumn.HeaderText = "Family";
            this.familiesnameDataGridViewTextBoxColumn.Name = "familiesnameDataGridViewTextBoxColumn";
            this.familiesnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.familiesnameDataGridViewTextBoxColumn.Width = 120;
            // 
            // breedsnameDataGridViewTextBoxColumn
            // 
            this.breedsnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.breedsnameDataGridViewTextBoxColumn.DataPropertyName = "breeds_name";
            this.breedsnameDataGridViewTextBoxColumn.HeaderText = "Breed";
            this.breedsnameDataGridViewTextBoxColumn.Name = "breedsnameDataGridViewTextBoxColumn";
            this.breedsnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTablebreedsBindingSource
            // 
            this.viewDataTablebreedsBindingSource.DataMember = "viewDataTablebreeds";
            this.viewDataTablebreedsBindingSource.DataSource = this.dataSet01V;
            this.viewDataTablebreedsBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTablebreedsBindingSource_CurrentChanged);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 462);
            this.panel1.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel_filter);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(384, 35);
            this.panel7.TabIndex = 3;
            // 
            // panel_filter
            // 
            this.panel_filter.Controls.Add(this.comboBox_filter_families_id);
            this.panel_filter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filter.Location = new System.Drawing.Point(0, 0);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new System.Drawing.Size(384, 35);
            this.panel_filter.TabIndex = 3;
            // 
            // comboBox_filter_families_id
            // 
            this.comboBox_filter_families_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_filter_families_id.FormattingEnabled = true;
            this.comboBox_filter_families_id.Location = new System.Drawing.Point(3, 11);
            this.comboBox_filter_families_id.Name = "comboBox_filter_families_id";
            this.comboBox_filter_families_id.Size = new System.Drawing.Size(121, 21);
            this.comboBox_filter_families_id.TabIndex = 0;
            this.comboBox_filter_families_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_families_id_SelectedIndexChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 422);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 40);
            this.panel4.TabIndex = 1;
            // 
            // viewDataTablebreedsTableAdapter
            // 
            this.viewDataTablebreedsTableAdapter.ClearBeforeFill = true;
            // 
            // breedsTableAdapter
            // 
            this.breedsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablefamiliesTableAdapter
            // 
            this.comboviewDataTablefamiliesTableAdapter.ClearBeforeFill = true;
            // 
            // FormBreeds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 462);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormBreeds";
            this.Text = "Breeds";
            this.Activated += new System.EventHandler(this.FormBreeds_Activated);
            this.Deactivate += new System.EventHandler(this.FormBreeds_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormBreeds_FormClosing);
            this.Load += new System.EventHandler(this.FormBreeds_Load);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.breedsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablefamiliesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablebreedsBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel_filter.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.BindingSource viewDataTablebreedsBindingSource;
        private DataSet01VTableAdapters.viewDataTablebreedsTableAdapter viewDataTablebreedsTableAdapter;
        private System.Windows.Forms.BindingSource breedsBindingSource;
        private DataSet01STableAdapters.breedsTableAdapter breedsTableAdapter;
        private System.Windows.Forms.TextBox breeds_nameTextBox;
        private System.Windows.Forms.ComboBox families_idComboBox;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.ComboBox comboBox_filter_families_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn familiesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn breedsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource comboviewDataTablefamiliesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablefamiliesTableAdapter comboviewDataTablefamiliesTableAdapter;
        private System.Windows.Forms.Panel panel_filter;
    }
}