﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormTaxes : Form
    {
        int taxes_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormTaxes()
        {
            InitializeComponent();
        }

        private void FormTaxes_Load(object sender, EventArgs e)
        {
            this.viewDataTabletaxesTableAdapter.Fill(this.dataSet01V.viewDataTabletaxes);

            viewDataTabletaxesBindingSource.Sort = "taxes_name";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTabletaxesBindingSource_CurrentChanged(null, null);
        }

        private void FormTaxes_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormTaxes_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormTaxes_Load(sender, e);
        }

        private void FormTaxes_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                taxes_nameTextBox.ReadOnly = false;
                taxes_percentTextBox.ReadOnly = false;
                taxes_defaultCheckBox.Enabled = true;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                taxes_nameTextBox.ReadOnly = true;
                taxes_percentTextBox.ReadOnly = true;
                taxes_defaultCheckBox.Enabled = false;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            taxesBindingSource.AddNew();

            taxes_percentTextBox.Text = "0";
            taxes_defaultCheckBox.Checked = false;
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (taxes_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (taxes_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    bool candelete = true;
                    string candeletetxt = "";

                    {
                        DataSet01STableAdapters.treatmentsTableAdapter t = new DataSet01STableAdapters.treatmentsTableAdapter();
                        if (t.GetDataBy3(taxes_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "treatments" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }
                    
                    if (!candelete)
                    {
                        MessageBox.Show(candeletetxt);
                        return;
                    }

                    taxesBindingSource.RemoveCurrent();
                    taxesTableAdapter.Update(dataSet01S.taxes);
                    dataSet01S.taxes.AcceptChanges();

                    viewDataTabletaxesTableAdapter.Fill(dataSet01V.viewDataTabletaxes);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (taxes_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
                if (t.GetDataBy1(taxes_nameTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1(taxes_nameTextBox.Text).Select("taxes_id <> " + taxes_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
            }
            if (taxes_percentTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid percent" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(taxes_percentTextBox.Text);
                    if (d < 0 || d > 100)
                    {
                        valid_b = false;
                        valid_s += "invalid percent" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid percent" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            
            taxesBindingSource.EndEdit();
            taxesTableAdapter.Update(dataSet01S.taxes);
            dataSet01S.taxes.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = taxesTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = taxes_id;
                    break;
            }

            if (taxes_defaultCheckBox.Checked)
            {
                DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
                foreach (DataSet01S.taxesRow r in t.GetDataBy2().Select())
                {
                    if (r.taxes_id != sel_id)
                    {
                        r.taxes_default = 0;
                        t.Update(r);
                    }
                }
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTabletaxesTableAdapter.Fill(dataSet01V.viewDataTabletaxes);
            viewDataTabletaxesBindingSource.Position = viewDataTabletaxesBindingSource.Find("taxes_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            taxesBindingSource.CancelEdit();
            dataSet01S.taxes.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTabletaxesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            taxes_id = -1;

            taxesBindingSource.Filter = "taxes_id = -1";

            try
            {
                taxes_id = (int)((DataSet01V.viewDataTabletaxesRow)((DataRowView)viewDataTabletaxesBindingSource.Current).Row).taxes_id;
            }
            catch { }

            if (taxes_id != -1)
            {
                taxesTableAdapter.Fill(dataSet01S.taxes, taxes_id);

                taxesBindingSource.RemoveFilter();
                taxesBindingSource.Position = taxesBindingSource.Find("taxes_id", taxes_id);
            }
        }

        private void taxes_percentTextBox_Leave(object sender, EventArgs e)
        {
            if (!taxes_percentTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(taxes_percentTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }
    }
}
