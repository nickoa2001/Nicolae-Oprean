﻿namespace vettev
{
    partial class FormComputedrowsdocs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label computedrowsdocs_nameLabel;
            System.Windows.Forms.Label computedrowsdocs_percentLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormComputedrowsdocs));
            this.button_Delete = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.computedrowsdocsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTablecomputedrowsdocsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01V = new vettev.DataSet01V();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_New = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.computedrowsdocs_percentTextBox = new System.Windows.Forms.TextBox();
            this.computedrowsdocsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01S = new vettev.DataSet01S();
            this.computedrowsdocs_nameTextBox = new System.Windows.Forms.TextBox();
            this.button_Undo = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Save = new System.Windows.Forms.Button();
            this.computedrowsdocsTableAdapter = new vettev.DataSet01STableAdapters.computedrowsdocsTableAdapter();
            this.viewDataTablecomputedrowsdocsTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTablecomputedrowsdocsTableAdapter();
            computedrowsdocs_nameLabel = new System.Windows.Forms.Label();
            computedrowsdocs_percentLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablecomputedrowsdocsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.computedrowsdocsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // computedrowsdocs_nameLabel
            // 
            computedrowsdocs_nameLabel.AutoSize = true;
            computedrowsdocs_nameLabel.Location = new System.Drawing.Point(10, 15);
            computedrowsdocs_nameLabel.Name = "computedrowsdocs_nameLabel";
            computedrowsdocs_nameLabel.Size = new System.Drawing.Size(36, 13);
            computedrowsdocs_nameLabel.TabIndex = 0;
            computedrowsdocs_nameLabel.Text = "name:";
            // 
            // computedrowsdocs_percentLabel
            // 
            computedrowsdocs_percentLabel.AutoSize = true;
            computedrowsdocs_percentLabel.Location = new System.Drawing.Point(10, 54);
            computedrowsdocs_percentLabel.Name = "computedrowsdocs_percentLabel";
            computedrowsdocs_percentLabel.Size = new System.Drawing.Size(46, 13);
            computedrowsdocs_percentLabel.TabIndex = 2;
            computedrowsdocs_percentLabel.Text = "percent:";
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 462);
            this.panel1.TabIndex = 6;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(384, 422);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.computedrowsdocsnameDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTablecomputedrowsdocsBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(384, 422);
            this.dataGridView_main.TabIndex = 0;
            // 
            // computedrowsdocsnameDataGridViewTextBoxColumn
            // 
            this.computedrowsdocsnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.computedrowsdocsnameDataGridViewTextBoxColumn.DataPropertyName = "computedrowsdocs_name";
            this.computedrowsdocsnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.computedrowsdocsnameDataGridViewTextBoxColumn.Name = "computedrowsdocsnameDataGridViewTextBoxColumn";
            this.computedrowsdocsnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTablecomputedrowsdocsBindingSource
            // 
            this.viewDataTablecomputedrowsdocsBindingSource.DataMember = "viewDataTablecomputedrowsdocs";
            this.viewDataTablecomputedrowsdocsBindingSource.DataSource = this.dataSet01V;
            this.viewDataTablecomputedrowsdocsBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTablecomputedrowsdocsBindingSource_CurrentChanged);
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 422);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 40);
            this.panel4.TabIndex = 1;
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.Controls.Add(computedrowsdocs_percentLabel);
            this.panel6.Controls.Add(this.computedrowsdocs_percentTextBox);
            this.panel6.Controls.Add(computedrowsdocs_nameLabel);
            this.panel6.Controls.Add(this.computedrowsdocs_nameTextBox);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(300, 422);
            this.panel6.TabIndex = 1;
            // 
            // computedrowsdocs_percentTextBox
            // 
            this.computedrowsdocs_percentTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.computedrowsdocsBindingSource, "computedrowsdocs_percent", true));
            this.computedrowsdocs_percentTextBox.Location = new System.Drawing.Point(13, 70);
            this.computedrowsdocs_percentTextBox.Name = "computedrowsdocs_percentTextBox";
            this.computedrowsdocs_percentTextBox.Size = new System.Drawing.Size(70, 20);
            this.computedrowsdocs_percentTextBox.TabIndex = 3;
            this.computedrowsdocs_percentTextBox.Leave += new System.EventHandler(this.computedrowsdocs_percentTextBox_Leave);
            // 
            // computedrowsdocsBindingSource
            // 
            this.computedrowsdocsBindingSource.DataMember = "computedrowsdocs";
            this.computedrowsdocsBindingSource.DataSource = this.dataSet01S;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // computedrowsdocs_nameTextBox
            // 
            this.computedrowsdocs_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.computedrowsdocsBindingSource, "computedrowsdocs_name", true));
            this.computedrowsdocs_nameTextBox.Location = new System.Drawing.Point(13, 31);
            this.computedrowsdocs_nameTextBox.Name = "computedrowsdocs_nameTextBox";
            this.computedrowsdocs_nameTextBox.Size = new System.Drawing.Size(275, 20);
            this.computedrowsdocs_nameTextBox.TabIndex = 1;
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(384, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 462);
            this.panel2.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 422);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // computedrowsdocsTableAdapter
            // 
            this.computedrowsdocsTableAdapter.ClearBeforeFill = true;
            // 
            // viewDataTablecomputedrowsdocsTableAdapter
            // 
            this.viewDataTablecomputedrowsdocsTableAdapter.ClearBeforeFill = true;
            // 
            // FormComputedrowsdocs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 462);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormComputedrowsdocs";
            this.Text = "Computed Rows";
            this.Activated += new System.EventHandler(this.FormComputedrowsdocs_Activated);
            this.Deactivate += new System.EventHandler(this.FormComputedrowsdocs_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormComputedrowsdocs_FormClosing);
            this.Load += new System.EventHandler(this.FormComputedrowsdocs_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablecomputedrowsdocsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.computedrowsdocsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private DataSet01V dataSet01V;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.Panel panel6;
        private DataSet01S dataSet01S;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.TextBox computedrowsdocs_percentTextBox;
        private System.Windows.Forms.TextBox computedrowsdocs_nameTextBox;
        private System.Windows.Forms.BindingSource computedrowsdocsBindingSource;
        private DataSet01STableAdapters.computedrowsdocsTableAdapter computedrowsdocsTableAdapter;
        private System.Windows.Forms.BindingSource viewDataTablecomputedrowsdocsBindingSource;
        private DataSet01VTableAdapters.viewDataTablecomputedrowsdocsTableAdapter viewDataTablecomputedrowsdocsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn computedrowsdocsnameDataGridViewTextBoxColumn;
    }
}