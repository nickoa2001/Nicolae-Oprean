﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormTaxesdeduction : Form
    {
        int taxesdeduction_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormTaxesdeduction()
        {
            InitializeComponent();
        }

        private void FormTaxesdeduction_Load(object sender, EventArgs e)
        {
            this.viewDataTabletaxesdeductionTableAdapter.Fill(this.dataSet01V.viewDataTabletaxesdeduction);

            viewDataTabletaxesdeductionBindingSource.Sort = "taxesdeduction_name";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTabletaxesdeductionBindingSource_CurrentChanged(null, null);
        }

        private void FormTaxesdeduction_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormTaxesdeduction_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormTaxesdeduction_Load(sender, e);
        }

        private void FormTaxesdeduction_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                taxesdeduction_nameTextBox.ReadOnly = false;
                taxesdeduction_percentTextBox.ReadOnly = false;
                taxesdeduction_defaultCheckBox.Enabled = true;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                taxesdeduction_nameTextBox.ReadOnly = true;
                taxesdeduction_percentTextBox.ReadOnly = true;
                taxesdeduction_defaultCheckBox.Enabled = false;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            taxesdeductionBindingSource.AddNew();

            taxesdeduction_percentTextBox.Text = "0";
            taxesdeduction_defaultCheckBox.Checked = false;
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (taxesdeduction_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (taxesdeduction_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    taxesdeductionBindingSource.RemoveCurrent();
                    taxesdeductionTableAdapter.Update(dataSet01S.taxesdeduction);
                    dataSet01S.taxesdeduction.AcceptChanges();

                    viewDataTabletaxesdeductionTableAdapter.Fill(dataSet01V.viewDataTabletaxesdeduction);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (taxesdeduction_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.taxesdeductionTableAdapter t = new DataSet01STableAdapters.taxesdeductionTableAdapter();
                if (t.GetDataBy1(taxesdeduction_nameTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1(taxesdeduction_nameTextBox.Text).Select("taxesdeduction_id <> " + taxesdeduction_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
            }
            if (taxesdeduction_percentTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid percent" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(taxesdeduction_percentTextBox.Text);
                    if (d < 0 || d > 100)
                    {
                        valid_b = false;
                        valid_s += "invalid percent" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid percent" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }

            taxesdeductionBindingSource.EndEdit();
            taxesdeductionTableAdapter.Update(dataSet01S.taxesdeduction);
            dataSet01S.taxesdeduction.AcceptChanges();
            
            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = taxesdeductionTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = taxesdeduction_id;
                    break;
            }

            if (taxesdeduction_defaultCheckBox.Checked)
            {
                DataSet01STableAdapters.taxesdeductionTableAdapter t = new DataSet01STableAdapters.taxesdeductionTableAdapter();
                foreach (DataSet01S.taxesdeductionRow r in t.GetDataBy2().Select())
                {
                    if (r.taxesdeduction_id != sel_id)
                    {
                        r.taxesdeduction_default = 0;
                        t.Update(r);
                    }
                }
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTabletaxesdeductionTableAdapter.Fill(dataSet01V.viewDataTabletaxesdeduction);
            viewDataTabletaxesdeductionBindingSource.Position = viewDataTabletaxesdeductionBindingSource.Find("taxesdeduction_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            taxesdeductionBindingSource.CancelEdit();
            dataSet01S.taxesdeduction.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTabletaxesdeductionBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            taxesdeduction_id = -1;

            taxesdeductionBindingSource.Filter = "taxesdeduction_id = -1";

            try
            {
                taxesdeduction_id = (int)((DataSet01V.viewDataTabletaxesdeductionRow)((DataRowView)viewDataTabletaxesdeductionBindingSource.Current).Row).taxesdeduction_id;
            }
            catch { }

            if (taxesdeduction_id != -1)
            {
                taxesdeductionTableAdapter.Fill(dataSet01S.taxesdeduction, taxesdeduction_id);

                taxesdeductionBindingSource.RemoveFilter();
                taxesdeductionBindingSource.Position = taxesdeductionBindingSource.Find("taxesdeduction_id", taxesdeduction_id);
            }
        }

        private void taxesdeduction_percentTextBox_Leave(object sender, EventArgs e)
        {
            if (!taxesdeduction_percentTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(taxesdeduction_percentTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }
    }
}
