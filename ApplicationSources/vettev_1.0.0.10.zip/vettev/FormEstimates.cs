﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Resources;
using System.Diagnostics;

namespace vettev
{
    public partial class FormEstimates : Form
    {
        int estimates_id = -1;
        int estimatesitems_id = -1;

        private static int IS_ACTION = 0;
        private static int IS_ACTIONSUB = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormEstimates()
        {
            InitializeComponent();
        }

        private void FormEstimates_Load(object sender, EventArgs e)
        {
            this.comboviewDataTablecomputedrowsdocsTableAdapter.Fill(this.dataSet01V.comboviewDataTablecomputedrowsdocs);
            this.comboviewDataTabletaxesdeductionTableAdapter.Fill(this.dataSet01V.comboviewDataTabletaxesdeduction);
            this.comboviewDataTablefootersdocsTableAdapter.Fill(this.dataSet01V.comboviewDataTablefootersdocs);
            this.comboviewDataTabletreatmentscategoriesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletreatmentscategories);
            this.comboviewDataTabletreatmentsTableAdapter.Fill(this.dataSet01V.comboviewDataTabletreatments);
            this.comboviewDataTabletaxesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletaxes);
            this.comboviewDataTableusersTableAdapter.Fill(this.dataSet01V.comboviewDataTableusers);
            this.comboviewDataTablepaymentsTableAdapter.Fill(this.dataSet01V.comboviewDataTablepayments);
            this.comboviewDataTablecustomersTableAdapter.Fill(this.dataSet01V.comboviewDataTablecustomers);

            viewDataTableestimatesBindingSource.Sort = "estimates_date DESC";

            subviewDataTableestimatesitemsBindingSource.Sort = "estimatesitems_id";
            comboviewDataTabletreatmentsBindingSource.Sort = "treatments_name";
            
            comboBox_filter_users_id.Items.Clear();
            comboBox_filter_users_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTableusersRow r in dataSet01V.comboviewDataTableusers.Select("", "users_alias"))
            {
                comboBox_filter_users_id.Items.Add(new CLItemA(r.users_id.ToString(), r.users_alias.ToString()));
            }
            if (comboBox_filter_users_id.Items.Count == 2)
                comboBox_filter_users_id.SelectedIndex = 1;
            else
                comboBox_filter_users_id.SelectedIndex = 0;

            comboBox_taxesdeduction.Items.Clear();
            comboBox_taxesdeduction.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletaxesdeductionRow r in dataSet01V.comboviewDataTabletaxesdeduction.Select("", "taxesdeduction_name"))
            {
                comboBox_taxesdeduction.Items.Add(new CLItemA(r.taxesdeduction_id.ToString(), r.taxesdeduction_name.ToString()));
            }
            comboBox_taxesdeduction.SelectedIndex = 0;

            comboBox_fillfrompayments.Items.Clear();
            comboBox_fillfrompayments.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablepaymentsRow r in dataSet01V.comboviewDataTablepayments.Select("", "payments_name"))
            {
                comboBox_fillfrompayments.Items.Add(new CLItemA(r.payments_id.ToString(), r.payments_name.ToString()));
            }
            comboBox_fillfrompayments.SelectedIndex = 0;

            comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.Items.Clear();
            comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletreatmentscategoriesRow r in dataSet01V.comboviewDataTabletreatmentscategories.Select("", "treatmentscategories_name"))
            {
                comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.Items.Add(new CLItemA(r.treatmentscategories_id.ToString(), r.treatmentscategories_name.ToString()));
            }
            comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex = 0;

            comboBox_fillfrompayments.Items.Clear();
            comboBox_fillfrompayments.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablepaymentsRow r in dataSet01V.comboviewDataTablepayments.Select("", "payments_name"))
            {
                comboBox_fillfrompayments.Items.Add(new CLItemA(r.payments_id.ToString(), r.payments_name.ToString()));
            }
            comboBox_fillfrompayments.SelectedIndex = 0;

            comboBox_fillfromfootersdocs.Items.Clear();
            comboBox_fillfromfootersdocs.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablefootersdocsRow r in dataSet01V.comboviewDataTablefootersdocs.Select("", "footersdocs_desc"))
            {
                comboBox_fillfromfootersdocs.Items.Add(new CLItemA(r.footersdocs_id.ToString(), (r.footersdocs_desc.ToString().Length > 100 ? r.footersdocs_desc.ToString().Substring(0, 100) : r.footersdocs_desc.ToString())));
            }
            comboBox_fillfromfootersdocs.SelectedIndex = 0;

            comboBox_estimatesitemstaxes.Items.Clear();
            comboBox_estimatesitemstaxes.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletaxesRow r in dataSet01V.comboviewDataTabletaxes.Select("", "taxes_name"))
            {
                comboBox_estimatesitemstaxes.Items.Add(new CLItemA(r.taxes_id.ToString(), r.taxes_name.ToString()));
            }
            comboBox_estimatesitemstaxes.SelectedIndex = 0;

            comboBox_estimatesitemscomputedrowsdocs.Items.Clear();
            comboBox_estimatesitemscomputedrowsdocs.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablecomputedrowsdocsRow r in dataSet01V.comboviewDataTablecomputedrowsdocs.Select("", "computedrowsdocs_name"))
            {
                comboBox_estimatesitemscomputedrowsdocs.Items.Add(new CLItemA(r.computedrowsdocs_id.ToString(), r.computedrowsdocs_name.ToString()));
            }
            comboBox_estimatesitemscomputedrowsdocs.SelectedIndex = 0;

            DateTime datemin = DateTime.Now;
            if(estimatesTableAdapter.ScalarQuery2() != null)
                datemin = estimatesTableAdapter.ScalarQuery2().Value;
            int yearmin = datemin.Year;
            DateTime datemax = DateTime.Now;
            if(estimatesTableAdapter.ScalarQuery3() != null)
                datemax = estimatesTableAdapter.ScalarQuery3().Value;
            int yearmax = datemax.Year;
            if (datemax.Year < DateTime.Now.Year)
                yearmax = DateTime.Now.Year;
            comboBox_filter_year.Items.Clear();
            comboBox_filter_year.Items.Add(new CLItemA("0", ""));
            for (int i = yearmin; i <= yearmax; i++)
            {
                comboBox_filter_year.Items.Add(i.ToString());
            }
            comboBox_filter_year.SelectedIndex = comboBox_filter_year.Items.Count-1;

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            tabControl_main.SelectedIndex = 0;

            loading = 0;
            reload_estimates();
        }

        private void FormEstimates_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormEstimates_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormEstimates_Load(sender, e);
        }

        private void FormEstimates_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (IS_ACTION == IS_EDIT)
            {
                setEditingMode_estimatesitems(false, true);
            }
            else
            {
                setEditingMode_estimatesitems(false, false);
            }

            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;
                button_Print.Enabled = false;

                if (tabControl_main.SelectedTab == tabPage1)
                {
                    button_Save.Enabled = true;
                    button_Undo.Enabled = true;
                    button_Stopedit.Enabled = false;
                }
                else
                {
                    button_Save.Enabled = false;
                    button_Undo.Enabled = false;
                    button_Stopedit.Enabled = true;
                }

                estimates_numberTextBox.ReadOnly = false;
                estimates_paymentstextTextBox.ReadOnly = false;
                estimates_customerstextTextBox.ReadOnly = false;
                estimates_userstextTextBox.ReadOnly = false;
                estimates_footerstextTextBox.ReadOnly = false;
                estimates_dateDateTimePicker.Enabled = true;
                estimates_deductiontaxTextBox.ReadOnly = false;
                customers_idComboBox.Enabled = true;
                comboBox_fillfrompayments.Enabled = true;
                comboBox_fillfromfootersdocs.Enabled = true;
                comboBox_taxesdeduction.Enabled = true;
                button_fillfrompayments.Enabled = true;
                button_fillfromcustomers.Enabled = true;
                button_fillfromusers.Enabled = true;
                button_fillfromfootersdocs.Enabled = true;

                dataGridView_main.Enabled = false;

                panel_filter.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;
                button_Print.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = false;

                estimates_numberTextBox.ReadOnly = true;
                estimates_paymentstextTextBox.ReadOnly = true;
                estimates_customerstextTextBox.ReadOnly = true;
                estimates_userstextTextBox.ReadOnly = true;
                estimates_footerstextTextBox.ReadOnly = true;
                estimates_dateDateTimePicker.Enabled = false;
                estimates_deductiontaxTextBox.ReadOnly = true;
                customers_idComboBox.Enabled = false;
                comboBox_fillfrompayments.Enabled = false;
                comboBox_fillfromfootersdocs.Enabled = false;
                comboBox_taxesdeduction.Enabled = false;
                button_fillfrompayments.Enabled = false;
                button_fillfromcustomers.Enabled = false;
                button_fillfromusers.Enabled = false;
                button_fillfromfootersdocs.Enabled = false;

                dataGridView_main.Enabled = true;

                panel_filter.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = false;
            tabPage1.Enabled = true;
            tabControl_main.SelectedIndex = 0;

            IS_ACTION = IS_NEW;
            setEditingMode(true);

            estimatesBindingSource.AddNew();

            DateTime datefrom = new DateTime(Convert.ToInt32(comboBox_filter_year.SelectedItem), 1, 1, 0, 0, 0);
            DateTime dateto = new DateTime(Convert.ToInt32(comboBox_filter_year.SelectedItem), 1, 1, 0, 0, 0).AddYears(1).AddTicks(-1);
            int estimates_number = 1;
            try
            {
                estimates_number = Convert.ToInt32(estimatesTableAdapter.ScalarQuery1(datefrom, dateto, (Convert.ToInt32(((CLItemA)comboBox_filter_users_id.SelectedItem).id))));
                estimates_number++;
            }
            catch { }
            estimates_numberTextBox.Text = estimates_number.ToString();

            estimates_deductiontaxTextBox.Text = "0";
            DataSet01STableAdapters.taxesdeductionTableAdapter t = new DataSet01STableAdapters.taxesdeductionTableAdapter();
            if (t.GetDataBy2().First()["taxesdeduction_id"].ToString().CompareTo(string.Empty) != 0)
            {
                if (t.GetDataBy2().First().taxesdeduction_default == 1)
                {
                    foreach (CLItemA item in comboBox_taxesdeduction.Items)
                    {
                        if (Convert.ToInt32(item.id) == t.GetDataBy2().First().taxesdeduction_id)
                        {
                            comboBox_taxesdeduction.SelectedItem = item;
                            break;
                        }
                    }
                }
            }

            customers_idComboBox.SelectedIndex = -1;
            
            if (comboBox_filter_users_id.SelectedIndex != -1)
                users_idComboBox.SelectedValue = Convert.ToInt32(((CLItemA)comboBox_filter_users_id.SelectedItem).id);

            estimates_dateDateTimePicker.Value = DateTime.Now;
            estimates_totalTextBox.Text = "0";
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (estimates_id != -1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                { 
                    if(tabControl_main.SelectedTab == tp)
                        tp.Enabled = true;
                    else
                        tp.Enabled = false;
                }
                
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (estimates_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    {
                        DataSet01STableAdapters.estimatesitemsTableAdapter t = new DataSet01STableAdapters.estimatesitemsTableAdapter();
                        DataSet01S.estimatesitemsDataTable d = t.GetDataBy1(estimates_id);
                        foreach (DataSet01S.estimatesitemsRow r in d.Select())
                        {
                            r.Delete();
                        }
                        t.Update(d);
                    }

                    estimatesBindingSource.RemoveCurrent();
                    estimatesTableAdapter.Update(dataSet01S.estimates);
                    dataSet01S.animals.AcceptChanges();

                    reload_estimates();
                }
            }
        }

        private void button_Print_Click(object sender, EventArgs e)
        {
            if (estimates_id != -1)
            {
                print_estimates(estimates_id);
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (users_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a user" + Environment.NewLine;
                return valid_b;
            }
            if (estimates_numberTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid number" + Environment.NewLine;
            }
            else
            {
                try
                {
                    int estimates_number = Convert.ToInt32(estimates_numberTextBox.Text);
                    DateTime datefrom = new DateTime(estimates_dateDateTimePicker.Value.Year, 1, 1, 0, 0, 0);
                    DateTime dateto = new DateTime(estimates_dateDateTimePicker.Value.Year, 1, 1, 0, 0, 0).AddYears(1).AddTicks(-1);
                    DataSet01STableAdapters.estimatesTableAdapter t = new DataSet01STableAdapters.estimatesTableAdapter();
                    if (t.GetDataBy4(estimates_number, Convert.ToInt32(users_idComboBox.SelectedValue), datefrom, dateto).Select().Count() > 0 && IS_ACTION == IS_NEW)
                    {
                        valid_b = false;
                        valid_s += "invoice number already exists" + Environment.NewLine;
                    }
                    if (t.GetDataBy4(estimates_number, Convert.ToInt32(users_idComboBox.SelectedValue), datefrom, dateto).Select("estimates_id <> " + estimates_id).Count() > 0 && IS_ACTION == IS_EDIT)
                    {
                        valid_b = false;
                        valid_s += "invoice number already exists" + Environment.NewLine;
                    }
                    if (estimates_number <= 0)
                    {
                        valid_b = false;
                        valid_s += "invalid number" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid number" + Environment.NewLine;
                }
            }
            if (estimates_deductiontaxTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid deduction tax" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(estimates_deductiontaxTextBox.Text);
                    if (d < 0 || d > 100)
                    {
                        valid_b = false;
                        valid_s += "invalid deduction tax" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid deduction tax" + Environment.NewLine;
                }
            }
            if (customers_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a customer" + Environment.NewLine;
            }
            if (estimates_userstextTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid user description" + Environment.NewLine;
            }
            if (estimates_customerstextTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid user description" + Environment.NewLine;
            }
            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            if (tabControl_main.SelectedTab == tabPage1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;

                string valid_s = string.Empty;
                if (!validateUpdate(ref valid_s))
                {
                    MessageBox.Show(valid_s);
                    return;
                }

                estimatesBindingSource.EndEdit();
                estimatesTableAdapter.Update(dataSet01S.estimates);
                dataSet01S.estimates.AcceptChanges();

                int sel_id = -1;
                switch (IS_ACTION)
                {
                    case IS_NEW:
                        sel_id = estimatesTableAdapter.ScalarQuery().Value;
                        break;
                    case IS_EDIT:
                        sel_id = estimates_id;
                        break;
                }

                IS_ACTION = IS_VIEW;
                setEditingMode(false);
                
                decimal totalnotax = 0;
                decimal totaltax = 0;
                decimal totaldeductiontax = 0;
                decimal total = 0;
                calculate_total(estimates_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
                textBox_estimatesitemstotalnotax.Text = totalnotax.ToString();
                textBox_estimatesitemstotaltax.Text = totaltax.ToString();
                textBox_estimatesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                textBox_estimatesitemstotal.Text = total.ToString();

                DataSet01STableAdapters.estimatesTableAdapter ttttt = new DataSet01STableAdapters.estimatesTableAdapter();
                DataSet01S.estimatesRow rrrrr = ttttt.GetData(estimates_id).First();
                rrrrr.estimates_total = total;
                ttttt.Update(rrrrr);

                reload_estimates();
                viewDataTableestimatesBindingSource.Position = viewDataTableestimatesBindingSource.Find("estimates_id", sel_id);
            }
            else if (tabControl_main.SelectedTab == tabPage2)
            {
                estimatesitems_Save();
            }
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            if (tabControl_main.SelectedTab == tabPage1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;

                estimatesBindingSource.CancelEdit();
                dataSet01S.estimates.RejectChanges();
                
                reload_estimates();
                viewDataTableestimatesBindingSource.Position = viewDataTableestimatesBindingSource.Find("estimates_id", estimates_id);

                IS_ACTION = IS_VIEW;
                setEditingMode(false);

                comboBox_taxesdeduction.SelectedIndex = -1;
                comboBox_fillfrompayments.SelectedIndex = -1;
                comboBox_fillfromfootersdocs.SelectedIndex = -1;
            }
            else if (tabControl_main.SelectedTab == tabPage2)
            {
                estimatesitems_Undo();
            }
        }

        private void button_Stopedit_Click(object sender, EventArgs e)
        {
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = true;

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            if (tabControl_main.SelectedTab == tabPage2)
            {
                int sel_id = estimates_id;
                reload_estimates();
                viewDataTableestimatesBindingSource.Position = viewDataTableestimatesBindingSource.Find("estimates_id", sel_id);
            }
        }

        #region pdf

        private void print_estimates(int estimates_id)
        {
            //delete old temp
            string tmplocation = "tmp";
            if (!Directory.Exists(tmplocation))
            {
                Directory.CreateDirectory(tmplocation);
            }
            DirectoryInfo di = new DirectoryInfo(tmplocation);
            FileInfo[] fis = di.GetFiles("*.*");
            foreach (FileInfo fi in fis)
            {
                try
                {
                    if (fi.LastWriteTime < DateTime.Now.AddDays(-1))
                        fi.Delete();
                }
                catch { }
            }

            DataSet01STableAdapters.estimatesTableAdapter t = new DataSet01STableAdapters.estimatesTableAdapter();
            DataSet01S.estimatesRow r = t.GetData(estimates_id).First();
            DataSet01STableAdapters.estimatesitemsTableAdapter tt = new DataSet01STableAdapters.estimatesitemsTableAdapter();
            DataSet01S.estimatesitemsDataTable dd = tt.GetDataBy1(estimates_id);

            //make new filename
            string pdffilename = string.Empty;
            do
            {
                pdffilename = tmplocation + "\\estimate_" + r.estimates_date.Year.ToString().PadLeft(4, '0') + "-" + r.estimates_date.Month.ToString().PadLeft(2, '0') + "-" + r.estimates_date.Day.ToString().PadLeft(2, '0') + "_" + r.estimates_number.ToString() + "_" + CLGeneric.make_random_string(12) + ".pdf";
            } while (File.Exists(pdffilename));

            //fill infos
            Document document = new Document(PageSize.A4);
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(pdffilename, FileMode.Create));
            writer.ViewerPreferences = PdfWriter.PageModeUseOutlines;
            PrintPageN printPageN = new PrintPageN();
            writer.PageEvent = printPageN;
            document.Open();

            iTextSharp.text.Font b10Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font b12Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font n10Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL);
            iTextSharp.text.Font n8Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 8, iTextSharp.text.Font.NORMAL);

            PdfPTable aTable = null;
            PdfPTable bTable = null;
            PdfPCell aCell = null;
            Phrase phrase = null;

            //title
            aTable = new PdfPTable(new float[] { 1 });
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatestitle"), b12Font));
            aCell = new PdfPCell(phrase);
            aCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aCell.PaddingBottom = 10;
            aCell.HorizontalAlignment = Element.ALIGN_CENTER;
            aTable.AddCell(aCell);
            document.Add(aTable);

            //info
            aTable = new PdfPTable(new float[] { 1, 1, 1});
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] { 250, aTable.TotalWidth - 400, 150});
            phrase = new Phrase();
            phrase.Add(new Chunk(r.estimates_userstext, n10Font));
            aTable.AddCell(phrase);
            aTable.AddCell(new Paragraph(" "));
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatesnumber") + ": ", b10Font));
            phrase.Add(new Chunk(r.estimates_number.ToString(), n10Font));
            phrase.Add(new Chunk("/", n10Font));
            phrase.Add(new Chunk(r.estimates_date.Year.ToString(), n10Font));
            phrase.Add(new Chunk("\n"));
            phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatesdate") + ": ", b10Font));
            phrase.Add(new Chunk(r.estimates_date.ToShortDateString(), n10Font));
            aTable.AddCell(phrase);
            document.Add(aTable);

            //to
            aTable = new PdfPTable(new float[] { 1, 1 });
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] {aTable.TotalWidth - 250, 250 });
            aTable.AddCell(new Paragraph(" "));
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("estimates_pdf_customerstext") + ":", b10Font));
            aCell = new PdfPCell(phrase);
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            aTable.AddCell(new Paragraph(""));
            phrase = new Phrase();
            phrase.Add(new Chunk(r.estimates_customerstext, n10Font));
            aTable.AddCell(phrase);
            document.Add(aTable);
            document.Add(new Paragraph(" "));

            //items
            aTable = new PdfPTable(new float[] { 1, 1, 1, 1});
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] { 70, aTable.TotalWidth - 210, 70, 70 });

            aCell = new PdfPCell(new Paragraph(Strings.T("estimates_pdf_thestimatescode"), b10Font));
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            aCell = new PdfPCell(new Paragraph(Strings.T("estimates_pdf_thestimatesdesc"), b10Font)); 
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            aCell = new PdfPCell(new Paragraph(Strings.T("estimates_pdf_thestimatesprice"), b10Font)); 
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            aCell = new PdfPCell(new Paragraph(Strings.T("estimates_pdf_thestimatestax"), b10Font));
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            aTable.AddCell(aCell);
            foreach (DataSet01S.estimatesitemsRow rr in dd.Select())
            {
                if (rr["estimatesitems_code"].ToString().CompareTo(string.Empty) != 0)
                    if(rr.estimatesitems_code.CompareTo(string.Empty) != 0)
                        aTable.AddCell(new Paragraph(rr.estimatesitems_code, n10Font));
                    else
                        aTable.AddCell(new Paragraph("/"));
                else
                    aTable.AddCell(new Paragraph("/"));
                aTable.AddCell(new Paragraph(rr.estimatesitems_desc, n10Font));
                aTable.AddCell(new Paragraph(rr.estimatesitems_price.ToString(), n10Font));
                if (rr.estimatesitems_tax != 0)
                    aTable.AddCell(new Paragraph(rr.estimatesitems_tax + "%", n10Font));
                else
                    aTable.AddCell(new Paragraph("/"));
            }
            document.Add(aTable);

            if (writer.GetVerticalPosition(false) < 220)
            {
                float currentvert = writer.GetVerticalPosition(false);
                document.Add(new Paragraph(" "));
                while (writer.GetVerticalPosition(false) < currentvert)
                    document.Add(new Paragraph(" "));
            }
            while (writer.GetVerticalPosition(false) > (float)220)
                document.Add(new Paragraph(" "));

            decimal totalnotax = 0;
            decimal totaltax = 0;
            decimal totaldeductiontax = 0;
            decimal total = 0;
            calculate_total(estimates_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);

            //payment
            aTable = new PdfPTable(new float[] { 1, 1 });
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] { aTable.TotalWidth / 2, aTable.TotalWidth / 2 });

            bTable = new PdfPTable(new float[] { 1 });
            bTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            bTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            bTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;

            if (r["estimates_paymentstext"].ToString().CompareTo(string.Empty) != 0)
            {
                if (r.estimates_paymentstext.Trim().ToString().CompareTo(string.Empty) != 0)
                {
                    phrase = new Phrase();
                    phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatespaymentext") + ":", b10Font));
                    aCell = new PdfPCell(phrase);
                    aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
                    aCell.PaddingBottom = 5;
                    bTable.AddCell(aCell);
                    bTable.AddCell(new Paragraph(""));
                    phrase = new Phrase();
                    phrase.Add(new Chunk(r.estimates_paymentstext, n10Font));
                    bTable.AddCell(phrase);
                }
            }

            aTable.AddCell(bTable);

            bTable = new PdfPTable(new float[] { 1 });
            bTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            bTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            bTable.DefaultCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatestotals") + ":", b10Font));
            aCell = new PdfPCell(phrase);
            aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
            aCell.PaddingBottom = 5;
            bTable.AddCell(aCell);
            bTable.AddCell(new Paragraph(""));

            phrase = new Phrase();

            List<decimal> taxvaluel = new List<decimal>();
            foreach (DataSet01S.estimatesitemsRow rr in dd.OrderByDescending(a => a.estimatesitems_tax))
            {
                if (rr["estimatesitems_tax"].ToString().CompareTo(string.Empty) != 0)
                {
                    if (!taxvaluel.Contains(Convert.ToDecimal(rr.estimatesitems_tax)))
                        taxvaluel.Add(Convert.ToDecimal(rr.estimatesitems_tax));
                }
            }

            phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatestotalnotax") + ": ", b10Font));
            foreach (decimal taxvalue in taxvaluel)
            {
                string valuestring = "";
                decimal valuetotal = 0;
                foreach (DataSet01S.estimatesitemsRow rr in dd.Select("estimatesitems_tax = '" + taxvalue + "'"))
                {
                    valuetotal += Convert.ToDecimal(rr.estimatesitems_price);
                }
                if (valuetotal != 0)
                {
                    valuestring += "(" + taxvalue.ToString() + "%) " + Math.Round(valuetotal, 2);
                    phrase.Add(new Chunk(valuestring.ToString() + "\n", n10Font));
                }
            }
            phrase.Add(new Chunk(totalnotax.ToString() + "\n", n10Font));

            phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatestotaltax") + ": ", b10Font));
            foreach (decimal taxvalue in taxvaluel)
            {
                string taxvaluestring = "";
                decimal taxvaluetotal = 0;
                foreach (DataSet01S.estimatesitemsRow rr in dd.Select("estimatesitems_tax = '" + taxvalue + "'"))
                {
                    taxvaluetotal += Convert.ToDecimal(rr.estimatesitems_price) * Convert.ToDecimal(rr.estimatesitems_tax) / 100;
                }
                if (taxvaluetotal != 0)
                {
                    taxvaluestring += "(" + taxvalue.ToString() + "%) " + Math.Round(taxvaluetotal, 2);
                    phrase.Add(new Chunk(taxvaluestring.ToString() + "\n", n10Font));
                }
            }
            phrase.Add(new Chunk(totaltax.ToString() + "\n", n10Font));

            bTable.AddCell(phrase);

            if (totaldeductiontax != 0)
            {
                decimal totalnodeductiontax = total - totaldeductiontax;

                phrase = new Phrase();
                
                phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatestotalnodeductiontax") + ": ", b10Font));
                phrase.Add(new Chunk(totalnodeductiontax.ToString() + "\n", n10Font));

                phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatestotaldeductiontax") + ": ", b10Font));
                phrase.Add(new Chunk("(" + Math.Round(Convert.ToDecimal(r["estimates_deductiontax"]), 2).ToString() + "%) " + totaldeductiontax.ToString() + "\n", n10Font));
            
                aCell = new PdfPCell(phrase);
                aCell.Border = iTextSharp.text.Rectangle.TOP_BORDER;
                aCell.HorizontalAlignment = Element.ALIGN_RIGHT;
                aCell.PaddingTop = 4;
                aCell.PaddingBottom = 4;
                bTable.AddCell(aCell);
            }

            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("estimates_pdf_estimatestotal") + ": ", b10Font));
            phrase.Add(new Chunk(total.ToString() + "\n", b10Font));
            aCell = new PdfPCell(phrase);
            aCell.Border = iTextSharp.text.Rectangle.TOP_BORDER;
            aCell.HorizontalAlignment = Element.ALIGN_RIGHT;
            aCell.PaddingTop = 4;
            aCell.PaddingBottom = 4;
            bTable.AddCell(aCell);

            aTable.AddCell(bTable);

            document.Add(aTable);

            //footer
            if(r["estimates_footerstext"].ToString().CompareTo(string.Empty) != 0)
            {
                aTable = new PdfPTable(new float[] { 1 });
                aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
                aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
                phrase = new Phrase();
                phrase.Add(new Chunk(r.estimates_footerstext, n8Font));
                aCell = new PdfPCell(phrase);
                aCell.Border = iTextSharp.text.Rectangle.TOP_BORDER;
                aCell.PaddingTop = 5;
                aTable.AddCell(aCell);
                document.Add(aTable);
            }            

            document.Close();

            try
            {
                Process.Start(pdffilename);
            }
            catch { }
        }

        #endregion

        private void viewDataTableestimatesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            estimates_id = -1;

            estimatesBindingSource.Filter = "estimates_id = -1";

            try
            {
                estimates_id = (int)((DataSet01V.viewDataTableestimatesRow)((DataRowView)viewDataTableestimatesBindingSource.Current).Row).estimates_id;
            }
            catch { }

            textBox_total.Text = "0";
            comboBox_taxesdeduction.SelectedIndex = -1;
            comboBox_fillfrompayments.SelectedIndex = -1;
            comboBox_fillfromfootersdocs.SelectedIndex = -1;
            customers_idComboBox.SelectedIndex = -1;
            estimates_dateDateTimePicker.Value = DateTime.Now;

            if (estimates_id != -1)
            {
                estimatesTableAdapter.Fill(dataSet01S.estimates, estimates_id);

                estimatesBindingSource.RemoveFilter();
                estimatesBindingSource.Position = estimatesBindingSource.Find("estimates_id", estimates_id);

                decimal estimates_total = 0;
                foreach (DataSet01V.viewDataTableestimatesRow r in dataSet01V.viewDataTableestimates)
                {
                    estimates_total += r.estimates_total;
                }
                textBox_total.Text = Math.Round(estimates_total, 2).ToString();

                decimal totalnotax = 0;
                decimal totaltax = 0;
                decimal totaldeductiontax = 0;
                decimal total = 0;
                calculate_total(estimates_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
                textBox_estimatesitemstotalnotax.Text = totalnotax.ToString();
                textBox_estimatesitemstotaltax.Text = totaltax.ToString();
                textBox_estimatesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                textBox_estimatesitemstotal.Text = total.ToString();
            }

            loading = 1;
            subviewDataTableestimatesitemsTableAdapter.Fill(dataSet01V.subviewDataTableestimatesitems, estimates_id);
            loading = 0;
            subviewDataTableestimatesitemsBindingSource_CurrentChanged(null, null);
        }

        private void reload_estimates()
        {
            load_estimates();
        }
        
        private void comboBox_filter_year_SelectedIndexChanged(object sender, EventArgs e)
        {
            load_estimates();
        }

        private void comboBox_filter_users_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            load_estimates();
        }

        private void load_estimates()
        {
            if (loading == 1)
                return;

            button_New.Enabled = false;
            button_Edit.Enabled = false;
            button_Delete.Enabled = false;
            button_Print.Enabled = false;
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = false;
            loading = 1;
            textBox_filter_number.Enabled = false;
            textBox_filter_customers.Enabled = false;
            textBox_filter_number.Text = string.Empty;
            textBox_filter_customers.Text = string.Empty;
            this.dataSet01V.viewDataTableestimates.Rows.Clear();
            if (comboBox_filter_year.SelectedIndex != -1 && comboBox_filter_year.SelectedIndex != 0
                &&
                comboBox_filter_users_id.SelectedIndex != -1 && comboBox_filter_users_id.SelectedIndex != 0)
            {
                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;
                button_Print.Enabled = true;
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;
                textBox_filter_number.Enabled = true;
                textBox_filter_customers.Enabled = true;
                DateTime datefrom = new DateTime(Convert.ToInt32(comboBox_filter_year.SelectedItem), 1, 1, 0, 0, 0);
                DateTime dateto = new DateTime(Convert.ToInt32(comboBox_filter_year.SelectedItem), 1, 1, 0, 0, 0).AddYears(1).AddTicks(-1);
                this.viewDataTableestimatesTableAdapter.Fill(this.dataSet01V.viewDataTableestimates, datefrom, dateto, (Convert.ToInt32(((CLItemA)comboBox_filter_users_id.SelectedItem).id)));
            }
            loading = 0;
            viewDataTableestimatesBindingSource_CurrentChanged(null, null);
        }

        private void tabControl_main_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!e.TabPage.Enabled)
                e.Cancel = true;
        }

        private void setFilter()
        {
            try
            {
                string filter_s = string.Empty;
                if (textBox_filter_number.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "estimates_number = '" + textBox_filter_number.Text + "'";
                }

                if (textBox_filter_customers.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "customers_alias LIKE '%" + textBox_filter_customers.Text + "%'";
                }

                viewDataTableestimatesBindingSource.Filter = filter_s;
            }
            catch { }
        }
        
        private void textBox_filter_number_TextChanged(object sender, EventArgs e)
        {
            setFilter();
        }

        private void textBox_filter_customers_TextChanged(object sender, EventArgs e)
        {
            setFilter();
        }

        private void button_fillfrompayments_Click(object sender, EventArgs e)
        {
            estimates_paymentstextTextBox.Text = "";
            if (comboBox_fillfrompayments.SelectedIndex != -1 && comboBox_fillfrompayments.SelectedIndex != 0)
            {
                DataSet01STableAdapters.paymentsTableAdapter t = new DataSet01STableAdapters.paymentsTableAdapter();
                DataSet01S.paymentsRow r = t.GetData(Convert.ToInt32(((CLItemA)comboBox_fillfrompayments.SelectedItem).id)).First();
                string s = string.Empty;
                if (r["payments_desc"].ToString().CompareTo(string.Empty) != 0)
                    if (r.payments_desc.CompareTo(string.Empty) != 0)
                        s += r.payments_desc;
                estimates_paymentstextTextBox.Text = s;
            }
        }

        private void button_fillfromcustomers_Click(object sender, EventArgs e)
        {
            estimates_customerstextTextBox.Text = "";
            if (customers_idComboBox.SelectedIndex != -1)
            {
                DataSet01STableAdapters.customersTableAdapter t = new DataSet01STableAdapters.customersTableAdapter();
                DataSet01S.customersRow r = t.GetData(Convert.ToInt32(customers_idComboBox.SelectedValue)).First();
                string s = string.Empty;
                if (r["customers_invoicestext"].ToString().CompareTo(string.Empty) != 0)
                    if (r.customers_invoicestext.CompareTo(string.Empty) != 0)
                        s += r.customers_invoicestext + Environment.NewLine;
                estimates_customerstextTextBox.Text = s;
            }
        }

        private void button_fillfromusers_Click(object sender, EventArgs e)
        {
            estimates_userstextTextBox.Text = "";
            if (users_idComboBox.SelectedIndex != -1)
            {
                DataSet01STableAdapters.usersTableAdapter t = new DataSet01STableAdapters.usersTableAdapter();
                DataSet01S.usersRow r = t.GetData(Convert.ToInt32(users_idComboBox.SelectedValue)).First();
                string s = string.Empty;
                if (r["users_invoicestext"].ToString().CompareTo(string.Empty) != 0)
                    if (r.users_invoicestext.CompareTo(string.Empty) != 0)
                        s += r.users_invoicestext + Environment.NewLine;
                estimates_userstextTextBox.Text = s;
            }
        }

        private void button_fillfromfootersdocs_Click(object sender, EventArgs e)
        {
            estimates_footerstextTextBox.Text = "";
            if (comboBox_fillfromfootersdocs.SelectedIndex != -1 && comboBox_fillfromfootersdocs.SelectedIndex != 0)
            {
                DataSet01STableAdapters.footersdocsTableAdapter t = new DataSet01STableAdapters.footersdocsTableAdapter();
                DataSet01S.footersdocsRow r = t.GetData(Convert.ToInt32(Convert.ToInt32(((CLItemA)comboBox_fillfromfootersdocs.SelectedItem).id))).First();
                string s = string.Empty;
                if (r["footersdocs_desc"].ToString().CompareTo(string.Empty) != 0)
                    if (r.footersdocs_desc.CompareTo(string.Empty) != 0)
                        s += r.footersdocs_desc + Environment.NewLine;
                estimates_footerstextTextBox.Text = s;
            }
        }

        private void comboBox_taxesdeduction_SelectedIndexChanged(object sender, EventArgs e)
        {
            estimates_deductiontaxTextBox.Text = "0";
            if (comboBox_taxesdeduction.SelectedIndex != -1 && comboBox_taxesdeduction.SelectedIndex != 0)
            {
                DataSet01STableAdapters.taxesdeductionTableAdapter t = new DataSet01STableAdapters.taxesdeductionTableAdapter();
                decimal deductiontax = t.GetData(Convert.ToInt32(((CLItemA)comboBox_taxesdeduction.SelectedItem).id)).First().taxesdeduction_percent;
                if (IS_ACTION == IS_NEW)
                {
                    estimates_deductiontaxTextBox.Text = deductiontax.ToString();
                }
                else if (IS_ACTION == IS_EDIT)
                {
                    ((DataSet01S.estimatesRow)((DataRowView)estimatesBindingSource.Current).Row).estimates_deductiontax = deductiontax;
                }

                decimal totalnotax = 0;
                decimal totaltax = 0;
                decimal totaldeductiontax = 0;
                decimal total = 0;
                calculate_total(estimates_id, deductiontax, out totalnotax, out totaltax, out totaldeductiontax, out total);
                textBox_estimatesitemstotalnotax.Text = totalnotax.ToString();
                textBox_estimatesitemstotaltax.Text = totaltax.ToString();
                textBox_estimatesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                textBox_estimatesitemstotal.Text = total.ToString();
                ((DataSet01S.estimatesRow)((DataRowView)estimatesBindingSource.Current).Row).estimates_total = total;
            }
        }

        private void estimates_numberTextBox_Leave(object sender, EventArgs e)
        {
            if (!estimates_numberTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToInt32(estimates_numberTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric integer value");
                }
            }
        }

        private void estimates_deductiontaxTextBox_Leave(object sender, EventArgs e)
        {
            if (!estimates_deductiontaxTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(estimates_deductiontaxTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }

        private void calculate_total(int estimates_id, decimal deductiontax, out decimal totalnotax, out decimal totaltax, out decimal totaldeductiontax, out decimal total)
        {
            totalnotax = 0;
            totaltax = 0;
            totaldeductiontax = 0;
            total = 0;

            if (estimates_id != -1)
            {
                DataSet01STableAdapters.estimatesTableAdapter t = new DataSet01STableAdapters.estimatesTableAdapter();
                DataSet01S.estimatesRow r = t.GetData(estimates_id).First();
                DataSet01STableAdapters.estimatesitemsTableAdapter tt = new DataSet01STableAdapters.estimatesitemsTableAdapter();
                DataSet01S.estimatesitemsDataTable dd = tt.GetDataBy1(estimates_id);

                decimal estimatesitems_totalnotax = 0;
                decimal estimatesitems_totaltax = 0;
                decimal estimatesitems_totaldeductiontax = 0;
                decimal estimatesitems_total = 0;
                decimal estimates_deductiontax = 0;
                if(deductiontax != 0)
                    estimates_deductiontax = deductiontax;
                else
                    estimates_deductiontax = r.estimates_deductiontax;

                foreach (DataSet01S.estimatesitemsRow rr in dd)
                {
                    decimal rowestimatesitems_price = 0;
                    decimal rowestimatesitems_tax = 0;
                    decimal rowestimatesitems_totaltax = 0;
                    decimal rowestimatesitems_totaldeduction = 0;
                    decimal rowestimatesitems_total = 0;
                    rowestimatesitems_price = Convert.ToDecimal(rr.estimatesitems_price);
                    if (rr["estimatesitems_tax"].ToString().CompareTo(string.Empty) != 0)
                        rowestimatesitems_tax = Convert.ToDecimal(rr.estimatesitems_tax);

                    rowestimatesitems_total = rowestimatesitems_price;
                    rowestimatesitems_totaltax = rowestimatesitems_price * rowestimatesitems_tax / 100;
                    rowestimatesitems_totaldeduction = rowestimatesitems_price * estimates_deductiontax / 100;

                    estimatesitems_totaltax += Math.Round(rowestimatesitems_totaltax, 2);
                    estimatesitems_totaldeductiontax += Math.Round(rowestimatesitems_totaldeduction, 2);
                    estimatesitems_totalnotax += Math.Round(rowestimatesitems_total, 2);
                    estimatesitems_total += Math.Round(rowestimatesitems_total + rowestimatesitems_totaltax - rowestimatesitems_totaldeduction, 2);
                }

                totalnotax = estimatesitems_totalnotax;
                totaltax = estimatesitems_totaltax;
                totaldeductiontax = estimatesitems_totaldeductiontax;
                total = estimatesitems_total;
            }
        }


        #region estimatesitems

        private void setEditingMode_estimatesitems(bool editing_mode, bool subediting_mode)
        {
            if (editing_mode)
            {
                button_estimatesitemsNew.Enabled = false;
                button_estimatesitemsEdit.Enabled = false;
                button_estimatesitemsDelete.Enabled = false;
                button_estimatesitemsAddcomputedrowsdocs.Enabled = false;
                comboBox_estimatesitemscomputedrowsdocs.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;
                button_Stopedit.Enabled = false;

                groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Enabled = true;
                groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Visible = true;
                comboBox_estimatesitemstaxes.Enabled = true;
                estimatesitems_codeTextBox.ReadOnly = false;
                estimatesitems_descTextBox.ReadOnly = false;
                estimatesitems_priceTextBox.ReadOnly = false;
                estimatesitems_taxTextBox.ReadOnly = false;

                dataGridView_estimatesitemsmain.Enabled = false;
            }
            else
            {
                if (subediting_mode)
                {
                    button_estimatesitemsNew.Enabled = true;
                    button_estimatesitemsEdit.Enabled = true;
                    button_estimatesitemsDelete.Enabled = true;
                    button_estimatesitemsAddcomputedrowsdocs.Enabled = true;
                    comboBox_estimatesitemscomputedrowsdocs.Enabled = true;
                }
                else
                {
                    button_estimatesitemsNew.Enabled = false;
                    button_estimatesitemsEdit.Enabled = false;
                    button_estimatesitemsDelete.Enabled = false;
                    button_estimatesitemsAddcomputedrowsdocs.Enabled = false;
                    comboBox_estimatesitemscomputedrowsdocs.Enabled = false;
                }

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = true;

                groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Enabled = false;
                groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Visible = false;
                comboBox_estimatesitemstaxes.Enabled = false;
                estimatesitems_codeTextBox.ReadOnly = true;
                estimatesitems_descTextBox.ReadOnly = true;
                estimatesitems_priceTextBox.ReadOnly = true;
                estimatesitems_taxTextBox.ReadOnly = true;

                dataGridView_estimatesitemsmain.Enabled = true;
            }
        }
        
        private void subviewDataTableestimatesitemsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            estimatesitems_id = -1;

            estimatesitemsBindingSource.Filter = "estimatesitems_id = -1";

            try
            {
                estimatesitems_id = (int)((DataSet01V.subviewDataTableestimatesitemsRow)((DataRowView)subviewDataTableestimatesitemsBindingSource.Current).Row).estimatesitems_id;
            }
            catch { }
            
            comboBox_estimatesitemscomputedrowsdocs.SelectedIndex = -1;
            comboBox_estimatesitemstaxes.SelectedIndex = -1;

            if (estimatesitems_id != -1)
            {
                estimatesitemsTableAdapter.Fill(dataSet01S.estimatesitems, estimatesitems_id);

                estimatesitemsBindingSource.RemoveFilter();
                estimatesitemsBindingSource.Position = estimatesitemsBindingSource.Find("estimatesitems_id", estimatesitems_id);
            }
        }

        private void button_estimatesitemsNew_Click(object sender, EventArgs e)
        {
            IS_ACTIONSUB = IS_NEW;
            setEditingMode_estimatesitems(true, true);

            estimatesitemsBindingSource.AddNew();

            estimatesitems_taxTextBox.Text = "0";
            DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
            if (t.GetDataBy2().First()["taxes_id"].ToString().CompareTo(string.Empty) != 0)
            {
                if (t.GetDataBy2().First().taxes_default == 1)
                {
                    foreach (CLItemA item in comboBox_estimatesitemstaxes.Items)
                    {
                        if (Convert.ToInt32(item.id) == t.GetDataBy2().First().taxes_id)
                        {
                            comboBox_estimatesitemstaxes.SelectedItem = item;
                            break;
                        }
                    }
                }
            }
            estimatesitems_priceTextBox.Text = "0";
        }

        private void button_estimatesitemsEdit_Click(object sender, EventArgs e)
        {
            if (estimatesitems_id != -1)
            {
                IS_ACTIONSUB = IS_EDIT;
                setEditingMode_estimatesitems(true, true);
            }
        }

        private void button_estimatesitemsDelete_Click(object sender, EventArgs e)
        {
            if (estimatesitems_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    estimatesitemsBindingSource.RemoveCurrent();
                    estimatesitemsTableAdapter.Update(dataSet01S.estimatesitems);
                    dataSet01S.animalstreatments.AcceptChanges();

                    subviewDataTableestimatesitemsTableAdapter.Fill(dataSet01V.subviewDataTableestimatesitems, estimates_id);

                    decimal totalnotax = 0;
                    decimal totaltax = 0;
                    decimal totaldeductiontax = 0;
                    decimal total = 0;
                    calculate_total(estimates_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
                    textBox_estimatesitemstotalnotax.Text = totalnotax.ToString();
                    textBox_estimatesitemstotaltax.Text = totaltax.ToString();
                    textBox_estimatesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                    textBox_estimatesitemstotal.Text = total.ToString();

                    DataSet01STableAdapters.estimatesTableAdapter ttttt = new DataSet01STableAdapters.estimatesTableAdapter();
                    DataSet01S.estimatesRow rrrrr = ttttt.GetData(estimates_id).First();
                    rrrrr.estimates_total = total;
                    ttttt.Update(rrrrr);
                }
            }
        }

        private bool validateUpdate_estimatesitems(ref string valid_s)
        {
            bool valid_b = true;

            if (estimatesitems_priceTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "select a price" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(estimatesitems_priceTextBox.Text);
                    if (d < 0)
                    {
                        valid_b = false;
                        valid_s += "invalid price" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid price" + Environment.NewLine;
                }
            }
            if (estimatesitems_taxTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid tax" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(estimatesitems_taxTextBox.Text);
                    if (d < 0 || d > 100)
                    {
                        valid_b = false;
                        valid_s += "invalid tax" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid tax" + Environment.NewLine;
                }
            }
            if (estimatesitems_descTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid description" + Environment.NewLine;
            }

            return valid_b;
        }

        private void estimatesitems_Save()
        {
            string valid_s = string.Empty;
            if (!validateUpdate_estimatesitems(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }

            ((DataSet01S.estimatesitemsRow)((DataRowView)estimatesitemsBindingSource.Current).Row).estimates_id = estimates_id;

            estimatesitemsBindingSource.EndEdit();
            estimatesitemsTableAdapter.Update(dataSet01S.estimatesitems);
            dataSet01S.estimatesitems.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTIONSUB)
            {
                case IS_NEW:
                    sel_id = estimatesitemsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = estimatesitems_id;
                    break;
            }

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_estimatesitems(false, true);

            subviewDataTableestimatesitemsTableAdapter.Fill(dataSet01V.subviewDataTableestimatesitems, estimates_id);
            subviewDataTableestimatesitemsBindingSource.Position = subviewDataTableestimatesitemsBindingSource.Find("estimatesitems_id", sel_id);

            decimal totalnotax = 0;
            decimal totaltax = 0;
            decimal totaldeductiontax = 0;
            decimal total = 0;
            calculate_total(estimates_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
            textBox_estimatesitemstotalnotax.Text = totalnotax.ToString();
            textBox_estimatesitemstotaltax.Text = totaltax.ToString();
            textBox_estimatesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
            textBox_estimatesitemstotal.Text = total.ToString();

            DataSet01STableAdapters.estimatesTableAdapter ttttt = new DataSet01STableAdapters.estimatesTableAdapter();
            DataSet01S.estimatesRow rrrrr = ttttt.GetData(estimates_id).First();
            rrrrr.estimates_total = total;
            ttttt.Update(rrrrr);
        }

        private void estimatesitems_Undo()
        {
            estimatesitemsBindingSource.CancelEdit();
            dataSet01S.estimatesitems.RejectChanges();

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_estimatesitems(false, true);

            comboBox_estimatesitemstaxes.SelectedIndex = -1;
            comboBox_estimatesitemscomputedrowsdocs.SelectedIndex = -1;
        }

        private void setFilter_estimatesitemsfillfromtreatments()
        {
            try
            {
                string filter_s = string.Empty;
                if (textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "treatments_code LIKE '%" + textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code.Text + "%'";
                }
                if (comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex != -1 && comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "treatmentscategories_id = '" + Convert.ToInt32(((CLItemA)comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedItem).id) + "'";
                }
                if (textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "treatments_name LIKE '%" + textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name.Text + "%'";
                }

                comboviewDataTabletreatmentsBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name_TextChanged(object sender, EventArgs e)
        {
            setFilter_estimatesitemsfillfromtreatments();
        }

        private void textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code_TextChanged(object sender, EventArgs e)
        {
            setFilter_estimatesitemsfillfromtreatments();
        }

        private void comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            setFilter_estimatesitemsfillfromtreatments();
        }

        private void button_estimatesitemsfillfromtreatments_Click(object sender, EventArgs e)
        {
            int treatments_id = -1;
            try
            {
                treatments_id = ((DataSet01V.comboviewDataTabletreatmentsRow)((DataRowView)comboviewDataTabletreatmentsBindingSource.Current).Row).treatments_id;
            }
            catch { }

            if (treatments_id != -1)
            {
                DataSet01STableAdapters.treatmentsTableAdapter t = new DataSet01STableAdapters.treatmentsTableAdapter();
                DataSet01S.treatmentsRow r = t.GetData(treatments_id).First();
                if (r["treatments_code"].ToString().CompareTo(string.Empty) != 0)
                {
                    estimatesitems_codeTextBox.Text = r.treatments_code.ToString();
                }
                if (r["treatments_desc"].ToString().CompareTo(string.Empty) != 0)
                {
                    estimatesitems_descTextBox.Text = r.treatments_desc.ToString();
                }
                if (r["treatments_price"].ToString().CompareTo(string.Empty) != 0)
                {
                    if (r.treatments_price > 0)
                    {
                        estimatesitems_priceTextBox.Text = r.treatments_price.ToString();
                    }
                }
                comboBox_estimatesitemstaxes.SelectedIndex = -1;
                if (r["taxes_id"].ToString().CompareTo(string.Empty) != 0)
                {
                    foreach (CLItemA item in comboBox_estimatesitemstaxes.Items)
                    { 
                        if(Convert.ToInt32(item.id) == r.taxes_id)
                        {
                            comboBox_estimatesitemstaxes.SelectedItem = item;
                            break;
                        }
                    }
                }
            }
        }

        private void comboBox_estimatesitemstaxes_SelectedIndexChanged(object sender, EventArgs e)
        {
            estimatesitems_taxTextBox.Text = "0";
            if (comboBox_estimatesitemstaxes.SelectedIndex != -1 && comboBox_estimatesitemstaxes.SelectedIndex != 0)
            {
                DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
                decimal tax = t.GetData(Convert.ToInt32(((CLItemA)comboBox_estimatesitemstaxes.SelectedItem).id)).First().taxes_percent;
                if (IS_ACTIONSUB == IS_NEW)
                {
                    estimatesitems_taxTextBox.Text = tax.ToString();
                }
                else if (IS_ACTIONSUB == IS_EDIT)
                {
                    ((DataSet01S.estimatesitemsRow)((DataRowView)estimatesitemsBindingSource.Current).Row).estimatesitems_tax = tax;
                }
            }
        }


        private void button_estimatesitemsAddcomputedrowsdocs_Click(object sender, EventArgs e)
        {
            if (comboBox_estimatesitemscomputedrowsdocs.SelectedIndex != -1 && comboBox_estimatesitemscomputedrowsdocs.SelectedIndex != 0)
            {
                IS_ACTIONSUB = IS_NEW;
                setEditingMode_estimatesitems(true, true);

                estimatesitemsBindingSource.AddNew();

                estimatesitems_taxTextBox.Text = "0";
                DataSet01STableAdapters.taxesTableAdapter t = new DataSet01STableAdapters.taxesTableAdapter();
                if (t.GetDataBy2().First()["taxes_id"].ToString().CompareTo(string.Empty) != 0)
                {
                    if (t.GetDataBy2().First().taxes_default == 1)
                    {
                        foreach (CLItemA item in comboBox_estimatesitemstaxes.Items)
                        {
                            if (Convert.ToInt32(item.id) == t.GetDataBy2().First().taxes_id)
                            {
                                comboBox_estimatesitemstaxes.SelectedItem = item;
                                break;
                            }
                        }
                    }
                }

                DataSet01STableAdapters.computedrowsdocsTableAdapter tt = new DataSet01STableAdapters.computedrowsdocsTableAdapter();
                decimal computedrowsdocs_percent = tt.GetData(Convert.ToInt32(((CLItemA)comboBox_estimatesitemscomputedrowsdocs.SelectedItem).id)).First().computedrowsdocs_percent;

                decimal totalnotax = 0;
                decimal totaltax = 0;
                decimal totaldeductiontax = 0;
                decimal total = 0;
                calculate_total(estimates_id, 0, out totalnotax, out totaltax, out totaldeductiontax, out total);
                textBox_estimatesitemstotalnotax.Text = totalnotax.ToString();
                textBox_estimatesitemstotaltax.Text = totaltax.ToString();
                textBox_estimatesitemstotaldeductiontax.Text = totaldeductiontax.ToString();
                textBox_estimatesitemstotal.Text = total.ToString();

                DataSet01STableAdapters.estimatesTableAdapter ttttt = new DataSet01STableAdapters.estimatesTableAdapter();
                DataSet01S.estimatesRow rrrrr = ttttt.GetData(estimates_id).First();
                rrrrr.estimates_total = total;
                ttttt.Update(rrrrr);

                estimatesitems_priceTextBox.Text = Math.Round(totalnotax * computedrowsdocs_percent / 100, 2).ToString();
                estimatesitems_descTextBox.Text = tt.GetData(Convert.ToInt32(((CLItemA)comboBox_estimatesitemscomputedrowsdocs.SelectedItem).id)).First().computedrowsdocs_name;
            }
        }
        
        private void estimatesitems_taxTextBox_Leave(object sender, EventArgs e)
        {
            if (!estimatesitems_taxTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(estimatesitems_taxTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }

        private void estimatesitems_priceTextBox_Leave(object sender, EventArgs e)
        {
            if (!estimatesitems_priceTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(estimatesitems_priceTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }

        #endregion

    }
}
