﻿namespace vettev
{
    partial class FormTreatments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label taxes_idLabel;
            System.Windows.Forms.Label treatments_durationLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTreatments));
            this.treatmentscategories_idLabel = new System.Windows.Forms.Label();
            this.treatments_codeLabel = new System.Windows.Forms.Label();
            this.treatments_nameLabel = new System.Windows.Forms.Label();
            this.treatments_descLabel = new System.Windows.Forms.Label();
            this.treatments_priceLabel = new System.Windows.Forms.Label();
            this.dataSet01S = new vettev.DataSet01S();
            this.dataSet01V = new vettev.DataSet01V();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button_notax = new System.Windows.Forms.Button();
            this.treatments_durationTextBox = new System.Windows.Forms.TextBox();
            this.treatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.treatments_priceTextBox = new System.Windows.Forms.TextBox();
            this.treatments_descTextBox = new System.Windows.Forms.TextBox();
            this.treatments_nameTextBox = new System.Windows.Forms.TextBox();
            this.treatments_codeTextBox = new System.Windows.Forms.TextBox();
            this.taxes_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTabletaxesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.treatmentscategories_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTabletreatmentscategoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_Edit = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.treatmentscodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentscategoriesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTabletreatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_New = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Undo = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel_filter = new System.Windows.Forms.Panel();
            this.textBox_filter_treatments_name = new System.Windows.Forms.TextBox();
            this.comboBox_filter_treatmentscategories_id = new System.Windows.Forms.ComboBox();
            this.textBox_filter_treatments_code = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_Delete = new System.Windows.Forms.Button();
            this.viewDataTabletreatmentsTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTabletreatmentsTableAdapter();
            this.treatmentsTableAdapter = new vettev.DataSet01STableAdapters.treatmentsTableAdapter();
            this.comboviewDataTabletreatmentscategoriesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletreatmentscategoriesTableAdapter();
            this.comboviewDataTabletaxesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletaxesTableAdapter();
            taxes_idLabel = new System.Windows.Forms.Label();
            treatments_durationLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treatmentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentscategoriesBindingSource)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTabletreatmentsBindingSource)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel_filter.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // taxes_idLabel
            // 
            taxes_idLabel.AutoSize = true;
            taxes_idLabel.Location = new System.Drawing.Point(110, 133);
            taxes_idLabel.Name = "taxes_idLabel";
            taxes_idLabel.Size = new System.Drawing.Size(24, 13);
            taxes_idLabel.TabIndex = 30;
            taxes_idLabel.Text = "tax:";
            // 
            // treatments_durationLabel
            // 
            treatments_durationLabel.AutoSize = true;
            treatments_durationLabel.Location = new System.Drawing.Point(13, 172);
            treatments_durationLabel.Name = "treatments_durationLabel";
            treatments_durationLabel.Size = new System.Drawing.Size(104, 13);
            treatments_durationLabel.TabIndex = 35;
            treatments_durationLabel.Text = "expiration (in month):";
            // 
            // treatmentscategories_idLabel
            // 
            this.treatmentscategories_idLabel.AutoSize = true;
            this.treatmentscategories_idLabel.Location = new System.Drawing.Point(10, 93);
            this.treatmentscategories_idLabel.Name = "treatmentscategories_idLabel";
            this.treatmentscategories_idLabel.Size = new System.Drawing.Size(51, 13);
            this.treatmentscategories_idLabel.TabIndex = 29;
            this.treatmentscategories_idLabel.Text = "category:";
            // 
            // treatments_codeLabel
            // 
            this.treatments_codeLabel.AutoSize = true;
            this.treatments_codeLabel.Location = new System.Drawing.Point(10, 15);
            this.treatments_codeLabel.Name = "treatments_codeLabel";
            this.treatments_codeLabel.Size = new System.Drawing.Size(34, 13);
            this.treatments_codeLabel.TabIndex = 31;
            this.treatments_codeLabel.Text = "code:";
            // 
            // treatments_nameLabel
            // 
            this.treatments_nameLabel.AutoSize = true;
            this.treatments_nameLabel.Location = new System.Drawing.Point(10, 54);
            this.treatments_nameLabel.Name = "treatments_nameLabel";
            this.treatments_nameLabel.Size = new System.Drawing.Size(36, 13);
            this.treatments_nameLabel.TabIndex = 32;
            this.treatments_nameLabel.Text = "name:";
            // 
            // treatments_descLabel
            // 
            this.treatments_descLabel.AutoSize = true;
            this.treatments_descLabel.Location = new System.Drawing.Point(13, 211);
            this.treatments_descLabel.Name = "treatments_descLabel";
            this.treatments_descLabel.Size = new System.Drawing.Size(61, 13);
            this.treatments_descLabel.TabIndex = 33;
            this.treatments_descLabel.Text = "description:";
            // 
            // treatments_priceLabel
            // 
            this.treatments_priceLabel.AutoSize = true;
            this.treatments_priceLabel.Location = new System.Drawing.Point(13, 133);
            this.treatments_priceLabel.Name = "treatments_priceLabel";
            this.treatments_priceLabel.Size = new System.Drawing.Size(33, 13);
            this.treatments_priceLabel.TabIndex = 34;
            this.treatments_priceLabel.Text = "price:";
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.Controls.Add(this.button_notax);
            this.panel6.Controls.Add(treatments_durationLabel);
            this.panel6.Controls.Add(this.treatments_durationTextBox);
            this.panel6.Controls.Add(this.treatments_priceLabel);
            this.panel6.Controls.Add(this.treatments_priceTextBox);
            this.panel6.Controls.Add(this.treatments_descLabel);
            this.panel6.Controls.Add(this.treatments_descTextBox);
            this.panel6.Controls.Add(this.treatments_nameLabel);
            this.panel6.Controls.Add(this.treatments_nameTextBox);
            this.panel6.Controls.Add(this.treatments_codeLabel);
            this.panel6.Controls.Add(this.treatments_codeTextBox);
            this.panel6.Controls.Add(taxes_idLabel);
            this.panel6.Controls.Add(this.taxes_idComboBox);
            this.panel6.Controls.Add(this.treatmentscategories_idLabel);
            this.panel6.Controls.Add(this.treatmentscategories_idComboBox);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(300, 422);
            this.panel6.TabIndex = 1;
            // 
            // button_notax
            // 
            this.button_notax.Location = new System.Drawing.Point(215, 146);
            this.button_notax.Name = "button_notax";
            this.button_notax.Size = new System.Drawing.Size(73, 23);
            this.button_notax.TabIndex = 37;
            this.button_notax.Text = "No Tax";
            this.button_notax.UseVisualStyleBackColor = true;
            this.button_notax.Click += new System.EventHandler(this.button_notax_Click);
            // 
            // treatments_durationTextBox
            // 
            this.treatments_durationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.treatmentsBindingSource, "treatments_duration", true));
            this.treatments_durationTextBox.Location = new System.Drawing.Point(16, 188);
            this.treatments_durationTextBox.MaxLength = 2;
            this.treatments_durationTextBox.Name = "treatments_durationTextBox";
            this.treatments_durationTextBox.Size = new System.Drawing.Size(30, 20);
            this.treatments_durationTextBox.TabIndex = 36;
            this.treatments_durationTextBox.Leave += new System.EventHandler(this.treatments_durationTextBox_Leave);
            // 
            // treatmentsBindingSource
            // 
            this.treatmentsBindingSource.DataMember = "treatments";
            this.treatmentsBindingSource.DataSource = this.dataSet01S;
            // 
            // treatments_priceTextBox
            // 
            this.treatments_priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.treatmentsBindingSource, "treatments_price", true));
            this.treatments_priceTextBox.Location = new System.Drawing.Point(16, 149);
            this.treatments_priceTextBox.MaxLength = 11;
            this.treatments_priceTextBox.Name = "treatments_priceTextBox";
            this.treatments_priceTextBox.Size = new System.Drawing.Size(70, 20);
            this.treatments_priceTextBox.TabIndex = 35;
            this.treatments_priceTextBox.Leave += new System.EventHandler(this.treatments_priceTextBox_Leave);
            // 
            // treatments_descTextBox
            // 
            this.treatments_descTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.treatmentsBindingSource, "treatments_desc", true));
            this.treatments_descTextBox.Location = new System.Drawing.Point(16, 227);
            this.treatments_descTextBox.Multiline = true;
            this.treatments_descTextBox.Name = "treatments_descTextBox";
            this.treatments_descTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.treatments_descTextBox.Size = new System.Drawing.Size(272, 50);
            this.treatments_descTextBox.TabIndex = 34;
            // 
            // treatments_nameTextBox
            // 
            this.treatments_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.treatmentsBindingSource, "treatments_name", true));
            this.treatments_nameTextBox.Location = new System.Drawing.Point(13, 70);
            this.treatments_nameTextBox.MaxLength = 100;
            this.treatments_nameTextBox.Name = "treatments_nameTextBox";
            this.treatments_nameTextBox.Size = new System.Drawing.Size(275, 20);
            this.treatments_nameTextBox.TabIndex = 33;
            // 
            // treatments_codeTextBox
            // 
            this.treatments_codeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.treatmentsBindingSource, "treatments_code", true));
            this.treatments_codeTextBox.Location = new System.Drawing.Point(13, 31);
            this.treatments_codeTextBox.MaxLength = 15;
            this.treatments_codeTextBox.Name = "treatments_codeTextBox";
            this.treatments_codeTextBox.Size = new System.Drawing.Size(100, 20);
            this.treatments_codeTextBox.TabIndex = 32;
            // 
            // taxes_idComboBox
            // 
            this.taxes_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.treatmentsBindingSource, "taxes_id", true));
            this.taxes_idComboBox.DataSource = this.comboviewDataTabletaxesBindingSource;
            this.taxes_idComboBox.DisplayMember = "taxes_name";
            this.taxes_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.taxes_idComboBox.FormattingEnabled = true;
            this.taxes_idComboBox.Location = new System.Drawing.Point(109, 148);
            this.taxes_idComboBox.Name = "taxes_idComboBox";
            this.taxes_idComboBox.Size = new System.Drawing.Size(100, 21);
            this.taxes_idComboBox.TabIndex = 31;
            this.taxes_idComboBox.ValueMember = "taxes_id";
            // 
            // comboviewDataTabletaxesBindingSource
            // 
            this.comboviewDataTabletaxesBindingSource.DataMember = "comboviewDataTabletaxes";
            this.comboviewDataTabletaxesBindingSource.DataSource = this.dataSet01V;
            // 
            // treatmentscategories_idComboBox
            // 
            this.treatmentscategories_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.treatmentsBindingSource, "treatmentscategories_id", true));
            this.treatmentscategories_idComboBox.DataSource = this.comboviewDataTabletreatmentscategoriesBindingSource;
            this.treatmentscategories_idComboBox.DisplayMember = "treatmentscategories_name";
            this.treatmentscategories_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.treatmentscategories_idComboBox.FormattingEnabled = true;
            this.treatmentscategories_idComboBox.Location = new System.Drawing.Point(13, 109);
            this.treatmentscategories_idComboBox.Name = "treatmentscategories_idComboBox";
            this.treatmentscategories_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.treatmentscategories_idComboBox.TabIndex = 30;
            this.treatmentscategories_idComboBox.ValueMember = "treatmentscategories_id";
            // 
            // comboviewDataTabletreatmentscategoriesBindingSource
            // 
            this.comboviewDataTabletreatmentscategoriesBindingSource.DataMember = "comboviewDataTabletreatmentscategories";
            this.comboviewDataTabletreatmentscategoriesBindingSource.DataSource = this.dataSet01V;
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 35);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(384, 387);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.treatmentscodeDataGridViewTextBoxColumn,
            this.treatmentscategoriesnameDataGridViewTextBoxColumn,
            this.treatmentsnameDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTabletreatmentsBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(384, 387);
            this.dataGridView_main.TabIndex = 0;
            // 
            // treatmentscodeDataGridViewTextBoxColumn
            // 
            this.treatmentscodeDataGridViewTextBoxColumn.DataPropertyName = "treatments_code";
            this.treatmentscodeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.treatmentscodeDataGridViewTextBoxColumn.Name = "treatmentscodeDataGridViewTextBoxColumn";
            this.treatmentscodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentscodeDataGridViewTextBoxColumn.Width = 80;
            // 
            // treatmentscategoriesnameDataGridViewTextBoxColumn
            // 
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.DataPropertyName = "treatmentscategories_name";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.HeaderText = "Category";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.Name = "treatmentscategoriesnameDataGridViewTextBoxColumn";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.Width = 120;
            // 
            // treatmentsnameDataGridViewTextBoxColumn
            // 
            this.treatmentsnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.treatmentsnameDataGridViewTextBoxColumn.DataPropertyName = "treatments_name";
            this.treatmentsnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.treatmentsnameDataGridViewTextBoxColumn.Name = "treatmentsnameDataGridViewTextBoxColumn";
            this.treatmentsnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTabletreatmentsBindingSource
            // 
            this.viewDataTabletreatmentsBindingSource.DataMember = "viewDataTabletreatments";
            this.viewDataTabletreatmentsBindingSource.DataSource = this.dataSet01V;
            this.viewDataTabletreatmentsBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTabletreatmentsBindingSource_CurrentChanged);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(384, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 462);
            this.panel2.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 422);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 462);
            this.panel1.TabIndex = 4;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel_filter);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(384, 35);
            this.panel7.TabIndex = 3;
            // 
            // panel_filter
            // 
            this.panel_filter.Controls.Add(this.textBox_filter_treatments_name);
            this.panel_filter.Controls.Add(this.comboBox_filter_treatmentscategories_id);
            this.panel_filter.Controls.Add(this.textBox_filter_treatments_code);
            this.panel_filter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filter.Location = new System.Drawing.Point(0, 0);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new System.Drawing.Size(384, 35);
            this.panel_filter.TabIndex = 3;
            // 
            // textBox_filter_treatments_name
            // 
            this.textBox_filter_treatments_name.Location = new System.Drawing.Point(201, 12);
            this.textBox_filter_treatments_name.Name = "textBox_filter_treatments_name";
            this.textBox_filter_treatments_name.Size = new System.Drawing.Size(100, 20);
            this.textBox_filter_treatments_name.TabIndex = 32;
            this.textBox_filter_treatments_name.TextChanged += new System.EventHandler(this.textBox_filter_treatments_name_TextChanged);
            // 
            // comboBox_filter_treatmentscategories_id
            // 
            this.comboBox_filter_treatmentscategories_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_filter_treatmentscategories_id.FormattingEnabled = true;
            this.comboBox_filter_treatmentscategories_id.Location = new System.Drawing.Point(80, 11);
            this.comboBox_filter_treatmentscategories_id.Name = "comboBox_filter_treatmentscategories_id";
            this.comboBox_filter_treatmentscategories_id.Size = new System.Drawing.Size(100, 21);
            this.comboBox_filter_treatmentscategories_id.TabIndex = 31;
            this.comboBox_filter_treatmentscategories_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_treatmentscategories_id_SelectedIndexChanged);
            // 
            // textBox_filter_treatments_code
            // 
            this.textBox_filter_treatments_code.Location = new System.Drawing.Point(3, 12);
            this.textBox_filter_treatments_code.Name = "textBox_filter_treatments_code";
            this.textBox_filter_treatments_code.Size = new System.Drawing.Size(71, 20);
            this.textBox_filter_treatments_code.TabIndex = 1;
            this.textBox_filter_treatments_code.TextChanged += new System.EventHandler(this.textBox_filter_treatments_TextChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 422);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 40);
            this.panel4.TabIndex = 1;
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // viewDataTabletreatmentsTableAdapter
            // 
            this.viewDataTabletreatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // treatmentsTableAdapter
            // 
            this.treatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletreatmentscategoriesTableAdapter
            // 
            this.comboviewDataTabletreatmentscategoriesTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletaxesTableAdapter
            // 
            this.comboviewDataTabletaxesTableAdapter.ClearBeforeFill = true;
            // 
            // FormTreatments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(684, 462);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormTreatments";
            this.Text = "Treatments";
            this.Activated += new System.EventHandler(this.FormTreatments_Activated);
            this.Deactivate += new System.EventHandler(this.FormTreatments_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormTreatments_FormClosing);
            this.Load += new System.EventHandler(this.FormTreatments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.treatmentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentscategoriesBindingSource)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTabletreatmentsBindingSource)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel_filter.ResumeLayout(false);
            this.panel_filter.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox_filter_treatments_code;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.BindingSource viewDataTabletreatmentsBindingSource;
        private DataSet01VTableAdapters.viewDataTabletreatmentsTableAdapter viewDataTabletreatmentsTableAdapter;
        private System.Windows.Forms.BindingSource treatmentsBindingSource;
        private DataSet01STableAdapters.treatmentsTableAdapter treatmentsTableAdapter;
        private System.Windows.Forms.TextBox treatments_priceTextBox;
        private System.Windows.Forms.TextBox treatments_descTextBox;
        private System.Windows.Forms.TextBox treatments_nameTextBox;
        private System.Windows.Forms.TextBox treatments_codeTextBox;
        private System.Windows.Forms.ComboBox taxes_idComboBox;
        private System.Windows.Forms.ComboBox treatmentscategories_idComboBox;
        private System.Windows.Forms.ComboBox comboBox_filter_treatmentscategories_id;
        private System.Windows.Forms.Label treatmentscategories_idLabel;
        private System.Windows.Forms.Label treatments_codeLabel;
        private System.Windows.Forms.Label treatments_nameLabel;
        private System.Windows.Forms.Label treatments_descLabel;
        private System.Windows.Forms.Label treatments_priceLabel;
        private System.Windows.Forms.BindingSource comboviewDataTabletreatmentscategoriesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletreatmentscategoriesTableAdapter comboviewDataTabletreatmentscategoriesTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTabletaxesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletaxesTableAdapter comboviewDataTabletaxesTableAdapter;
        private System.Windows.Forms.TextBox treatments_durationTextBox;
        private System.Windows.Forms.Panel panel_filter;
        private System.Windows.Forms.TextBox textBox_filter_treatments_name;
        private System.Windows.Forms.Button button_notax;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscategoriesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentsnameDataGridViewTextBoxColumn;
    }
}