﻿namespace vettev
{
    partial class FormInvoices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label invoices_numberLabel;
            System.Windows.Forms.Label invoices_dateLabel;
            System.Windows.Forms.Label invoices_paymentstextLabel;
            System.Windows.Forms.Label invoices_customerstextLabel;
            System.Windows.Forms.Label paystatus_idLabel1;
            System.Windows.Forms.Label invoices_totalLabel;
            System.Windows.Forms.Label customers_idLabel;
            System.Windows.Forms.Label users_idLabel2;
            System.Windows.Forms.Label invoices_userstextLabel;
            System.Windows.Forms.Label invoicespayments_dateLabel;
            System.Windows.Forms.Label invoicespayments_notesLabel;
            System.Windows.Forms.Label invoicespayments_totalLabel;
            System.Windows.Forms.Label invoicesitems_taxLabel;
            System.Windows.Forms.Label invoicesitems_descLabel;
            System.Windows.Forms.Label invoicesitems_codeLabel;
            System.Windows.Forms.Label invoicesitems_priceLabel;
            System.Windows.Forms.Label invoicesitems_idLabel;
            System.Windows.Forms.Label invoices_footerstextLabel;
            System.Windows.Forms.Label invoices_deductiontaxLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormInvoices));
            this.tabControl_main = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox_taxesdeduction = new System.Windows.Forms.ComboBox();
            this.invoices_deductiontaxTextBox = new System.Windows.Forms.TextBox();
            this.invoicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01S = new vettev.DataSet01S();
            this.comboBox_fillfromfootersdocs = new System.Windows.Forms.ComboBox();
            this.button_fillfromfootersdocs = new System.Windows.Forms.Button();
            this.invoices_footerstextTextBox = new System.Windows.Forms.TextBox();
            this.button_fillfromusers = new System.Windows.Forms.Button();
            this.invoices_userstextTextBox = new System.Windows.Forms.TextBox();
            this.users_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTableusersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01V = new vettev.DataSet01V();
            this.button_fillfromcustomers = new System.Windows.Forms.Button();
            this.customers_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTablecustomersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_fillfrompayments = new System.Windows.Forms.Button();
            this.comboBox_fillfrompayments = new System.Windows.Forms.ComboBox();
            this.invoices_totalTextBox = new System.Windows.Forms.TextBox();
            this.paystatus_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTablepaystatusBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.invoices_customerstextTextBox = new System.Windows.Forms.TextBox();
            this.invoices_paymentstextTextBox = new System.Windows.Forms.TextBox();
            this.invoices_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.invoices_numberTextBox = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dataGridView_invoicestreatmentsmain = new System.Windows.Forms.DataGridView();
            this.animalstreatmentsdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalstreatmentsdescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paystatusnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTableinvoicestreatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel9 = new System.Windows.Forms.Panel();
            this.dataGridView_invoicestreatmentsinvoiceable = new System.Windows.Forms.DataGridView();
            this.animalsnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalstreatmentsdateDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalstreatmentsdescDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comboviewDataTableanimalstreatmentsinvoiceableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_invoicestreatmentsMarkPaied = new System.Windows.Forms.Button();
            this.button_invoicestreatmentsRemove = new System.Windows.Forms.Button();
            this.button_invoicestreatmentsAdd = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel14 = new System.Windows.Forms.Panel();
            this.dataGridView_invoicesitemsmain = new System.Windows.Forms.DataGridView();
            this.invoicesitemsidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoicesitemscodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoicesitemsdescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoicesitemspriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTableinvoicesitemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel13 = new System.Windows.Forms.Panel();
            this.button_invoicesitemsAddcomputedrowsdocs = new System.Windows.Forms.Button();
            this.comboBox_invoicesitemscomputedrowsdocs = new System.Windows.Forms.ComboBox();
            this.invoicesitems_idTextBox = new System.Windows.Forms.TextBox();
            this.invoicesitemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_invoicesitemstotalnotax = new System.Windows.Forms.TextBox();
            this.textBox_invoicesitemstotal = new System.Windows.Forms.TextBox();
            this.comboBox_invoicesitemstaxes = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_invoicesitemstotaltax = new System.Windows.Forms.TextBox();
            this.invoicesitems_priceTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.invoicesitems_codeTextBox = new System.Windows.Forms.TextBox();
            this.textBox_invoicesitemstotaldeductiontax = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.invoicesitems_descTextBox = new System.Windows.Forms.TextBox();
            this.button_invoicesitemsLoadfromtreatments = new System.Windows.Forms.Button();
            this.button_invoicesitemsDelete = new System.Windows.Forms.Button();
            this.button_invoicesitemsEdit = new System.Windows.Forms.Button();
            this.invoicesitems_taxTextBox = new System.Windows.Forms.TextBox();
            this.button_invoicesitemsNew = new System.Windows.Forms.Button();
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments = new System.Windows.Forms.GroupBox();
            this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id = new System.Windows.Forms.ComboBox();
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name = new System.Windows.Forms.TextBox();
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code = new System.Windows.Forms.TextBox();
            this.dataGridView_invoicesitemsfillfromtreatmentsmain = new System.Windows.Forms.DataGridView();
            this.treatmentscodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentscategoriesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentsdescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comboviewDataTabletreatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_invoicesitemsfillfromtreatments = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.dataGridView_invoicespaymentsmain = new System.Windows.Forms.DataGridView();
            this.invoicespaymentsdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoicespaymentstotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTableinvoicespaymentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel10 = new System.Windows.Forms.Panel();
            this.textBox_invoicespaymentstotal = new System.Windows.Forms.TextBox();
            this.invoicespayments_totalTextBox = new System.Windows.Forms.TextBox();
            this.invoicespaymentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.invoicespayments_notesTextBox = new System.Windows.Forms.TextBox();
            this.button_invoicespaymentsDelete = new System.Windows.Forms.Button();
            this.button_invoicespaymentsEdit = new System.Windows.Forms.Button();
            this.invoicespayments_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.button_invoicespaymentsNew = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_New = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox_totalpaid = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_total = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button_Print = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox_filter_year = new System.Windows.Forms.ComboBox();
            this.button_Undo = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel_filter = new System.Windows.Forms.Panel();
            this.textBox_filter_customers = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_filter_users_id = new System.Windows.Forms.ComboBox();
            this.textBox_filter_number = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.invoicesnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoicesdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customersaliasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paystatusnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoicestotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTableinvoicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_Save = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Stopedit = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.viewDataTableinvoicesTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTableinvoicesTableAdapter();
            this.invoicesTableAdapter = new vettev.DataSet01STableAdapters.invoicesTableAdapter();
            this.comboviewDataTablecustomersTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablecustomersTableAdapter();
            this.comboviewDataTablepaystatusTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablepaystatusTableAdapter();
            this.comboviewDataTablepaymentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTablepaymentsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablepaymentsTableAdapter();
            this.invoicesitemsTableAdapter = new vettev.DataSet01STableAdapters.invoicesitemsTableAdapter();
            this.comboviewDataTableusersTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTableusersTableAdapter();
            this.invoicespaymentsTableAdapter = new vettev.DataSet01STableAdapters.invoicespaymentsTableAdapter();
            this.subviewDataTableinvoicespaymentsTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableinvoicespaymentsTableAdapter();
            this.comboviewDataTableanimalstreatmentsinvoiceableTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTableanimalstreatmentsinvoiceableTableAdapter();
            this.subviewDataTableinvoicestreatmentsTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableinvoicestreatmentsTableAdapter();
            this.comboviewDataTabletaxesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTabletaxesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletaxesTableAdapter();
            this.subviewDataTableinvoicesitemsTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableinvoicesitemsTableAdapter();
            this.comboviewDataTabletreatmentsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletreatmentsTableAdapter();
            this.comboviewDataTabletreatmentscategoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTabletreatmentscategoriesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletreatmentscategoriesTableAdapter();
            this.comboviewDataTablefootersdocsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTablefootersdocsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablefootersdocsTableAdapter();
            this.comboviewDataTabletaxesdeductionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTabletaxesdeductionTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletaxesdeductionTableAdapter();
            this.comboviewDataTablecomputedrowsdocsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTablecomputedrowsdocsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablecomputedrowsdocsTableAdapter();
            invoices_numberLabel = new System.Windows.Forms.Label();
            invoices_dateLabel = new System.Windows.Forms.Label();
            invoices_paymentstextLabel = new System.Windows.Forms.Label();
            invoices_customerstextLabel = new System.Windows.Forms.Label();
            paystatus_idLabel1 = new System.Windows.Forms.Label();
            invoices_totalLabel = new System.Windows.Forms.Label();
            customers_idLabel = new System.Windows.Forms.Label();
            users_idLabel2 = new System.Windows.Forms.Label();
            invoices_userstextLabel = new System.Windows.Forms.Label();
            invoicespayments_dateLabel = new System.Windows.Forms.Label();
            invoicespayments_notesLabel = new System.Windows.Forms.Label();
            invoicespayments_totalLabel = new System.Windows.Forms.Label();
            invoicesitems_taxLabel = new System.Windows.Forms.Label();
            invoicesitems_descLabel = new System.Windows.Forms.Label();
            invoicesitems_codeLabel = new System.Windows.Forms.Label();
            invoicesitems_priceLabel = new System.Windows.Forms.Label();
            invoicesitems_idLabel = new System.Windows.Forms.Label();
            invoices_footerstextLabel = new System.Windows.Forms.Label();
            invoices_deductiontaxLabel = new System.Windows.Forms.Label();
            this.tabControl_main.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableusersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecustomersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablepaystatusBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicestreatmentsmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableinvoicestreatmentsBindingSource)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicestreatmentsinvoiceable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableanimalstreatmentsinvoiceableBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicesitemsmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableinvoicesitemsBindingSource)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoicesitemsBindingSource)).BeginInit();
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicesitemsfillfromtreatmentsmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentsBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicespaymentsmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableinvoicespaymentsBindingSource)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoicespaymentsBindingSource)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel_filter.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableinvoicesBindingSource)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablepaymentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentscategoriesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablefootersdocsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesdeductionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecomputedrowsdocsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // invoices_numberLabel
            // 
            invoices_numberLabel.AutoSize = true;
            invoices_numberLabel.Location = new System.Drawing.Point(10, 12);
            invoices_numberLabel.Name = "invoices_numberLabel";
            invoices_numberLabel.Size = new System.Drawing.Size(45, 13);
            invoices_numberLabel.TabIndex = 0;
            invoices_numberLabel.Text = "number:";
            // 
            // invoices_dateLabel
            // 
            invoices_dateLabel.AutoSize = true;
            invoices_dateLabel.Location = new System.Drawing.Point(127, 12);
            invoices_dateLabel.Name = "invoices_dateLabel";
            invoices_dateLabel.Size = new System.Drawing.Size(31, 13);
            invoices_dateLabel.TabIndex = 2;
            invoices_dateLabel.Text = "date:";
            // 
            // invoices_paymentstextLabel
            // 
            invoices_paymentstextLabel.AutoSize = true;
            invoices_paymentstextLabel.Location = new System.Drawing.Point(10, 269);
            invoices_paymentstextLabel.Name = "invoices_paymentstextLabel";
            invoices_paymentstextLabel.Size = new System.Drawing.Size(104, 13);
            invoices_paymentstextLabel.TabIndex = 4;
            invoices_paymentstextLabel.Text = "payment description:";
            // 
            // invoices_customerstextLabel
            // 
            invoices_customerstextLabel.AutoSize = true;
            invoices_customerstextLabel.Location = new System.Drawing.Point(10, 200);
            invoices_customerstextLabel.Name = "invoices_customerstextLabel";
            invoices_customerstextLabel.Size = new System.Drawing.Size(107, 13);
            invoices_customerstextLabel.TabIndex = 6;
            invoices_customerstextLabel.Text = "customer description:";
            // 
            // paystatus_idLabel1
            // 
            paystatus_idLabel1.AutoSize = true;
            paystatus_idLabel1.Location = new System.Drawing.Point(12, 500);
            paystatus_idLabel1.Name = "paystatus_idLabel1";
            paystatus_idLabel1.Size = new System.Drawing.Size(81, 13);
            paystatus_idLabel1.TabIndex = 8;
            paystatus_idLabel1.Text = "payment status:";
            // 
            // invoices_totalLabel
            // 
            invoices_totalLabel.AutoSize = true;
            invoices_totalLabel.Location = new System.Drawing.Point(514, 12);
            invoices_totalLabel.Name = "invoices_totalLabel";
            invoices_totalLabel.Size = new System.Drawing.Size(30, 13);
            invoices_totalLabel.TabIndex = 10;
            invoices_totalLabel.Text = "total:";
            // 
            // customers_idLabel
            // 
            customers_idLabel.AutoSize = true;
            customers_idLabel.Location = new System.Drawing.Point(9, 160);
            customers_idLabel.Name = "customers_idLabel";
            customers_idLabel.Size = new System.Drawing.Size(53, 13);
            customers_idLabel.TabIndex = 14;
            customers_idLabel.Text = "customer:";
            // 
            // users_idLabel2
            // 
            users_idLabel2.AutoSize = true;
            users_idLabel2.Location = new System.Drawing.Point(10, 51);
            users_idLabel2.Name = "users_idLabel2";
            users_idLabel2.Size = new System.Drawing.Size(30, 13);
            users_idLabel2.TabIndex = 17;
            users_idLabel2.Text = "user:";
            // 
            // invoices_userstextLabel
            // 
            invoices_userstextLabel.AutoSize = true;
            invoices_userstextLabel.Location = new System.Drawing.Point(9, 91);
            invoices_userstextLabel.Name = "invoices_userstextLabel";
            invoices_userstextLabel.Size = new System.Drawing.Size(84, 13);
            invoices_userstextLabel.TabIndex = 19;
            invoices_userstextLabel.Text = "user description:";
            // 
            // invoicespayments_dateLabel
            // 
            invoicespayments_dateLabel.AutoSize = true;
            invoicespayments_dateLabel.Location = new System.Drawing.Point(10, 40);
            invoicespayments_dateLabel.Name = "invoicespayments_dateLabel";
            invoicespayments_dateLabel.Size = new System.Drawing.Size(31, 13);
            invoicespayments_dateLabel.TabIndex = 8;
            invoicespayments_dateLabel.Text = "date:";
            // 
            // invoicespayments_notesLabel
            // 
            invoicespayments_notesLabel.AutoSize = true;
            invoicespayments_notesLabel.Location = new System.Drawing.Point(10, 79);
            invoicespayments_notesLabel.Name = "invoicespayments_notesLabel";
            invoicespayments_notesLabel.Size = new System.Drawing.Size(36, 13);
            invoicespayments_notesLabel.TabIndex = 9;
            invoicespayments_notesLabel.Text = "notes:";
            // 
            // invoicespayments_totalLabel
            // 
            invoicespayments_totalLabel.AutoSize = true;
            invoicespayments_totalLabel.Location = new System.Drawing.Point(162, 40);
            invoicespayments_totalLabel.Name = "invoicespayments_totalLabel";
            invoicespayments_totalLabel.Size = new System.Drawing.Size(30, 13);
            invoicespayments_totalLabel.TabIndex = 10;
            invoicespayments_totalLabel.Text = "total:";
            // 
            // invoicesitems_taxLabel
            // 
            invoicesitems_taxLabel.AutoSize = true;
            invoicesitems_taxLabel.Location = new System.Drawing.Point(122, 198);
            invoicesitems_taxLabel.Name = "invoicesitems_taxLabel";
            invoicesitems_taxLabel.Size = new System.Drawing.Size(24, 13);
            invoicesitems_taxLabel.TabIndex = 20;
            invoicesitems_taxLabel.Text = "tax:";
            // 
            // invoicesitems_descLabel
            // 
            invoicesitems_descLabel.AutoSize = true;
            invoicesitems_descLabel.Location = new System.Drawing.Point(11, 129);
            invoicesitems_descLabel.Name = "invoicesitems_descLabel";
            invoicesitems_descLabel.Size = new System.Drawing.Size(61, 13);
            invoicesitems_descLabel.TabIndex = 22;
            invoicesitems_descLabel.Text = "description:";
            // 
            // invoicesitems_codeLabel
            // 
            invoicesitems_codeLabel.AutoSize = true;
            invoicesitems_codeLabel.Location = new System.Drawing.Point(10, 91);
            invoicesitems_codeLabel.Name = "invoicesitems_codeLabel";
            invoicesitems_codeLabel.Size = new System.Drawing.Size(34, 13);
            invoicesitems_codeLabel.TabIndex = 23;
            invoicesitems_codeLabel.Text = "code:";
            // 
            // invoicesitems_priceLabel
            // 
            invoicesitems_priceLabel.AutoSize = true;
            invoicesitems_priceLabel.Location = new System.Drawing.Point(11, 198);
            invoicesitems_priceLabel.Name = "invoicesitems_priceLabel";
            invoicesitems_priceLabel.Size = new System.Drawing.Size(33, 13);
            invoicesitems_priceLabel.TabIndex = 24;
            invoicesitems_priceLabel.Text = "price:";
            // 
            // invoicesitems_idLabel
            // 
            invoicesitems_idLabel.AutoSize = true;
            invoicesitems_idLabel.Location = new System.Drawing.Point(10, 45);
            invoicesitems_idLabel.Name = "invoicesitems_idLabel";
            invoicesitems_idLabel.Size = new System.Drawing.Size(18, 13);
            invoicesitems_idLabel.TabIndex = 31;
            invoicesitems_idLabel.Text = "id:";
            // 
            // invoices_footerstextLabel
            // 
            invoices_footerstextLabel.AutoSize = true;
            invoices_footerstextLabel.Location = new System.Drawing.Point(10, 365);
            invoices_footerstextLabel.Name = "invoices_footerstextLabel";
            invoices_footerstextLabel.Size = new System.Drawing.Size(62, 13);
            invoices_footerstextLabel.TabIndex = 22;
            invoices_footerstextLabel.Text = "footers text:";
            // 
            // invoices_deductiontaxLabel
            // 
            invoices_deductiontaxLabel.AutoSize = true;
            invoices_deductiontaxLabel.Location = new System.Drawing.Point(9, 461);
            invoices_deductiontaxLabel.Name = "invoices_deductiontaxLabel";
            invoices_deductiontaxLabel.Size = new System.Drawing.Size(74, 13);
            invoices_deductiontaxLabel.TabIndex = 26;
            invoices_deductiontaxLabel.Text = "deduction tax:";
            // 
            // tabControl_main
            // 
            this.tabControl_main.Controls.Add(this.tabPage1);
            this.tabControl_main.Controls.Add(this.tabPage4);
            this.tabControl_main.Controls.Add(this.tabPage2);
            this.tabControl_main.Controls.Add(this.tabPage3);
            this.tabControl_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_main.Location = new System.Drawing.Point(0, 0);
            this.tabControl_main.Name = "tabControl_main";
            this.tabControl_main.SelectedIndex = 0;
            this.tabControl_main.Size = new System.Drawing.Size(600, 622);
            this.tabControl_main.TabIndex = 0;
            this.tabControl_main.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_main_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.comboBox_taxesdeduction);
            this.tabPage1.Controls.Add(invoices_deductiontaxLabel);
            this.tabPage1.Controls.Add(this.invoices_deductiontaxTextBox);
            this.tabPage1.Controls.Add(this.comboBox_fillfromfootersdocs);
            this.tabPage1.Controls.Add(this.button_fillfromfootersdocs);
            this.tabPage1.Controls.Add(invoices_footerstextLabel);
            this.tabPage1.Controls.Add(this.invoices_footerstextTextBox);
            this.tabPage1.Controls.Add(this.button_fillfromusers);
            this.tabPage1.Controls.Add(invoices_userstextLabel);
            this.tabPage1.Controls.Add(this.invoices_userstextTextBox);
            this.tabPage1.Controls.Add(users_idLabel2);
            this.tabPage1.Controls.Add(this.users_idComboBox);
            this.tabPage1.Controls.Add(this.button_fillfromcustomers);
            this.tabPage1.Controls.Add(customers_idLabel);
            this.tabPage1.Controls.Add(this.customers_idComboBox);
            this.tabPage1.Controls.Add(this.button_fillfrompayments);
            this.tabPage1.Controls.Add(this.comboBox_fillfrompayments);
            this.tabPage1.Controls.Add(invoices_totalLabel);
            this.tabPage1.Controls.Add(this.invoices_totalTextBox);
            this.tabPage1.Controls.Add(paystatus_idLabel1);
            this.tabPage1.Controls.Add(this.paystatus_idComboBox);
            this.tabPage1.Controls.Add(invoices_customerstextLabel);
            this.tabPage1.Controls.Add(this.invoices_customerstextTextBox);
            this.tabPage1.Controls.Add(invoices_paymentstextLabel);
            this.tabPage1.Controls.Add(this.invoices_paymentstextTextBox);
            this.tabPage1.Controls.Add(invoices_dateLabel);
            this.tabPage1.Controls.Add(this.invoices_dateDateTimePicker);
            this.tabPage1.Controls.Add(invoices_numberLabel);
            this.tabPage1.Controls.Add(this.invoices_numberTextBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(592, 596);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Info";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox_taxesdeduction
            // 
            this.comboBox_taxesdeduction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_taxesdeduction.FormattingEnabled = true;
            this.comboBox_taxesdeduction.Location = new System.Drawing.Point(89, 476);
            this.comboBox_taxesdeduction.Name = "comboBox_taxesdeduction";
            this.comboBox_taxesdeduction.Size = new System.Drawing.Size(100, 21);
            this.comboBox_taxesdeduction.TabIndex = 28;
            this.comboBox_taxesdeduction.SelectedIndexChanged += new System.EventHandler(this.comboBox_taxesdeduction_SelectedIndexChanged);
            // 
            // invoices_deductiontaxTextBox
            // 
            this.invoices_deductiontaxTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesBindingSource, "invoices_deductiontax", true));
            this.invoices_deductiontaxTextBox.Location = new System.Drawing.Point(13, 477);
            this.invoices_deductiontaxTextBox.MaxLength = 5;
            this.invoices_deductiontaxTextBox.Name = "invoices_deductiontaxTextBox";
            this.invoices_deductiontaxTextBox.Size = new System.Drawing.Size(70, 20);
            this.invoices_deductiontaxTextBox.TabIndex = 27;
            this.invoices_deductiontaxTextBox.Leave += new System.EventHandler(this.invoices_deductiontaxTextBox_Leave);
            // 
            // invoicesBindingSource
            // 
            this.invoicesBindingSource.DataMember = "invoices";
            this.invoicesBindingSource.DataSource = this.dataSet01S;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox_fillfromfootersdocs
            // 
            this.comboBox_fillfromfootersdocs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_fillfromfootersdocs.FormattingEnabled = true;
            this.comboBox_fillfromfootersdocs.Location = new System.Drawing.Point(13, 381);
            this.comboBox_fillfromfootersdocs.Name = "comboBox_fillfromfootersdocs";
            this.comboBox_fillfromfootersdocs.Size = new System.Drawing.Size(250, 21);
            this.comboBox_fillfromfootersdocs.TabIndex = 25;
            // 
            // button_fillfromfootersdocs
            // 
            this.button_fillfromfootersdocs.Location = new System.Drawing.Point(450, 379);
            this.button_fillfromfootersdocs.Name = "button_fillfromfootersdocs";
            this.button_fillfromfootersdocs.Size = new System.Drawing.Size(136, 23);
            this.button_fillfromfootersdocs.TabIndex = 24;
            this.button_fillfromfootersdocs.Text = "fill from footers";
            this.button_fillfromfootersdocs.UseVisualStyleBackColor = true;
            this.button_fillfromfootersdocs.Click += new System.EventHandler(this.button_fillfromfootersdocs_Click);
            // 
            // invoices_footerstextTextBox
            // 
            this.invoices_footerstextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesBindingSource, "invoices_footerstext", true));
            this.invoices_footerstextTextBox.Location = new System.Drawing.Point(13, 408);
            this.invoices_footerstextTextBox.Multiline = true;
            this.invoices_footerstextTextBox.Name = "invoices_footerstextTextBox";
            this.invoices_footerstextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.invoices_footerstextTextBox.Size = new System.Drawing.Size(569, 50);
            this.invoices_footerstextTextBox.TabIndex = 23;
            // 
            // button_fillfromusers
            // 
            this.button_fillfromusers.Location = new System.Drawing.Point(448, 81);
            this.button_fillfromusers.Name = "button_fillfromusers";
            this.button_fillfromusers.Size = new System.Drawing.Size(136, 23);
            this.button_fillfromusers.TabIndex = 21;
            this.button_fillfromusers.Text = "fill from user";
            this.button_fillfromusers.UseVisualStyleBackColor = true;
            this.button_fillfromusers.Click += new System.EventHandler(this.button_fillfromusers_Click);
            // 
            // invoices_userstextTextBox
            // 
            this.invoices_userstextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesBindingSource, "invoices_userstext", true));
            this.invoices_userstextTextBox.Location = new System.Drawing.Point(12, 107);
            this.invoices_userstextTextBox.Multiline = true;
            this.invoices_userstextTextBox.Name = "invoices_userstextTextBox";
            this.invoices_userstextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.invoices_userstextTextBox.Size = new System.Drawing.Size(572, 50);
            this.invoices_userstextTextBox.TabIndex = 20;
            // 
            // users_idComboBox
            // 
            this.users_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.invoicesBindingSource, "users_id", true));
            this.users_idComboBox.DataSource = this.comboviewDataTableusersBindingSource;
            this.users_idComboBox.DisplayMember = "users_alias";
            this.users_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.users_idComboBox.Enabled = false;
            this.users_idComboBox.FormattingEnabled = true;
            this.users_idComboBox.Location = new System.Drawing.Point(13, 67);
            this.users_idComboBox.Name = "users_idComboBox";
            this.users_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.users_idComboBox.TabIndex = 18;
            this.users_idComboBox.ValueMember = "users_id";
            // 
            // comboviewDataTableusersBindingSource
            // 
            this.comboviewDataTableusersBindingSource.DataMember = "comboviewDataTableusers";
            this.comboviewDataTableusersBindingSource.DataSource = this.dataSet01V;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button_fillfromcustomers
            // 
            this.button_fillfromcustomers.Location = new System.Drawing.Point(448, 187);
            this.button_fillfromcustomers.Name = "button_fillfromcustomers";
            this.button_fillfromcustomers.Size = new System.Drawing.Size(136, 23);
            this.button_fillfromcustomers.TabIndex = 16;
            this.button_fillfromcustomers.Text = "fill from customer";
            this.button_fillfromcustomers.UseVisualStyleBackColor = true;
            this.button_fillfromcustomers.Click += new System.EventHandler(this.button_fillfromcustomers_Click);
            // 
            // customers_idComboBox
            // 
            this.customers_idComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.customers_idComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.customers_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.invoicesBindingSource, "customers_id", true));
            this.customers_idComboBox.DataSource = this.comboviewDataTablecustomersBindingSource;
            this.customers_idComboBox.DisplayMember = "customers_alias";
            this.customers_idComboBox.FormattingEnabled = true;
            this.customers_idComboBox.Location = new System.Drawing.Point(12, 176);
            this.customers_idComboBox.Name = "customers_idComboBox";
            this.customers_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.customers_idComboBox.TabIndex = 15;
            this.customers_idComboBox.ValueMember = "customers_id";
            // 
            // comboviewDataTablecustomersBindingSource
            // 
            this.comboviewDataTablecustomersBindingSource.DataMember = "comboviewDataTablecustomers";
            this.comboviewDataTablecustomersBindingSource.DataSource = this.dataSet01V;
            // 
            // button_fillfrompayments
            // 
            this.button_fillfrompayments.Location = new System.Drawing.Point(448, 283);
            this.button_fillfrompayments.Name = "button_fillfrompayments";
            this.button_fillfrompayments.Size = new System.Drawing.Size(136, 23);
            this.button_fillfrompayments.TabIndex = 13;
            this.button_fillfrompayments.Text = "fill from payment";
            this.button_fillfrompayments.UseVisualStyleBackColor = true;
            this.button_fillfrompayments.Click += new System.EventHandler(this.button_fillfrompayments_Click);
            // 
            // comboBox_fillfrompayments
            // 
            this.comboBox_fillfrompayments.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_fillfrompayments.FormattingEnabled = true;
            this.comboBox_fillfrompayments.Location = new System.Drawing.Point(13, 285);
            this.comboBox_fillfrompayments.Name = "comboBox_fillfrompayments";
            this.comboBox_fillfrompayments.Size = new System.Drawing.Size(250, 21);
            this.comboBox_fillfrompayments.TabIndex = 12;
            // 
            // invoices_totalTextBox
            // 
            this.invoices_totalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesBindingSource, "invoices_total", true));
            this.invoices_totalTextBox.Location = new System.Drawing.Point(514, 28);
            this.invoices_totalTextBox.Name = "invoices_totalTextBox";
            this.invoices_totalTextBox.ReadOnly = true;
            this.invoices_totalTextBox.Size = new System.Drawing.Size(70, 20);
            this.invoices_totalTextBox.TabIndex = 11;
            // 
            // paystatus_idComboBox
            // 
            this.paystatus_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.invoicesBindingSource, "paystatus_id", true));
            this.paystatus_idComboBox.DataSource = this.comboviewDataTablepaystatusBindingSource;
            this.paystatus_idComboBox.DisplayMember = "paystatus_name";
            this.paystatus_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.paystatus_idComboBox.FormattingEnabled = true;
            this.paystatus_idComboBox.Location = new System.Drawing.Point(13, 516);
            this.paystatus_idComboBox.Name = "paystatus_idComboBox";
            this.paystatus_idComboBox.Size = new System.Drawing.Size(80, 21);
            this.paystatus_idComboBox.TabIndex = 9;
            this.paystatus_idComboBox.ValueMember = "paystatus_id";
            // 
            // comboviewDataTablepaystatusBindingSource
            // 
            this.comboviewDataTablepaystatusBindingSource.DataMember = "comboviewDataTablepaystatus";
            this.comboviewDataTablepaystatusBindingSource.DataSource = this.dataSet01V;
            // 
            // invoices_customerstextTextBox
            // 
            this.invoices_customerstextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesBindingSource, "invoices_customerstext", true));
            this.invoices_customerstextTextBox.Location = new System.Drawing.Point(13, 216);
            this.invoices_customerstextTextBox.Multiline = true;
            this.invoices_customerstextTextBox.Name = "invoices_customerstextTextBox";
            this.invoices_customerstextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.invoices_customerstextTextBox.Size = new System.Drawing.Size(571, 50);
            this.invoices_customerstextTextBox.TabIndex = 7;
            // 
            // invoices_paymentstextTextBox
            // 
            this.invoices_paymentstextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesBindingSource, "invoices_paymentstext", true));
            this.invoices_paymentstextTextBox.Location = new System.Drawing.Point(15, 312);
            this.invoices_paymentstextTextBox.Multiline = true;
            this.invoices_paymentstextTextBox.Name = "invoices_paymentstextTextBox";
            this.invoices_paymentstextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.invoices_paymentstextTextBox.Size = new System.Drawing.Size(571, 50);
            this.invoices_paymentstextTextBox.TabIndex = 5;
            // 
            // invoices_dateDateTimePicker
            // 
            this.invoices_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.invoicesBindingSource, "invoices_date", true));
            this.invoices_dateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.invoices_dateDateTimePicker.Location = new System.Drawing.Point(130, 28);
            this.invoices_dateDateTimePicker.Name = "invoices_dateDateTimePicker";
            this.invoices_dateDateTimePicker.Size = new System.Drawing.Size(100, 20);
            this.invoices_dateDateTimePicker.TabIndex = 3;
            // 
            // invoices_numberTextBox
            // 
            this.invoices_numberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesBindingSource, "invoices_number", true));
            this.invoices_numberTextBox.Location = new System.Drawing.Point(13, 28);
            this.invoices_numberTextBox.MaxLength = 11;
            this.invoices_numberTextBox.Name = "invoices_numberTextBox";
            this.invoices_numberTextBox.Size = new System.Drawing.Size(70, 20);
            this.invoices_numberTextBox.TabIndex = 1;
            this.invoices_numberTextBox.Leave += new System.EventHandler(this.invoices_numberTextBox_Leave);
            // 
            // tabPage4
            // 
            this.tabPage4.AutoScroll = true;
            this.tabPage4.Controls.Add(this.panel8);
            this.tabPage4.Controls.Add(this.panel9);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(592, 596);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Treatments";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.dataGridView_invoicestreatmentsmain);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(586, 466);
            this.panel8.TabIndex = 0;
            // 
            // dataGridView_invoicestreatmentsmain
            // 
            this.dataGridView_invoicestreatmentsmain.AllowUserToAddRows = false;
            this.dataGridView_invoicestreatmentsmain.AllowUserToDeleteRows = false;
            this.dataGridView_invoicestreatmentsmain.AllowUserToResizeColumns = false;
            this.dataGridView_invoicestreatmentsmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_invoicestreatmentsmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_invoicestreatmentsmain.AutoGenerateColumns = false;
            this.dataGridView_invoicestreatmentsmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_invoicestreatmentsmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.animalstreatmentsdateDataGridViewTextBoxColumn,
            this.animalsnameDataGridViewTextBoxColumn,
            this.animalstreatmentsdescDataGridViewTextBoxColumn,
            this.paystatusnameDataGridViewTextBoxColumn1});
            this.dataGridView_invoicestreatmentsmain.DataSource = this.subviewDataTableinvoicestreatmentsBindingSource;
            this.dataGridView_invoicestreatmentsmain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_invoicestreatmentsmain.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_invoicestreatmentsmain.MultiSelect = false;
            this.dataGridView_invoicestreatmentsmain.Name = "dataGridView_invoicestreatmentsmain";
            this.dataGridView_invoicestreatmentsmain.ReadOnly = true;
            this.dataGridView_invoicestreatmentsmain.RowHeadersVisible = false;
            this.dataGridView_invoicestreatmentsmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_invoicestreatmentsmain.Size = new System.Drawing.Size(586, 466);
            this.dataGridView_invoicestreatmentsmain.TabIndex = 2;
            // 
            // animalstreatmentsdateDataGridViewTextBoxColumn
            // 
            this.animalstreatmentsdateDataGridViewTextBoxColumn.DataPropertyName = "animalstreatments_date";
            this.animalstreatmentsdateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.animalstreatmentsdateDataGridViewTextBoxColumn.Name = "animalstreatmentsdateDataGridViewTextBoxColumn";
            this.animalstreatmentsdateDataGridViewTextBoxColumn.ReadOnly = true;
            this.animalstreatmentsdateDataGridViewTextBoxColumn.Width = 80;
            // 
            // animalsnameDataGridViewTextBoxColumn
            // 
            this.animalsnameDataGridViewTextBoxColumn.DataPropertyName = "animals_name";
            this.animalsnameDataGridViewTextBoxColumn.HeaderText = "Animal";
            this.animalsnameDataGridViewTextBoxColumn.Name = "animalsnameDataGridViewTextBoxColumn";
            this.animalsnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.animalsnameDataGridViewTextBoxColumn.Width = 120;
            // 
            // animalstreatmentsdescDataGridViewTextBoxColumn
            // 
            this.animalstreatmentsdescDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.animalstreatmentsdescDataGridViewTextBoxColumn.DataPropertyName = "animalstreatments_desc";
            this.animalstreatmentsdescDataGridViewTextBoxColumn.HeaderText = "Desc";
            this.animalstreatmentsdescDataGridViewTextBoxColumn.Name = "animalstreatmentsdescDataGridViewTextBoxColumn";
            this.animalstreatmentsdescDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paystatusnameDataGridViewTextBoxColumn1
            // 
            this.paystatusnameDataGridViewTextBoxColumn1.DataPropertyName = "paystatus_name";
            this.paystatusnameDataGridViewTextBoxColumn1.HeaderText = "PayStatus";
            this.paystatusnameDataGridViewTextBoxColumn1.Name = "paystatusnameDataGridViewTextBoxColumn1";
            this.paystatusnameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.paystatusnameDataGridViewTextBoxColumn1.Width = 70;
            // 
            // subviewDataTableinvoicestreatmentsBindingSource
            // 
            this.subviewDataTableinvoicestreatmentsBindingSource.DataMember = "subviewDataTableinvoicestreatments";
            this.subviewDataTableinvoicestreatmentsBindingSource.DataSource = this.dataSet01V;
            this.subviewDataTableinvoicestreatmentsBindingSource.CurrentChanged += new System.EventHandler(this.subviewDataTableinvoicestreatmentsBindingSource_CurrentChanged);
            // 
            // panel9
            // 
            this.panel9.AutoScroll = true;
            this.panel9.Controls.Add(this.dataGridView_invoicestreatmentsinvoiceable);
            this.panel9.Controls.Add(this.button_invoicestreatmentsMarkPaied);
            this.panel9.Controls.Add(this.button_invoicestreatmentsRemove);
            this.panel9.Controls.Add(this.button_invoicestreatmentsAdd);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel9.Location = new System.Drawing.Point(3, 469);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(586, 124);
            this.panel9.TabIndex = 1;
            // 
            // dataGridView_invoicestreatmentsinvoiceable
            // 
            this.dataGridView_invoicestreatmentsinvoiceable.AllowUserToAddRows = false;
            this.dataGridView_invoicestreatmentsinvoiceable.AllowUserToDeleteRows = false;
            this.dataGridView_invoicestreatmentsinvoiceable.AllowUserToResizeColumns = false;
            this.dataGridView_invoicestreatmentsinvoiceable.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_invoicestreatmentsinvoiceable.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_invoicestreatmentsinvoiceable.AutoGenerateColumns = false;
            this.dataGridView_invoicestreatmentsinvoiceable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_invoicestreatmentsinvoiceable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.animalsnameDataGridViewTextBoxColumn1,
            this.animalstreatmentsdateDataGridViewTextBoxColumn1,
            this.animalstreatmentsdescDataGridViewTextBoxColumn1});
            this.dataGridView_invoicestreatmentsinvoiceable.DataSource = this.comboviewDataTableanimalstreatmentsinvoiceableBindingSource;
            this.dataGridView_invoicestreatmentsinvoiceable.Location = new System.Drawing.Point(3, 6);
            this.dataGridView_invoicestreatmentsinvoiceable.MultiSelect = false;
            this.dataGridView_invoicestreatmentsinvoiceable.Name = "dataGridView_invoicestreatmentsinvoiceable";
            this.dataGridView_invoicestreatmentsinvoiceable.ReadOnly = true;
            this.dataGridView_invoicestreatmentsinvoiceable.RowHeadersVisible = false;
            this.dataGridView_invoicestreatmentsinvoiceable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_invoicestreatmentsinvoiceable.Size = new System.Drawing.Size(472, 115);
            this.dataGridView_invoicestreatmentsinvoiceable.TabIndex = 4;
            // 
            // animalsnameDataGridViewTextBoxColumn1
            // 
            this.animalsnameDataGridViewTextBoxColumn1.DataPropertyName = "animals_name";
            this.animalsnameDataGridViewTextBoxColumn1.HeaderText = "Animal";
            this.animalsnameDataGridViewTextBoxColumn1.Name = "animalsnameDataGridViewTextBoxColumn1";
            this.animalsnameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.animalsnameDataGridViewTextBoxColumn1.Width = 120;
            // 
            // animalstreatmentsdateDataGridViewTextBoxColumn1
            // 
            this.animalstreatmentsdateDataGridViewTextBoxColumn1.DataPropertyName = "animalstreatments_date";
            this.animalstreatmentsdateDataGridViewTextBoxColumn1.HeaderText = "Date";
            this.animalstreatmentsdateDataGridViewTextBoxColumn1.Name = "animalstreatmentsdateDataGridViewTextBoxColumn1";
            this.animalstreatmentsdateDataGridViewTextBoxColumn1.ReadOnly = true;
            this.animalstreatmentsdateDataGridViewTextBoxColumn1.Width = 80;
            // 
            // animalstreatmentsdescDataGridViewTextBoxColumn1
            // 
            this.animalstreatmentsdescDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.animalstreatmentsdescDataGridViewTextBoxColumn1.DataPropertyName = "animalstreatments_desc";
            this.animalstreatmentsdescDataGridViewTextBoxColumn1.HeaderText = "Desc";
            this.animalstreatmentsdescDataGridViewTextBoxColumn1.Name = "animalstreatmentsdescDataGridViewTextBoxColumn1";
            this.animalstreatmentsdescDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // comboviewDataTableanimalstreatmentsinvoiceableBindingSource
            // 
            this.comboviewDataTableanimalstreatmentsinvoiceableBindingSource.DataMember = "comboviewDataTableanimalstreatmentsinvoiceable";
            this.comboviewDataTableanimalstreatmentsinvoiceableBindingSource.DataSource = this.dataSet01V;
            // 
            // button_invoicestreatmentsMarkPaied
            // 
            this.button_invoicestreatmentsMarkPaied.Location = new System.Drawing.Point(481, 64);
            this.button_invoicestreatmentsMarkPaied.Name = "button_invoicestreatmentsMarkPaied";
            this.button_invoicestreatmentsMarkPaied.Size = new System.Drawing.Size(100, 23);
            this.button_invoicestreatmentsMarkPaied.TabIndex = 3;
            this.button_invoicestreatmentsMarkPaied.Text = "Mark as Paid";
            this.button_invoicestreatmentsMarkPaied.UseVisualStyleBackColor = true;
            this.button_invoicestreatmentsMarkPaied.Click += new System.EventHandler(this.button_invoicestreatmentsMarkPaied_Click);
            // 
            // button_invoicestreatmentsRemove
            // 
            this.button_invoicestreatmentsRemove.Location = new System.Drawing.Point(506, 35);
            this.button_invoicestreatmentsRemove.Name = "button_invoicestreatmentsRemove";
            this.button_invoicestreatmentsRemove.Size = new System.Drawing.Size(75, 23);
            this.button_invoicestreatmentsRemove.TabIndex = 1;
            this.button_invoicestreatmentsRemove.Text = "Remove";
            this.button_invoicestreatmentsRemove.UseVisualStyleBackColor = true;
            this.button_invoicestreatmentsRemove.Click += new System.EventHandler(this.button_invoicestreatmentsRemove_Click);
            // 
            // button_invoicestreatmentsAdd
            // 
            this.button_invoicestreatmentsAdd.Location = new System.Drawing.Point(506, 6);
            this.button_invoicestreatmentsAdd.Name = "button_invoicestreatmentsAdd";
            this.button_invoicestreatmentsAdd.Size = new System.Drawing.Size(75, 23);
            this.button_invoicestreatmentsAdd.TabIndex = 0;
            this.button_invoicestreatmentsAdd.Text = "Add";
            this.button_invoicestreatmentsAdd.UseVisualStyleBackColor = true;
            this.button_invoicestreatmentsAdd.Click += new System.EventHandler(this.button_invoicestreatmentsAdd_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.panel14);
            this.tabPage2.Controls.Add(this.panel13);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(592, 596);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Items";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.dataGridView_invoicesitemsmain);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(3, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(586, 229);
            this.panel14.TabIndex = 3;
            // 
            // dataGridView_invoicesitemsmain
            // 
            this.dataGridView_invoicesitemsmain.AllowUserToAddRows = false;
            this.dataGridView_invoicesitemsmain.AllowUserToDeleteRows = false;
            this.dataGridView_invoicesitemsmain.AllowUserToResizeColumns = false;
            this.dataGridView_invoicesitemsmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_invoicesitemsmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_invoicesitemsmain.AutoGenerateColumns = false;
            this.dataGridView_invoicesitemsmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_invoicesitemsmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.invoicesitemsidDataGridViewTextBoxColumn,
            this.invoicesitemscodeDataGridViewTextBoxColumn,
            this.invoicesitemsdescDataGridViewTextBoxColumn,
            this.invoicesitemspriceDataGridViewTextBoxColumn});
            this.dataGridView_invoicesitemsmain.DataSource = this.subviewDataTableinvoicesitemsBindingSource;
            this.dataGridView_invoicesitemsmain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_invoicesitemsmain.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_invoicesitemsmain.MultiSelect = false;
            this.dataGridView_invoicesitemsmain.Name = "dataGridView_invoicesitemsmain";
            this.dataGridView_invoicesitemsmain.ReadOnly = true;
            this.dataGridView_invoicesitemsmain.RowHeadersVisible = false;
            this.dataGridView_invoicesitemsmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_invoicesitemsmain.Size = new System.Drawing.Size(586, 229);
            this.dataGridView_invoicesitemsmain.TabIndex = 1;
            // 
            // invoicesitemsidDataGridViewTextBoxColumn
            // 
            this.invoicesitemsidDataGridViewTextBoxColumn.DataPropertyName = "invoicesitems_id";
            this.invoicesitemsidDataGridViewTextBoxColumn.HeaderText = "Id";
            this.invoicesitemsidDataGridViewTextBoxColumn.Name = "invoicesitemsidDataGridViewTextBoxColumn";
            this.invoicesitemsidDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicesitemsidDataGridViewTextBoxColumn.Width = 50;
            // 
            // invoicesitemscodeDataGridViewTextBoxColumn
            // 
            this.invoicesitemscodeDataGridViewTextBoxColumn.DataPropertyName = "invoicesitems_code";
            this.invoicesitemscodeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.invoicesitemscodeDataGridViewTextBoxColumn.Name = "invoicesitemscodeDataGridViewTextBoxColumn";
            this.invoicesitemscodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicesitemscodeDataGridViewTextBoxColumn.Width = 70;
            // 
            // invoicesitemsdescDataGridViewTextBoxColumn
            // 
            this.invoicesitemsdescDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.invoicesitemsdescDataGridViewTextBoxColumn.DataPropertyName = "invoicesitems_desc";
            this.invoicesitemsdescDataGridViewTextBoxColumn.HeaderText = "Desc";
            this.invoicesitemsdescDataGridViewTextBoxColumn.Name = "invoicesitemsdescDataGridViewTextBoxColumn";
            this.invoicesitemsdescDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // invoicesitemspriceDataGridViewTextBoxColumn
            // 
            this.invoicesitemspriceDataGridViewTextBoxColumn.DataPropertyName = "invoicesitems_price";
            this.invoicesitemspriceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.invoicesitemspriceDataGridViewTextBoxColumn.Name = "invoicesitemspriceDataGridViewTextBoxColumn";
            this.invoicesitemspriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicesitemspriceDataGridViewTextBoxColumn.Width = 70;
            // 
            // subviewDataTableinvoicesitemsBindingSource
            // 
            this.subviewDataTableinvoicesitemsBindingSource.DataMember = "subviewDataTableinvoicesitems";
            this.subviewDataTableinvoicesitemsBindingSource.DataSource = this.dataSet01V;
            this.subviewDataTableinvoicesitemsBindingSource.CurrentChanged += new System.EventHandler(this.subviewDataTableinvoicesitemsBindingSource_CurrentChanged);
            // 
            // panel13
            // 
            this.panel13.AutoScroll = true;
            this.panel13.Controls.Add(this.button_invoicesitemsAddcomputedrowsdocs);
            this.panel13.Controls.Add(this.comboBox_invoicesitemscomputedrowsdocs);
            this.panel13.Controls.Add(invoicesitems_idLabel);
            this.panel13.Controls.Add(this.invoicesitems_idTextBox);
            this.panel13.Controls.Add(this.label5);
            this.panel13.Controls.Add(this.textBox_invoicesitemstotalnotax);
            this.panel13.Controls.Add(this.textBox_invoicesitemstotal);
            this.panel13.Controls.Add(this.comboBox_invoicesitemstaxes);
            this.panel13.Controls.Add(this.label4);
            this.panel13.Controls.Add(invoicesitems_priceLabel);
            this.panel13.Controls.Add(this.textBox_invoicesitemstotaltax);
            this.panel13.Controls.Add(this.invoicesitems_priceTextBox);
            this.panel13.Controls.Add(this.label3);
            this.panel13.Controls.Add(invoicesitems_codeLabel);
            this.panel13.Controls.Add(this.invoicesitems_codeTextBox);
            this.panel13.Controls.Add(this.textBox_invoicesitemstotaldeductiontax);
            this.panel13.Controls.Add(invoicesitems_descLabel);
            this.panel13.Controls.Add(this.label2);
            this.panel13.Controls.Add(this.invoicesitems_descTextBox);
            this.panel13.Controls.Add(this.button_invoicesitemsLoadfromtreatments);
            this.panel13.Controls.Add(this.button_invoicesitemsDelete);
            this.panel13.Controls.Add(invoicesitems_taxLabel);
            this.panel13.Controls.Add(this.button_invoicesitemsEdit);
            this.panel13.Controls.Add(this.invoicesitems_taxTextBox);
            this.panel13.Controls.Add(this.button_invoicesitemsNew);
            this.panel13.Controls.Add(this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel13.Location = new System.Drawing.Point(3, 232);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(586, 361);
            this.panel13.TabIndex = 2;
            // 
            // button_invoicesitemsAddcomputedrowsdocs
            // 
            this.button_invoicesitemsAddcomputedrowsdocs.Location = new System.Drawing.Point(135, 65);
            this.button_invoicesitemsAddcomputedrowsdocs.Name = "button_invoicesitemsAddcomputedrowsdocs";
            this.button_invoicesitemsAddcomputedrowsdocs.Size = new System.Drawing.Size(110, 23);
            this.button_invoicesitemsAddcomputedrowsdocs.TabIndex = 34;
            this.button_invoicesitemsAddcomputedrowsdocs.Text = "Add computed row";
            this.button_invoicesitemsAddcomputedrowsdocs.UseVisualStyleBackColor = true;
            this.button_invoicesitemsAddcomputedrowsdocs.Click += new System.EventHandler(this.button_invoicesitemsAddcomputedrowsdocs_Click);
            // 
            // comboBox_invoicesitemscomputedrowsdocs
            // 
            this.comboBox_invoicesitemscomputedrowsdocs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_invoicesitemscomputedrowsdocs.FormattingEnabled = true;
            this.comboBox_invoicesitemscomputedrowsdocs.Location = new System.Drawing.Point(251, 66);
            this.comboBox_invoicesitemscomputedrowsdocs.Name = "comboBox_invoicesitemscomputedrowsdocs";
            this.comboBox_invoicesitemscomputedrowsdocs.Size = new System.Drawing.Size(100, 21);
            this.comboBox_invoicesitemscomputedrowsdocs.TabIndex = 33;
            // 
            // invoicesitems_idTextBox
            // 
            this.invoicesitems_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesitemsBindingSource, "invoicesitems_id", true));
            this.invoicesitems_idTextBox.Location = new System.Drawing.Point(13, 68);
            this.invoicesitems_idTextBox.Name = "invoicesitems_idTextBox";
            this.invoicesitems_idTextBox.ReadOnly = true;
            this.invoicesitems_idTextBox.Size = new System.Drawing.Size(100, 20);
            this.invoicesitems_idTextBox.TabIndex = 32;
            // 
            // invoicesitemsBindingSource
            // 
            this.invoicesitemsBindingSource.DataMember = "invoicesitems";
            this.invoicesitemsBindingSource.DataSource = this.dataSet01S;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(445, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 29;
            this.label5.Text = "total no tax";
            // 
            // textBox_invoicesitemstotalnotax
            // 
            this.textBox_invoicesitemstotalnotax.Location = new System.Drawing.Point(513, 9);
            this.textBox_invoicesitemstotalnotax.Name = "textBox_invoicesitemstotalnotax";
            this.textBox_invoicesitemstotalnotax.ReadOnly = true;
            this.textBox_invoicesitemstotalnotax.Size = new System.Drawing.Size(61, 20);
            this.textBox_invoicesitemstotalnotax.TabIndex = 28;
            // 
            // textBox_invoicesitemstotal
            // 
            this.textBox_invoicesitemstotal.Location = new System.Drawing.Point(513, 93);
            this.textBox_invoicesitemstotal.Name = "textBox_invoicesitemstotal";
            this.textBox_invoicesitemstotal.ReadOnly = true;
            this.textBox_invoicesitemstotal.Size = new System.Drawing.Size(61, 20);
            this.textBox_invoicesitemstotal.TabIndex = 16;
            // 
            // comboBox_invoicesitemstaxes
            // 
            this.comboBox_invoicesitemstaxes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_invoicesitemstaxes.FormattingEnabled = true;
            this.comboBox_invoicesitemstaxes.Location = new System.Drawing.Point(201, 214);
            this.comboBox_invoicesitemstaxes.Name = "comboBox_invoicesitemstaxes";
            this.comboBox_invoicesitemstaxes.Size = new System.Drawing.Size(80, 21);
            this.comboBox_invoicesitemstaxes.TabIndex = 26;
            this.comboBox_invoicesitemstaxes.SelectedIndexChanged += new System.EventHandler(this.comboBox_invoicesitemstaxes_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(413, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "total deduction tax";
            // 
            // textBox_invoicesitemstotaltax
            // 
            this.textBox_invoicesitemstotaltax.Location = new System.Drawing.Point(513, 38);
            this.textBox_invoicesitemstotaltax.Name = "textBox_invoicesitemstotaltax";
            this.textBox_invoicesitemstotaltax.ReadOnly = true;
            this.textBox_invoicesitemstotaltax.Size = new System.Drawing.Size(61, 20);
            this.textBox_invoicesitemstotaltax.TabIndex = 14;
            // 
            // invoicesitems_priceTextBox
            // 
            this.invoicesitems_priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesitemsBindingSource, "invoicesitems_price", true));
            this.invoicesitems_priceTextBox.Location = new System.Drawing.Point(14, 214);
            this.invoicesitems_priceTextBox.MaxLength = 11;
            this.invoicesitems_priceTextBox.Name = "invoicesitems_priceTextBox";
            this.invoicesitems_priceTextBox.Size = new System.Drawing.Size(70, 20);
            this.invoicesitems_priceTextBox.TabIndex = 25;
            this.invoicesitems_priceTextBox.Leave += new System.EventHandler(this.invoicesitems_priceTextBox_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(480, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "total";
            // 
            // invoicesitems_codeTextBox
            // 
            this.invoicesitems_codeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesitemsBindingSource, "invoicesitems_code", true));
            this.invoicesitems_codeTextBox.Location = new System.Drawing.Point(13, 107);
            this.invoicesitems_codeTextBox.MaxLength = 15;
            this.invoicesitems_codeTextBox.Name = "invoicesitems_codeTextBox";
            this.invoicesitems_codeTextBox.Size = new System.Drawing.Size(100, 20);
            this.invoicesitems_codeTextBox.TabIndex = 24;
            // 
            // textBox_invoicesitemstotaldeductiontax
            // 
            this.textBox_invoicesitemstotaldeductiontax.Location = new System.Drawing.Point(513, 67);
            this.textBox_invoicesitemstotaldeductiontax.Name = "textBox_invoicesitemstotaldeductiontax";
            this.textBox_invoicesitemstotaldeductiontax.ReadOnly = true;
            this.textBox_invoicesitemstotaldeductiontax.Size = new System.Drawing.Size(61, 20);
            this.textBox_invoicesitemstotaldeductiontax.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(460, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "total tax";
            // 
            // invoicesitems_descTextBox
            // 
            this.invoicesitems_descTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesitemsBindingSource, "invoicesitems_desc", true));
            this.invoicesitems_descTextBox.Location = new System.Drawing.Point(13, 145);
            this.invoicesitems_descTextBox.Multiline = true;
            this.invoicesitems_descTextBox.Name = "invoicesitems_descTextBox";
            this.invoicesitems_descTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.invoicesitems_descTextBox.Size = new System.Drawing.Size(568, 50);
            this.invoicesitems_descTextBox.TabIndex = 23;
            // 
            // button_invoicesitemsLoadfromtreatments
            // 
            this.button_invoicesitemsLoadfromtreatments.Location = new System.Drawing.Point(135, 36);
            this.button_invoicesitemsLoadfromtreatments.Name = "button_invoicesitemsLoadfromtreatments";
            this.button_invoicesitemsLoadfromtreatments.Size = new System.Drawing.Size(140, 23);
            this.button_invoicesitemsLoadfromtreatments.TabIndex = 10;
            this.button_invoicesitemsLoadfromtreatments.Text = "Load from Treatments";
            this.button_invoicesitemsLoadfromtreatments.UseVisualStyleBackColor = true;
            this.button_invoicesitemsLoadfromtreatments.Click += new System.EventHandler(this.button_invoicesitemsLoadfromtreatments_Click);
            // 
            // button_invoicesitemsDelete
            // 
            this.button_invoicesitemsDelete.Location = new System.Drawing.Point(165, 6);
            this.button_invoicesitemsDelete.Name = "button_invoicesitemsDelete";
            this.button_invoicesitemsDelete.Size = new System.Drawing.Size(75, 23);
            this.button_invoicesitemsDelete.TabIndex = 8;
            this.button_invoicesitemsDelete.Text = "Delete";
            this.button_invoicesitemsDelete.UseVisualStyleBackColor = true;
            this.button_invoicesitemsDelete.Click += new System.EventHandler(this.button_invoicesitemsDelete_Click);
            // 
            // button_invoicesitemsEdit
            // 
            this.button_invoicesitemsEdit.Location = new System.Drawing.Point(84, 6);
            this.button_invoicesitemsEdit.Name = "button_invoicesitemsEdit";
            this.button_invoicesitemsEdit.Size = new System.Drawing.Size(75, 23);
            this.button_invoicesitemsEdit.TabIndex = 7;
            this.button_invoicesitemsEdit.Text = "Edit";
            this.button_invoicesitemsEdit.UseVisualStyleBackColor = true;
            this.button_invoicesitemsEdit.Click += new System.EventHandler(this.button_invoicesitemsEdit_Click);
            // 
            // invoicesitems_taxTextBox
            // 
            this.invoicesitems_taxTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicesitemsBindingSource, "invoicesitems_tax", true));
            this.invoicesitems_taxTextBox.Location = new System.Drawing.Point(125, 214);
            this.invoicesitems_taxTextBox.MaxLength = 5;
            this.invoicesitems_taxTextBox.Name = "invoicesitems_taxTextBox";
            this.invoicesitems_taxTextBox.Size = new System.Drawing.Size(70, 20);
            this.invoicesitems_taxTextBox.TabIndex = 21;
            this.invoicesitems_taxTextBox.Leave += new System.EventHandler(this.invoicesitems_taxTextBox_Leave);
            // 
            // button_invoicesitemsNew
            // 
            this.button_invoicesitemsNew.Location = new System.Drawing.Point(3, 6);
            this.button_invoicesitemsNew.Name = "button_invoicesitemsNew";
            this.button_invoicesitemsNew.Size = new System.Drawing.Size(75, 23);
            this.button_invoicesitemsNew.TabIndex = 6;
            this.button_invoicesitemsNew.Text = "New";
            this.button_invoicesitemsNew.UseVisualStyleBackColor = true;
            this.button_invoicesitemsNew.Click += new System.EventHandler(this.button_invoicesitemsNew_Click);
            // 
            // groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments
            // 
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id);
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name);
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code);
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.dataGridView_invoicesitemsfillfromtreatmentsmain);
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.button_invoicesitemsfillfromtreatments);
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Location = new System.Drawing.Point(13, 241);
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Name = "groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments";
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Size = new System.Drawing.Size(567, 115);
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.TabIndex = 17;
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.TabStop = false;
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.Text = "fill from treatments";
            // 
            // comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id
            // 
            this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.FormattingEnabled = true;
            this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.Location = new System.Drawing.Point(69, 18);
            this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.Name = "comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id";
            this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.Size = new System.Drawing.Size(74, 21);
            this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.TabIndex = 6;
            this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id_SelectedIndexChanged);
            // 
            // textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name
            // 
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name.Location = new System.Drawing.Point(149, 19);
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name.Name = "textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name";
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name.Size = new System.Drawing.Size(113, 20);
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name.TabIndex = 5;
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name.TextChanged += new System.EventHandler(this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name_TextChanged);
            // 
            // textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code
            // 
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code.Location = new System.Drawing.Point(7, 19);
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code.Name = "textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code";
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code.Size = new System.Drawing.Size(58, 20);
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code.TabIndex = 3;
            this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code.TextChanged += new System.EventHandler(this.textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code_TextChanged);
            // 
            // dataGridView_invoicesitemsfillfromtreatmentsmain
            // 
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.AllowUserToAddRows = false;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.AllowUserToDeleteRows = false;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.AllowUserToResizeColumns = false;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.AutoGenerateColumns = false;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.treatmentscodeDataGridViewTextBoxColumn,
            this.treatmentscategoriesnameDataGridViewTextBoxColumn,
            this.treatmentsnameDataGridViewTextBoxColumn,
            this.treatmentsdescDataGridViewTextBoxColumn});
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.DataSource = this.comboviewDataTabletreatmentsBindingSource;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.Location = new System.Drawing.Point(6, 40);
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.MultiSelect = false;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.Name = "dataGridView_invoicesitemsfillfromtreatmentsmain";
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.ReadOnly = true;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.RowHeadersVisible = false;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.Size = new System.Drawing.Size(473, 68);
            this.dataGridView_invoicesitemsfillfromtreatmentsmain.TabIndex = 2;
            // 
            // treatmentscodeDataGridViewTextBoxColumn
            // 
            this.treatmentscodeDataGridViewTextBoxColumn.DataPropertyName = "treatments_code";
            this.treatmentscodeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.treatmentscodeDataGridViewTextBoxColumn.Name = "treatmentscodeDataGridViewTextBoxColumn";
            this.treatmentscodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentscodeDataGridViewTextBoxColumn.Width = 70;
            // 
            // treatmentscategoriesnameDataGridViewTextBoxColumn
            // 
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.DataPropertyName = "treatmentscategories_name";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.HeaderText = "Category";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.Name = "treatmentscategoriesnameDataGridViewTextBoxColumn";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.Width = 70;
            // 
            // treatmentsnameDataGridViewTextBoxColumn
            // 
            this.treatmentsnameDataGridViewTextBoxColumn.DataPropertyName = "treatments_name";
            this.treatmentsnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.treatmentsnameDataGridViewTextBoxColumn.Name = "treatmentsnameDataGridViewTextBoxColumn";
            this.treatmentsnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentsnameDataGridViewTextBoxColumn.Width = 70;
            // 
            // treatmentsdescDataGridViewTextBoxColumn
            // 
            this.treatmentsdescDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.treatmentsdescDataGridViewTextBoxColumn.DataPropertyName = "treatments_desc";
            this.treatmentsdescDataGridViewTextBoxColumn.HeaderText = "Desc";
            this.treatmentsdescDataGridViewTextBoxColumn.Name = "treatmentsdescDataGridViewTextBoxColumn";
            this.treatmentsdescDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // comboviewDataTabletreatmentsBindingSource
            // 
            this.comboviewDataTabletreatmentsBindingSource.DataMember = "comboviewDataTabletreatments";
            this.comboviewDataTabletreatmentsBindingSource.DataSource = this.dataSet01V;
            // 
            // button_invoicesitemsfillfromtreatments
            // 
            this.button_invoicesitemsfillfromtreatments.Location = new System.Drawing.Point(486, 85);
            this.button_invoicesitemsfillfromtreatments.Name = "button_invoicesitemsfillfromtreatments";
            this.button_invoicesitemsfillfromtreatments.Size = new System.Drawing.Size(75, 23);
            this.button_invoicesitemsfillfromtreatments.TabIndex = 1;
            this.button_invoicesitemsfillfromtreatments.Text = "Fill";
            this.button_invoicesitemsfillfromtreatments.UseVisualStyleBackColor = true;
            this.button_invoicesitemsfillfromtreatments.Click += new System.EventHandler(this.button_invoicesitemsfillfromtreatments_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.panel11);
            this.tabPage3.Controls.Add(this.panel10);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(592, 596);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Payments";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.dataGridView_invoicespaymentsmain);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(3, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(586, 438);
            this.panel11.TabIndex = 2;
            // 
            // dataGridView_invoicespaymentsmain
            // 
            this.dataGridView_invoicespaymentsmain.AllowUserToAddRows = false;
            this.dataGridView_invoicespaymentsmain.AllowUserToDeleteRows = false;
            this.dataGridView_invoicespaymentsmain.AllowUserToResizeColumns = false;
            this.dataGridView_invoicespaymentsmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_invoicespaymentsmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView_invoicespaymentsmain.AutoGenerateColumns = false;
            this.dataGridView_invoicespaymentsmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_invoicespaymentsmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.invoicespaymentsdateDataGridViewTextBoxColumn,
            this.invoicespaymentstotalDataGridViewTextBoxColumn});
            this.dataGridView_invoicespaymentsmain.DataSource = this.subviewDataTableinvoicespaymentsBindingSource;
            this.dataGridView_invoicespaymentsmain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_invoicespaymentsmain.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_invoicespaymentsmain.MultiSelect = false;
            this.dataGridView_invoicespaymentsmain.Name = "dataGridView_invoicespaymentsmain";
            this.dataGridView_invoicespaymentsmain.ReadOnly = true;
            this.dataGridView_invoicespaymentsmain.RowHeadersVisible = false;
            this.dataGridView_invoicespaymentsmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_invoicespaymentsmain.Size = new System.Drawing.Size(586, 438);
            this.dataGridView_invoicespaymentsmain.TabIndex = 1;
            // 
            // invoicespaymentsdateDataGridViewTextBoxColumn
            // 
            this.invoicespaymentsdateDataGridViewTextBoxColumn.DataPropertyName = "invoicespayments_date";
            this.invoicespaymentsdateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.invoicespaymentsdateDataGridViewTextBoxColumn.Name = "invoicespaymentsdateDataGridViewTextBoxColumn";
            this.invoicespaymentsdateDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicespaymentsdateDataGridViewTextBoxColumn.Width = 80;
            // 
            // invoicespaymentstotalDataGridViewTextBoxColumn
            // 
            this.invoicespaymentstotalDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.invoicespaymentstotalDataGridViewTextBoxColumn.DataPropertyName = "invoicespayments_total";
            this.invoicespaymentstotalDataGridViewTextBoxColumn.HeaderText = "Total";
            this.invoicespaymentstotalDataGridViewTextBoxColumn.Name = "invoicespaymentstotalDataGridViewTextBoxColumn";
            this.invoicespaymentstotalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // subviewDataTableinvoicespaymentsBindingSource
            // 
            this.subviewDataTableinvoicespaymentsBindingSource.DataMember = "subviewDataTableinvoicespayments";
            this.subviewDataTableinvoicespaymentsBindingSource.DataSource = this.dataSet01V;
            this.subviewDataTableinvoicespaymentsBindingSource.CurrentChanged += new System.EventHandler(this.subviewDataTableinvoicespaymentsBindingSource_CurrentChanged);
            // 
            // panel10
            // 
            this.panel10.AutoScroll = true;
            this.panel10.Controls.Add(invoicespayments_totalLabel);
            this.panel10.Controls.Add(this.textBox_invoicespaymentstotal);
            this.panel10.Controls.Add(this.invoicespayments_totalTextBox);
            this.panel10.Controls.Add(this.label1);
            this.panel10.Controls.Add(invoicespayments_notesLabel);
            this.panel10.Controls.Add(this.invoicespayments_notesTextBox);
            this.panel10.Controls.Add(this.button_invoicespaymentsDelete);
            this.panel10.Controls.Add(invoicespayments_dateLabel);
            this.panel10.Controls.Add(this.button_invoicespaymentsEdit);
            this.panel10.Controls.Add(this.invoicespayments_dateDateTimePicker);
            this.panel10.Controls.Add(this.button_invoicespaymentsNew);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(3, 441);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(586, 152);
            this.panel10.TabIndex = 1;
            // 
            // textBox_invoicespaymentstotal
            // 
            this.textBox_invoicespaymentstotal.Location = new System.Drawing.Point(511, 6);
            this.textBox_invoicespaymentstotal.Name = "textBox_invoicespaymentstotal";
            this.textBox_invoicespaymentstotal.ReadOnly = true;
            this.textBox_invoicespaymentstotal.Size = new System.Drawing.Size(70, 20);
            this.textBox_invoicespaymentstotal.TabIndex = 11;
            // 
            // invoicespayments_totalTextBox
            // 
            this.invoicespayments_totalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicespaymentsBindingSource, "invoicespayments_total", true));
            this.invoicespayments_totalTextBox.Location = new System.Drawing.Point(165, 56);
            this.invoicespayments_totalTextBox.MaxLength = 11;
            this.invoicespayments_totalTextBox.Name = "invoicespayments_totalTextBox";
            this.invoicespayments_totalTextBox.Size = new System.Drawing.Size(100, 20);
            this.invoicespayments_totalTextBox.TabIndex = 11;
            this.invoicespayments_totalTextBox.Leave += new System.EventHandler(this.invoicespayments_totalTextBox_Leave);
            // 
            // invoicespaymentsBindingSource
            // 
            this.invoicespaymentsBindingSource.DataMember = "invoicespayments";
            this.invoicespaymentsBindingSource.DataSource = this.dataSet01S;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(478, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "total";
            // 
            // invoicespayments_notesTextBox
            // 
            this.invoicespayments_notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.invoicespaymentsBindingSource, "invoicespayments_notes", true));
            this.invoicespayments_notesTextBox.Location = new System.Drawing.Point(13, 95);
            this.invoicespayments_notesTextBox.Multiline = true;
            this.invoicespayments_notesTextBox.Name = "invoicespayments_notesTextBox";
            this.invoicespayments_notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.invoicespayments_notesTextBox.Size = new System.Drawing.Size(568, 50);
            this.invoicespayments_notesTextBox.TabIndex = 10;
            // 
            // button_invoicespaymentsDelete
            // 
            this.button_invoicespaymentsDelete.Location = new System.Drawing.Point(165, 6);
            this.button_invoicespaymentsDelete.Name = "button_invoicespaymentsDelete";
            this.button_invoicespaymentsDelete.Size = new System.Drawing.Size(75, 23);
            this.button_invoicespaymentsDelete.TabIndex = 8;
            this.button_invoicespaymentsDelete.Text = "Delete";
            this.button_invoicespaymentsDelete.UseVisualStyleBackColor = true;
            this.button_invoicespaymentsDelete.Click += new System.EventHandler(this.button_invoicespaymentsDelete_Click);
            // 
            // button_invoicespaymentsEdit
            // 
            this.button_invoicespaymentsEdit.Location = new System.Drawing.Point(84, 6);
            this.button_invoicespaymentsEdit.Name = "button_invoicespaymentsEdit";
            this.button_invoicespaymentsEdit.Size = new System.Drawing.Size(75, 23);
            this.button_invoicespaymentsEdit.TabIndex = 7;
            this.button_invoicespaymentsEdit.Text = "Edit";
            this.button_invoicespaymentsEdit.UseVisualStyleBackColor = true;
            this.button_invoicespaymentsEdit.Click += new System.EventHandler(this.button_invoicespaymentsEdit_Click);
            // 
            // invoicespayments_dateDateTimePicker
            // 
            this.invoicespayments_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.invoicespaymentsBindingSource, "invoicespayments_date", true));
            this.invoicespayments_dateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.invoicespayments_dateDateTimePicker.Location = new System.Drawing.Point(13, 56);
            this.invoicespayments_dateDateTimePicker.Name = "invoicespayments_dateDateTimePicker";
            this.invoicespayments_dateDateTimePicker.Size = new System.Drawing.Size(103, 20);
            this.invoicespayments_dateDateTimePicker.TabIndex = 9;
            // 
            // button_invoicespaymentsNew
            // 
            this.button_invoicespaymentsNew.Location = new System.Drawing.Point(3, 6);
            this.button_invoicespaymentsNew.Name = "button_invoicespaymentsNew";
            this.button_invoicespaymentsNew.Size = new System.Drawing.Size(75, 23);
            this.button_invoicespaymentsNew.TabIndex = 6;
            this.button_invoicespaymentsNew.Text = "New";
            this.button_invoicespaymentsNew.UseVisualStyleBackColor = true;
            this.button_invoicespaymentsNew.Click += new System.EventHandler(this.button_invoicespaymentsNew_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox_totalpaid);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.textBox_total);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.button_Print);
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 597);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 65);
            this.panel4.TabIndex = 1;
            // 
            // textBox_totalpaid
            // 
            this.textBox_totalpaid.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_totalpaid.Location = new System.Drawing.Point(308, 32);
            this.textBox_totalpaid.Name = "textBox_totalpaid";
            this.textBox_totalpaid.ReadOnly = true;
            this.textBox_totalpaid.Size = new System.Drawing.Size(70, 20);
            this.textBox_totalpaid.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(252, 35);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "total paid";
            // 
            // textBox_total
            // 
            this.textBox_total.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_total.Location = new System.Drawing.Point(308, 6);
            this.textBox_total.Name = "textBox_total";
            this.textBox_total.ReadOnly = true;
            this.textBox_total.Size = new System.Drawing.Size(70, 20);
            this.textBox_total.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(275, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "total";
            // 
            // button_Print
            // 
            this.button_Print.Location = new System.Drawing.Point(12, 35);
            this.button_Print.Name = "button_Print";
            this.button_Print.Size = new System.Drawing.Size(75, 23);
            this.button_Print.TabIndex = 4;
            this.button_Print.Text = "Print";
            this.button_Print.UseVisualStyleBackColor = true;
            this.button_Print.Click += new System.EventHandler(this.button_Print_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "year";
            // 
            // comboBox_filter_year
            // 
            this.comboBox_filter_year.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_filter_year.FormattingEnabled = true;
            this.comboBox_filter_year.Location = new System.Drawing.Point(43, 12);
            this.comboBox_filter_year.Name = "comboBox_filter_year";
            this.comboBox_filter_year.Size = new System.Drawing.Size(70, 21);
            this.comboBox_filter_year.TabIndex = 4;
            this.comboBox_filter_year.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_year_SelectedIndexChanged);
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel_filter);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(384, 60);
            this.panel7.TabIndex = 3;
            // 
            // panel_filter
            // 
            this.panel_filter.Controls.Add(this.textBox_filter_customers);
            this.panel_filter.Controls.Add(this.label8);
            this.panel_filter.Controls.Add(this.comboBox_filter_users_id);
            this.panel_filter.Controls.Add(this.textBox_filter_number);
            this.panel_filter.Controls.Add(this.comboBox_filter_year);
            this.panel_filter.Controls.Add(this.label6);
            this.panel_filter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filter.Location = new System.Drawing.Point(0, 0);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new System.Drawing.Size(384, 60);
            this.panel_filter.TabIndex = 1;
            // 
            // textBox_filter_customers
            // 
            this.textBox_filter_customers.Location = new System.Drawing.Point(110, 37);
            this.textBox_filter_customers.Name = "textBox_filter_customers";
            this.textBox_filter_customers.Size = new System.Drawing.Size(130, 20);
            this.textBox_filter_customers.TabIndex = 8;
            this.textBox_filter_customers.TextChanged += new System.EventHandler(this.textBox_filter_customers_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(119, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "user";
            // 
            // comboBox_filter_users_id
            // 
            this.comboBox_filter_users_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox_filter_users_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_filter_users_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_filter_users_id.FormattingEnabled = true;
            this.comboBox_filter_users_id.Location = new System.Drawing.Point(152, 12);
            this.comboBox_filter_users_id.Name = "comboBox_filter_users_id";
            this.comboBox_filter_users_id.Size = new System.Drawing.Size(121, 21);
            this.comboBox_filter_users_id.TabIndex = 6;
            this.comboBox_filter_users_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_users_id_SelectedIndexChanged);
            // 
            // textBox_filter_number
            // 
            this.textBox_filter_number.Location = new System.Drawing.Point(3, 37);
            this.textBox_filter_number.Name = "textBox_filter_number";
            this.textBox_filter_number.Size = new System.Drawing.Size(45, 20);
            this.textBox_filter_number.TabIndex = 3;
            this.textBox_filter_number.TextChanged += new System.EventHandler(this.textBox_filter_number_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 662);
            this.panel1.TabIndex = 6;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 60);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(384, 537);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.invoicesnumberDataGridViewTextBoxColumn,
            this.invoicesdateDataGridViewTextBoxColumn,
            this.customersaliasDataGridViewTextBoxColumn,
            this.paystatusnameDataGridViewTextBoxColumn,
            this.invoicestotalDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTableinvoicesBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(384, 537);
            this.dataGridView_main.TabIndex = 0;
            // 
            // invoicesnumberDataGridViewTextBoxColumn
            // 
            this.invoicesnumberDataGridViewTextBoxColumn.DataPropertyName = "invoices_number";
            this.invoicesnumberDataGridViewTextBoxColumn.HeaderText = "Num.";
            this.invoicesnumberDataGridViewTextBoxColumn.Name = "invoicesnumberDataGridViewTextBoxColumn";
            this.invoicesnumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicesnumberDataGridViewTextBoxColumn.Width = 40;
            // 
            // invoicesdateDataGridViewTextBoxColumn
            // 
            this.invoicesdateDataGridViewTextBoxColumn.DataPropertyName = "invoices_date";
            this.invoicesdateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.invoicesdateDataGridViewTextBoxColumn.Name = "invoicesdateDataGridViewTextBoxColumn";
            this.invoicesdateDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicesdateDataGridViewTextBoxColumn.Width = 70;
            // 
            // customersaliasDataGridViewTextBoxColumn
            // 
            this.customersaliasDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customersaliasDataGridViewTextBoxColumn.DataPropertyName = "customers_alias";
            this.customersaliasDataGridViewTextBoxColumn.HeaderText = "Customer";
            this.customersaliasDataGridViewTextBoxColumn.Name = "customersaliasDataGridViewTextBoxColumn";
            this.customersaliasDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paystatusnameDataGridViewTextBoxColumn
            // 
            this.paystatusnameDataGridViewTextBoxColumn.DataPropertyName = "paystatus_name";
            this.paystatusnameDataGridViewTextBoxColumn.HeaderText = "PayS.";
            this.paystatusnameDataGridViewTextBoxColumn.Name = "paystatusnameDataGridViewTextBoxColumn";
            this.paystatusnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.paystatusnameDataGridViewTextBoxColumn.Width = 40;
            // 
            // invoicestotalDataGridViewTextBoxColumn
            // 
            this.invoicestotalDataGridViewTextBoxColumn.DataPropertyName = "invoices_total";
            this.invoicestotalDataGridViewTextBoxColumn.HeaderText = "Total";
            this.invoicestotalDataGridViewTextBoxColumn.Name = "invoicestotalDataGridViewTextBoxColumn";
            this.invoicestotalDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicestotalDataGridViewTextBoxColumn.Width = 50;
            // 
            // viewDataTableinvoicesBindingSource
            // 
            this.viewDataTableinvoicesBindingSource.DataMember = "viewDataTableinvoices";
            this.viewDataTableinvoicesBindingSource.DataSource = this.dataSet01V;
            this.viewDataTableinvoicesBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTableinvoicesBindingSource_CurrentChanged);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Stopedit);
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 622);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(600, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Stopedit
            // 
            this.button_Stopedit.Location = new System.Drawing.Point(168, 7);
            this.button_Stopedit.Name = "button_Stopedit";
            this.button_Stopedit.Size = new System.Drawing.Size(75, 23);
            this.button_Stopedit.TabIndex = 2;
            this.button_Stopedit.Text = "End Edit";
            this.button_Stopedit.UseVisualStyleBackColor = true;
            this.button_Stopedit.Click += new System.EventHandler(this.button_Stopedit_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(384, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 662);
            this.panel2.TabIndex = 7;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.tabControl_main);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(600, 622);
            this.panel6.TabIndex = 1;
            // 
            // viewDataTableinvoicesTableAdapter
            // 
            this.viewDataTableinvoicesTableAdapter.ClearBeforeFill = true;
            // 
            // invoicesTableAdapter
            // 
            this.invoicesTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablecustomersTableAdapter
            // 
            this.comboviewDataTablecustomersTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablepaystatusTableAdapter
            // 
            this.comboviewDataTablepaystatusTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablepaymentsBindingSource
            // 
            this.comboviewDataTablepaymentsBindingSource.DataMember = "comboviewDataTablepayments";
            this.comboviewDataTablepaymentsBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTablepaymentsTableAdapter
            // 
            this.comboviewDataTablepaymentsTableAdapter.ClearBeforeFill = true;
            // 
            // invoicesitemsTableAdapter
            // 
            this.invoicesitemsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTableusersTableAdapter
            // 
            this.comboviewDataTableusersTableAdapter.ClearBeforeFill = true;
            // 
            // invoicespaymentsTableAdapter
            // 
            this.invoicespaymentsTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableinvoicespaymentsTableAdapter
            // 
            this.subviewDataTableinvoicespaymentsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTableanimalstreatmentsinvoiceableTableAdapter
            // 
            this.comboviewDataTableanimalstreatmentsinvoiceableTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableinvoicestreatmentsTableAdapter
            // 
            this.subviewDataTableinvoicestreatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletaxesBindingSource
            // 
            this.comboviewDataTabletaxesBindingSource.DataMember = "comboviewDataTabletaxes";
            this.comboviewDataTabletaxesBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTabletaxesTableAdapter
            // 
            this.comboviewDataTabletaxesTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableinvoicesitemsTableAdapter
            // 
            this.subviewDataTableinvoicesitemsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletreatmentsTableAdapter
            // 
            this.comboviewDataTabletreatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletreatmentscategoriesBindingSource
            // 
            this.comboviewDataTabletreatmentscategoriesBindingSource.DataMember = "comboviewDataTabletreatmentscategories";
            this.comboviewDataTabletreatmentscategoriesBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTabletreatmentscategoriesTableAdapter
            // 
            this.comboviewDataTabletreatmentscategoriesTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablefootersdocsBindingSource
            // 
            this.comboviewDataTablefootersdocsBindingSource.DataMember = "comboviewDataTablefootersdocs";
            this.comboviewDataTablefootersdocsBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTablefootersdocsTableAdapter
            // 
            this.comboviewDataTablefootersdocsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletaxesdeductionBindingSource
            // 
            this.comboviewDataTabletaxesdeductionBindingSource.DataMember = "comboviewDataTabletaxesdeduction";
            this.comboviewDataTabletaxesdeductionBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTabletaxesdeductionTableAdapter
            // 
            this.comboviewDataTabletaxesdeductionTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablecomputedrowsdocsBindingSource
            // 
            this.comboviewDataTablecomputedrowsdocsBindingSource.DataMember = "comboviewDataTablecomputedrowsdocs";
            this.comboviewDataTablecomputedrowsdocsBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTablecomputedrowsdocsTableAdapter
            // 
            this.comboviewDataTablecomputedrowsdocsTableAdapter.ClearBeforeFill = true;
            // 
            // FormInvoices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormInvoices";
            this.Text = "Invoices";
            this.Activated += new System.EventHandler(this.FormInvoices_Activated);
            this.Deactivate += new System.EventHandler(this.FormInvoices_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormInvoices_FormClosing);
            this.Load += new System.EventHandler(this.FormInvoices_Load);
            this.tabControl_main.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableusersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecustomersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablepaystatusBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicestreatmentsmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableinvoicestreatmentsBindingSource)).EndInit();
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicestreatmentsinvoiceable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableanimalstreatmentsinvoiceableBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicesitemsmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableinvoicesitemsBindingSource)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoicesitemsBindingSource)).EndInit();
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.ResumeLayout(false);
            this.groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicesitemsfillfromtreatmentsmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentsBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_invoicespaymentsmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableinvoicespaymentsBindingSource)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invoicespaymentsBindingSource)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel_filter.ResumeLayout(false);
            this.panel_filter.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableinvoicesBindingSource)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablepaymentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentscategoriesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablefootersdocsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesdeductionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecomputedrowsdocsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_main;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.DataGridView dataGridView_invoicesitemsmain;
        private System.Windows.Forms.Panel panel13;
        private DataSet01S dataSet01S;
        private DataSet01V dataSet01V;
        private System.Windows.Forms.GroupBox groupBox_invoicesitemsfillfromtreatmentsfillfromtreatments;
        private System.Windows.Forms.ComboBox comboBox_invoicesitemsfillfromtreatmentsfilter_treatmentscategories_id;
        private System.Windows.Forms.TextBox textBox_invoicesitemsfillfromtreatmentsfilter_treatments_name;
        private System.Windows.Forms.TextBox textBox_invoicesitemsfillfromtreatmentsfilter_treatments_code;
        private System.Windows.Forms.Button button_invoicesitemsfillfromtreatments;
        private System.Windows.Forms.Button button_invoicesitemsDelete;
        private System.Windows.Forms.Button button_invoicesitemsEdit;
        private System.Windows.Forms.Button button_invoicesitemsNew;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.DataGridView dataGridView_invoicespaymentsmain;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button_invoicespaymentsDelete;
        private System.Windows.Forms.Button button_invoicespaymentsEdit;
        private System.Windows.Forms.Button button_invoicespaymentsNew;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox comboBox_filter_year;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_Print;
        private System.Windows.Forms.TextBox textBox_total;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.BindingSource viewDataTableinvoicesBindingSource;
        private DataSet01VTableAdapters.viewDataTableinvoicesTableAdapter viewDataTableinvoicesTableAdapter;
        private System.Windows.Forms.BindingSource invoicesBindingSource;
        private DataSet01STableAdapters.invoicesTableAdapter invoicesTableAdapter;
        private System.Windows.Forms.TextBox invoices_totalTextBox;
        private System.Windows.Forms.ComboBox paystatus_idComboBox;
        private System.Windows.Forms.TextBox invoices_customerstextTextBox;
        private System.Windows.Forms.TextBox invoices_paymentstextTextBox;
        private System.Windows.Forms.DateTimePicker invoices_dateDateTimePicker;
        private System.Windows.Forms.TextBox invoices_numberTextBox;
        private System.Windows.Forms.Button button_fillfrompayments;
        private System.Windows.Forms.ComboBox comboBox_fillfrompayments;
        private System.Windows.Forms.Button button_fillfromcustomers;
        private System.Windows.Forms.ComboBox customers_idComboBox;
        private System.Windows.Forms.BindingSource comboviewDataTablecustomersBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablecustomersTableAdapter comboviewDataTablecustomersTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTablepaystatusBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablepaystatusTableAdapter comboviewDataTablepaystatusTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTablepaymentsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablepaymentsTableAdapter comboviewDataTablepaymentsTableAdapter;
        private System.Windows.Forms.BindingSource invoicesitemsBindingSource;
        private DataSet01STableAdapters.invoicesitemsTableAdapter invoicesitemsTableAdapter;
        private System.Windows.Forms.ComboBox users_idComboBox;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox invoices_userstextTextBox;
        private System.Windows.Forms.Button button_fillfromusers;
        private System.Windows.Forms.BindingSource comboviewDataTableusersBindingSource;
        private DataSet01VTableAdapters.comboviewDataTableusersTableAdapter comboviewDataTableusersTableAdapter;
        private System.Windows.Forms.TextBox textBox_invoicespaymentstotal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource invoicespaymentsBindingSource;
        private DataSet01STableAdapters.invoicespaymentsTableAdapter invoicespaymentsTableAdapter;
        private System.Windows.Forms.TextBox invoicespayments_totalTextBox;
        private System.Windows.Forms.TextBox invoicespayments_notesTextBox;
        private System.Windows.Forms.DateTimePicker invoicespayments_dateDateTimePicker;
        private System.Windows.Forms.BindingSource subviewDataTableinvoicespaymentsBindingSource;
        private DataSet01VTableAdapters.subviewDataTableinvoicespaymentsTableAdapter subviewDataTableinvoicespaymentsTableAdapter;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DataGridView dataGridView_invoicestreatmentsmain;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button_invoicestreatmentsRemove;
        private System.Windows.Forms.Button button_invoicestreatmentsAdd;
        private System.Windows.Forms.BindingSource subviewDataTableinvoicestreatmentsBindingSource;
        private System.Windows.Forms.Button button_invoicestreatmentsMarkPaied;
        private System.Windows.Forms.BindingSource comboviewDataTableanimalstreatmentsinvoiceableBindingSource;
        private DataSet01VTableAdapters.comboviewDataTableanimalstreatmentsinvoiceableTableAdapter comboviewDataTableanimalstreatmentsinvoiceableTableAdapter;
        private DataSet01VTableAdapters.subviewDataTableinvoicestreatmentsTableAdapter subviewDataTableinvoicestreatmentsTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView_invoicesitemsfillfromtreatmentsmain;
        private System.Windows.Forms.TextBox invoicesitems_priceTextBox;
        private System.Windows.Forms.TextBox invoicesitems_codeTextBox;
        private System.Windows.Forms.TextBox invoicesitems_descTextBox;
        private System.Windows.Forms.TextBox invoicesitems_taxTextBox;
        private System.Windows.Forms.Button button_invoicesitemsLoadfromtreatments;
        private System.Windows.Forms.ComboBox comboBox_invoicesitemstaxes;
        private System.Windows.Forms.TextBox textBox_invoicesitemstotal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_invoicesitemstotaltax;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_invoicesitemstotaldeductiontax;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource comboviewDataTabletaxesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletaxesTableAdapter comboviewDataTabletaxesTableAdapter;
        private System.Windows.Forms.BindingSource subviewDataTableinvoicesitemsBindingSource;
        private DataSet01VTableAdapters.subviewDataTableinvoicesitemsTableAdapter subviewDataTableinvoicesitemsTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTabletreatmentsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletreatmentsTableAdapter comboviewDataTabletreatmentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscategoriesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentsdescDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource comboviewDataTabletreatmentscategoriesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletreatmentscategoriesTableAdapter comboviewDataTabletreatmentscategoriesTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView_invoicestreatmentsinvoiceable;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalstreatmentsdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalstreatmentsdescDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paystatusnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicespaymentsdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicespaymentstotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel_filter;
        private System.Windows.Forms.ComboBox comboBox_filter_users_id;
        private System.Windows.Forms.TextBox textBox_filter_number;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalstreatmentsdateDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalstreatmentsdescDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_invoicesitemstotalnotax;
        private System.Windows.Forms.TextBox textBox_totalpaid;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox invoicesitems_idTextBox;
        private System.Windows.Forms.ComboBox comboBox_fillfromfootersdocs;
        private System.Windows.Forms.Button button_fillfromfootersdocs;
        private System.Windows.Forms.TextBox invoices_footerstextTextBox;
        private System.Windows.Forms.BindingSource comboviewDataTablefootersdocsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablefootersdocsTableAdapter comboviewDataTablefootersdocsTableAdapter;
        private System.Windows.Forms.ComboBox comboBox_taxesdeduction;
        private System.Windows.Forms.TextBox invoices_deductiontaxTextBox;
        private System.Windows.Forms.ComboBox comboBox_invoicesitemscomputedrowsdocs;
        private System.Windows.Forms.BindingSource comboviewDataTabletaxesdeductionBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletaxesdeductionTableAdapter comboviewDataTabletaxesdeductionTableAdapter;
        private System.Windows.Forms.Button button_invoicesitemsAddcomputedrowsdocs;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicesitemsidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicesitemscodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicesitemsdescDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicesitemspriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource comboviewDataTablecomputedrowsdocsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablecomputedrowsdocsTableAdapter comboviewDataTablecomputedrowsdocsTableAdapter;
        private System.Windows.Forms.Button button_Stopedit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicesnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicesdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customersaliasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paystatusnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicestotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox_filter_customers;

    }
}