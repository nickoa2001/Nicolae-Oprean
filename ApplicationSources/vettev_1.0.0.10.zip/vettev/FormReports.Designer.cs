﻿namespace vettev
{
    partial class FormReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormReports));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_Execute = new System.Windows.Forms.Button();
            this.comboBox_reports = new System.Windows.Forms.ComboBox();
            this.dataGridView_reportsparameters = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.dataSet01V = new vettev.DataSet01V();
            this.comboviewDataTablereportsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTablereportsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablereportsTableAdapter();
            this.dataSet01S = new vettev.DataSet01S();
            this.reportsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.reportsTableAdapter = new vettev.DataSet01STableAdapters.reportsTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_reportsparameters)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablereportsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_Execute);
            this.panel1.Controls.Add(this.comboBox_reports);
            this.panel1.Controls.Add(this.dataGridView_reportsparameters);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(699, 136);
            this.panel1.TabIndex = 0;
            // 
            // button_Execute
            // 
            this.button_Execute.Location = new System.Drawing.Point(352, 12);
            this.button_Execute.Name = "button_Execute";
            this.button_Execute.Size = new System.Drawing.Size(75, 23);
            this.button_Execute.TabIndex = 3;
            this.button_Execute.Text = "Execute";
            this.button_Execute.UseVisualStyleBackColor = true;
            this.button_Execute.Click += new System.EventHandler(this.button_Execute_Click);
            // 
            // comboBox_reports
            // 
            this.comboBox_reports.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_reports.FormattingEnabled = true;
            this.comboBox_reports.Location = new System.Drawing.Point(12, 12);
            this.comboBox_reports.Name = "comboBox_reports";
            this.comboBox_reports.Size = new System.Drawing.Size(200, 21);
            this.comboBox_reports.TabIndex = 2;
            this.comboBox_reports.SelectedIndexChanged += new System.EventHandler(this.comboBox_reports_SelectedIndexChanged);
            // 
            // dataGridView_reportsparameters
            // 
            this.dataGridView_reportsparameters.AllowUserToAddRows = false;
            this.dataGridView_reportsparameters.AllowUserToDeleteRows = false;
            this.dataGridView_reportsparameters.AllowUserToResizeColumns = false;
            this.dataGridView_reportsparameters.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_reportsparameters.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_reportsparameters.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_reportsparameters.Location = new System.Drawing.Point(12, 37);
            this.dataGridView_reportsparameters.MultiSelect = false;
            this.dataGridView_reportsparameters.Name = "dataGridView_reportsparameters";
            this.dataGridView_reportsparameters.RowHeadersVisible = false;
            this.dataGridView_reportsparameters.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_reportsparameters.Size = new System.Drawing.Size(415, 85);
            this.dataGridView_reportsparameters.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dataGridView_main);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 136);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(699, 326);
            this.panel2.TabIndex = 1;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToOrderColumns = true;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(699, 326);
            this.dataGridView_main.TabIndex = 1;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboviewDataTablereportsBindingSource
            // 
            this.comboviewDataTablereportsBindingSource.DataMember = "comboviewDataTablereports";
            this.comboviewDataTablereportsBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTablereportsTableAdapter
            // 
            this.comboviewDataTablereportsTableAdapter.ClearBeforeFill = true;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportsBindingSource
            // 
            this.reportsBindingSource.DataMember = "reports";
            this.reportsBindingSource.DataSource = this.dataSet01S;
            // 
            // reportsTableAdapter
            // 
            this.reportsTableAdapter.ClearBeforeFill = true;
            // 
            // FormReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 462);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormReports";
            this.Text = "Reports";
            this.Activated += new System.EventHandler(this.FormReports_Activated);
            this.Deactivate += new System.EventHandler(this.FormReports_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormReports_FormClosing);
            this.Load += new System.EventHandler(this.FormReports_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_reportsparameters)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablereportsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox_reports;
        private System.Windows.Forms.DataGridView dataGridView_reportsparameters;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private DataSet01V dataSet01V;
        private System.Windows.Forms.BindingSource comboviewDataTablereportsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablereportsTableAdapter comboviewDataTablereportsTableAdapter;
        private System.Windows.Forms.Button button_Execute;
        private DataSet01S dataSet01S;
        private System.Windows.Forms.BindingSource reportsBindingSource;
        private DataSet01STableAdapters.reportsTableAdapter reportsTableAdapter;
    }
}