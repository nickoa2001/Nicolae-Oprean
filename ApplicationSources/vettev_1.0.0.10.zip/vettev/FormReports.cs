﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;

namespace vettev
{
    public partial class FormReports : Form
    {
        private DataTable dtparams = new DataTable();

        private static int loading = 1;

        public FormReports()
        {
            InitializeComponent();
        }

        private void FormReports_Load(object sender, EventArgs e)
        {
            this.comboviewDataTablereportsTableAdapter.Fill(this.dataSet01V.comboviewDataTablereports);

            comboBox_reports.Items.Clear();
            comboBox_reports.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablereportsRow r in dataSet01V.comboviewDataTablereports.Select("", "reports_name"))
            {
                comboBox_reports.Items.Add(new CLItemA(r.reports_id.ToString(), r.reports_name.ToString()));
            }
            comboBox_reports.SelectedIndex = 0;

            dtparams = new DataTable();
            dtparams.Columns.Add("Name", Type.GetType("System.String"));
            dtparams.Columns.Add("Value", Type.GetType("System.String"));

            dataGridView_reportsparameters.DataSource = dtparams;
            dataGridView_reportsparameters.Columns[0].Width = 80;
            dataGridView_reportsparameters.Columns[0].ReadOnly = true;
            dataGridView_reportsparameters.Columns[1].AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridView_reportsparameters.Columns[1].ReadOnly = false;

            loading = 0;
        }

        private void FormReports_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }
        
        private void FormReports_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormReports_Load(sender, e);
        }

        private void FormReports_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void comboBox_reports_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView_main.DataSource = null;
            dtparams.Clear();

            if (comboBox_reports.SelectedIndex != -1 && comboBox_reports.SelectedIndex != 0)
            {
                DataSet01STableAdapters.reportsTableAdapter t = new DataSet01STableAdapters.reportsTableAdapter();
                DataSet01S.reportsRow r = t.GetData(Convert.ToInt32(((CLItemA)comboBox_reports.SelectedItem).id)).First();

                string query = r.reports_query;
                
                List<string> pl = Regex.Matches(query, @"\@\w+").Cast<Match>().Select(m => m.Value).ToList();

                foreach (string p in pl)
                {
                    DataRow dr = dtparams.NewRow();
                    dr["Name" ] = p.ToString();
                    dtparams.Rows.Add(dr);
                }
            }
        }

        private void button_Execute_Click(object sender, EventArgs e)
        {
            if (comboBox_reports.SelectedIndex != -1 && comboBox_reports.SelectedIndex != 0)
            {
                
                DataSet01STableAdapters.reportsTableAdapter t = new DataSet01STableAdapters.reportsTableAdapter();
                DataSet01S.reportsRow r = t.GetData(Convert.ToInt32(((CLItemA)comboBox_reports.SelectedItem).id)).First();

                string query = r.reports_query;

                MySqlConnection mysqlconn = new MySqlConnection(t.Connection.ConnectionString);
                mysqlconn.Open();

                try
                {
                    MySqlCommand mysqlcommand = new MySqlCommand();
                    MySqlDataReader mysqlreader = null;

                    mysqlcommand = new MySqlCommand();
                    mysqlcommand.Connection = mysqlconn;
                    mysqlcommand.CommandText = query;
                    foreach (DataRow dr in dtparams.Rows)
                    {
                        MySqlParameter param = new MySqlParameter();
                        param.ParameterName = dr["Name"].ToString();
                        param.Value = dr["Value"].ToString();
                        mysqlcommand.Parameters.Add(param);
                    }
                    mysqlreader = mysqlcommand.ExecuteReader();

                    DataTable dt = new DataTable();
                    for (int i = 0; i < mysqlreader.FieldCount; i++)
                    {
                        dt.Columns.Add(mysqlreader.GetName(i), Type.GetType("System.String"));
                    }

                    while (mysqlreader.Read())
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < mysqlreader.FieldCount; i++)
                        {
                            dr[mysqlreader.GetName(i)] = mysqlreader[mysqlreader.GetName(i)].ToString();
                        }
                        dt.Rows.Add(dr);
                    }
                    mysqlreader.Close();

                    dataGridView_main.DataSource = dt;
                }
                catch { }

                mysqlconn.Close();
                
            }
        }
    }
}
