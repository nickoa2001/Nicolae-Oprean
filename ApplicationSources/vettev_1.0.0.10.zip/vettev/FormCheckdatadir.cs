﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace vettev
{
    public partial class FormCheckdatadir : Form
    {
        private static int loading = 1;

        public FormCheckdatadir()
        {
            InitializeComponent();
        }

        private void FormCheckdatadir_Load(object sender, EventArgs e)
        {
            textBox_output.Text = "";

            loading = 0;
        }

        private void FormCheckdatadir_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormCheckdatadir_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormCheckdatadir_Load(sender, e);
        }

        private void FormCheckdatadir_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void button_check_Click(object sender, EventArgs e)
        {
            textBox_output.Text = "";
            
            DataSet01VTableAdapters.comboviewDataTableanimalsTableAdapter t = new DataSet01VTableAdapters.comboviewDataTableanimalsTableAdapter();
            DataSet01V.comboviewDataTableanimalsDataTable d = t.GetData();

            string opendatalocation = CLOptions.ReadValue("opendatalocation");
            if (!Directory.Exists(opendatalocation))
            {
                Directory.CreateDirectory(opendatalocation);
            }

            bool haserr = false;
            DirectoryInfo dInfo = new DirectoryInfo(opendatalocation);
            foreach (DirectoryInfo di in dInfo.GetDirectories())
            { 
                bool hasdir = false;
                try
                {
                    if (d.Select("animals_id = '" + di.Name + "'").Count() > 0)
                        hasdir = true;
                }
                catch { }
                if (!hasdir)
                {
                    haserr = true;
                    textBox_output.Text += "directory " + di.FullName + " exists but no animal with this id exists" + Environment.NewLine;
                }
            }
            if (!haserr)
                textBox_output.Text += "all ok!";
        }
    }
}
