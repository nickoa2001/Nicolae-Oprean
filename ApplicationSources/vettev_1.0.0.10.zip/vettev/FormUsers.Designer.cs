﻿namespace vettev
{
    partial class FormUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label users_nameLabel;
            System.Windows.Forms.Label users_aliasLabel;
            System.Windows.Forms.Label users_surnameLabel;
            System.Windows.Forms.Label users_stateLabel;
            System.Windows.Forms.Label users_cityLabel;
            System.Windows.Forms.Label users_zipcodeLabel;
            System.Windows.Forms.Label users_streetLabel;
            System.Windows.Forms.Label users_vatnumberLabel;
            System.Windows.Forms.Label users_taxcodeLabel;
            System.Windows.Forms.Label users_telLabel;
            System.Windows.Forms.Label users_faxLabel;
            System.Windows.Forms.Label users_emailLabel;
            System.Windows.Forms.Label users_websiteLabel;
            System.Windows.Forms.Label users_notesLabel;
            System.Windows.Forms.Label users_invoicestextLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormUsers));
            this.panel6 = new System.Windows.Forms.Panel();
            this.users_invoicestextTextBox = new System.Windows.Forms.TextBox();
            this.usersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01S = new vettev.DataSet01S();
            this.users_notesTextBox = new System.Windows.Forms.TextBox();
            this.users_websiteTextBox = new System.Windows.Forms.TextBox();
            this.users_emailTextBox = new System.Windows.Forms.TextBox();
            this.users_faxTextBox = new System.Windows.Forms.TextBox();
            this.users_telTextBox = new System.Windows.Forms.TextBox();
            this.users_taxcodeTextBox = new System.Windows.Forms.TextBox();
            this.users_vatnumberTextBox = new System.Windows.Forms.TextBox();
            this.users_streetTextBox = new System.Windows.Forms.TextBox();
            this.users_zipcodeTextBox = new System.Windows.Forms.TextBox();
            this.users_cityTextBox = new System.Windows.Forms.TextBox();
            this.users_stateTextBox = new System.Windows.Forms.TextBox();
            this.users_surnameTextBox = new System.Windows.Forms.TextBox();
            this.users_aliasTextBox = new System.Windows.Forms.TextBox();
            this.users_nameTextBox = new System.Windows.Forms.TextBox();
            this.dataSet01V = new vettev.DataSet01V();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Undo = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.userssurnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersaliasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTableusersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_New = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel_filter = new System.Windows.Forms.Panel();
            this.textBox_filter_users = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.viewDataTableusersTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTableusersTableAdapter();
            this.usersTableAdapter = new vettev.DataSet01STableAdapters.usersTableAdapter();
            users_nameLabel = new System.Windows.Forms.Label();
            users_aliasLabel = new System.Windows.Forms.Label();
            users_surnameLabel = new System.Windows.Forms.Label();
            users_stateLabel = new System.Windows.Forms.Label();
            users_cityLabel = new System.Windows.Forms.Label();
            users_zipcodeLabel = new System.Windows.Forms.Label();
            users_streetLabel = new System.Windows.Forms.Label();
            users_vatnumberLabel = new System.Windows.Forms.Label();
            users_taxcodeLabel = new System.Windows.Forms.Label();
            users_telLabel = new System.Windows.Forms.Label();
            users_faxLabel = new System.Windows.Forms.Label();
            users_emailLabel = new System.Windows.Forms.Label();
            users_websiteLabel = new System.Windows.Forms.Label();
            users_notesLabel = new System.Windows.Forms.Label();
            users_invoicestextLabel = new System.Windows.Forms.Label();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableusersBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel_filter.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // users_nameLabel
            // 
            users_nameLabel.AutoSize = true;
            users_nameLabel.Location = new System.Drawing.Point(10, 56);
            users_nameLabel.Name = "users_nameLabel";
            users_nameLabel.Size = new System.Drawing.Size(36, 13);
            users_nameLabel.TabIndex = 2;
            users_nameLabel.Text = "name:";
            // 
            // users_aliasLabel
            // 
            users_aliasLabel.AutoSize = true;
            users_aliasLabel.Location = new System.Drawing.Point(10, 15);
            users_aliasLabel.Name = "users_aliasLabel";
            users_aliasLabel.Size = new System.Drawing.Size(31, 13);
            users_aliasLabel.TabIndex = 3;
            users_aliasLabel.Text = "alias:";
            // 
            // users_surnameLabel
            // 
            users_surnameLabel.AutoSize = true;
            users_surnameLabel.Location = new System.Drawing.Point(10, 95);
            users_surnameLabel.Name = "users_surnameLabel";
            users_surnameLabel.Size = new System.Drawing.Size(50, 13);
            users_surnameLabel.TabIndex = 4;
            users_surnameLabel.Text = "surname:";
            // 
            // users_stateLabel
            // 
            users_stateLabel.AutoSize = true;
            users_stateLabel.Location = new System.Drawing.Point(10, 134);
            users_stateLabel.Name = "users_stateLabel";
            users_stateLabel.Size = new System.Drawing.Size(33, 13);
            users_stateLabel.TabIndex = 6;
            users_stateLabel.Text = "state:";
            // 
            // users_cityLabel
            // 
            users_cityLabel.AutoSize = true;
            users_cityLabel.Location = new System.Drawing.Point(10, 173);
            users_cityLabel.Name = "users_cityLabel";
            users_cityLabel.Size = new System.Drawing.Size(26, 13);
            users_cityLabel.TabIndex = 8;
            users_cityLabel.Text = "city:";
            // 
            // users_zipcodeLabel
            // 
            users_zipcodeLabel.AutoSize = true;
            users_zipcodeLabel.Location = new System.Drawing.Point(10, 212);
            users_zipcodeLabel.Name = "users_zipcodeLabel";
            users_zipcodeLabel.Size = new System.Drawing.Size(50, 13);
            users_zipcodeLabel.TabIndex = 10;
            users_zipcodeLabel.Text = "zip code:";
            // 
            // users_streetLabel
            // 
            users_streetLabel.AutoSize = true;
            users_streetLabel.Location = new System.Drawing.Point(10, 251);
            users_streetLabel.Name = "users_streetLabel";
            users_streetLabel.Size = new System.Drawing.Size(36, 13);
            users_streetLabel.TabIndex = 12;
            users_streetLabel.Text = "street:";
            // 
            // users_vatnumberLabel
            // 
            users_vatnumberLabel.AutoSize = true;
            users_vatnumberLabel.Location = new System.Drawing.Point(130, 173);
            users_vatnumberLabel.Name = "users_vatnumberLabel";
            users_vatnumberLabel.Size = new System.Drawing.Size(63, 13);
            users_vatnumberLabel.TabIndex = 14;
            users_vatnumberLabel.Text = "vat number:";
            // 
            // users_taxcodeLabel
            // 
            users_taxcodeLabel.AutoSize = true;
            users_taxcodeLabel.Location = new System.Drawing.Point(130, 134);
            users_taxcodeLabel.Name = "users_taxcodeLabel";
            users_taxcodeLabel.Size = new System.Drawing.Size(51, 13);
            users_taxcodeLabel.TabIndex = 16;
            users_taxcodeLabel.Text = "tax code:";
            // 
            // users_telLabel
            // 
            users_telLabel.AutoSize = true;
            users_telLabel.Location = new System.Drawing.Point(285, 134);
            users_telLabel.Name = "users_telLabel";
            users_telLabel.Size = new System.Drawing.Size(21, 13);
            users_telLabel.TabIndex = 18;
            users_telLabel.Text = "tel:";
            // 
            // users_faxLabel
            // 
            users_faxLabel.AutoSize = true;
            users_faxLabel.Location = new System.Drawing.Point(285, 173);
            users_faxLabel.Name = "users_faxLabel";
            users_faxLabel.Size = new System.Drawing.Size(24, 13);
            users_faxLabel.TabIndex = 20;
            users_faxLabel.Text = "fax:";
            // 
            // users_emailLabel
            // 
            users_emailLabel.AutoSize = true;
            users_emailLabel.Location = new System.Drawing.Point(285, 212);
            users_emailLabel.Name = "users_emailLabel";
            users_emailLabel.Size = new System.Drawing.Size(34, 13);
            users_emailLabel.TabIndex = 22;
            users_emailLabel.Text = "email:";
            // 
            // users_websiteLabel
            // 
            users_websiteLabel.AutoSize = true;
            users_websiteLabel.Location = new System.Drawing.Point(285, 251);
            users_websiteLabel.Name = "users_websiteLabel";
            users_websiteLabel.Size = new System.Drawing.Size(46, 13);
            users_websiteLabel.TabIndex = 24;
            users_websiteLabel.Text = "website:";
            // 
            // users_notesLabel
            // 
            users_notesLabel.AutoSize = true;
            users_notesLabel.Location = new System.Drawing.Point(10, 359);
            users_notesLabel.Name = "users_notesLabel";
            users_notesLabel.Size = new System.Drawing.Size(36, 13);
            users_notesLabel.TabIndex = 26;
            users_notesLabel.Text = "notes:";
            // 
            // users_invoicestextLabel
            // 
            users_invoicestextLabel.AutoSize = true;
            users_invoicestextLabel.Location = new System.Drawing.Point(10, 290);
            users_invoicestextLabel.Name = "users_invoicestextLabel";
            users_invoicestextLabel.Size = new System.Drawing.Size(64, 13);
            users_invoicestextLabel.TabIndex = 28;
            users_invoicestextLabel.Text = "invoice text:";
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.Controls.Add(users_invoicestextLabel);
            this.panel6.Controls.Add(this.users_invoicestextTextBox);
            this.panel6.Controls.Add(users_notesLabel);
            this.panel6.Controls.Add(this.users_notesTextBox);
            this.panel6.Controls.Add(users_websiteLabel);
            this.panel6.Controls.Add(this.users_websiteTextBox);
            this.panel6.Controls.Add(users_emailLabel);
            this.panel6.Controls.Add(this.users_emailTextBox);
            this.panel6.Controls.Add(users_faxLabel);
            this.panel6.Controls.Add(this.users_faxTextBox);
            this.panel6.Controls.Add(users_telLabel);
            this.panel6.Controls.Add(this.users_telTextBox);
            this.panel6.Controls.Add(users_taxcodeLabel);
            this.panel6.Controls.Add(this.users_taxcodeTextBox);
            this.panel6.Controls.Add(users_vatnumberLabel);
            this.panel6.Controls.Add(this.users_vatnumberTextBox);
            this.panel6.Controls.Add(users_streetLabel);
            this.panel6.Controls.Add(this.users_streetTextBox);
            this.panel6.Controls.Add(users_zipcodeLabel);
            this.panel6.Controls.Add(this.users_zipcodeTextBox);
            this.panel6.Controls.Add(users_cityLabel);
            this.panel6.Controls.Add(this.users_cityTextBox);
            this.panel6.Controls.Add(users_stateLabel);
            this.panel6.Controls.Add(this.users_stateTextBox);
            this.panel6.Controls.Add(users_surnameLabel);
            this.panel6.Controls.Add(this.users_surnameTextBox);
            this.panel6.Controls.Add(users_aliasLabel);
            this.panel6.Controls.Add(this.users_aliasTextBox);
            this.panel6.Controls.Add(users_nameLabel);
            this.panel6.Controls.Add(this.users_nameTextBox);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 472);
            this.panel6.TabIndex = 1;
            // 
            // users_invoicestextTextBox
            // 
            this.users_invoicestextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_invoicestext", true));
            this.users_invoicestextTextBox.Location = new System.Drawing.Point(13, 306);
            this.users_invoicestextTextBox.Multiline = true;
            this.users_invoicestextTextBox.Name = "users_invoicestextTextBox";
            this.users_invoicestextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.users_invoicestextTextBox.Size = new System.Drawing.Size(375, 50);
            this.users_invoicestextTextBox.TabIndex = 29;
            // 
            // usersBindingSource
            // 
            this.usersBindingSource.DataMember = "users";
            this.usersBindingSource.DataSource = this.dataSet01S;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // users_notesTextBox
            // 
            this.users_notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_notes", true));
            this.users_notesTextBox.Location = new System.Drawing.Point(13, 375);
            this.users_notesTextBox.Multiline = true;
            this.users_notesTextBox.Name = "users_notesTextBox";
            this.users_notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.users_notesTextBox.Size = new System.Drawing.Size(375, 50);
            this.users_notesTextBox.TabIndex = 27;
            // 
            // users_websiteTextBox
            // 
            this.users_websiteTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_website", true));
            this.users_websiteTextBox.Location = new System.Drawing.Point(288, 267);
            this.users_websiteTextBox.MaxLength = 100;
            this.users_websiteTextBox.Name = "users_websiteTextBox";
            this.users_websiteTextBox.Size = new System.Drawing.Size(100, 20);
            this.users_websiteTextBox.TabIndex = 25;
            // 
            // users_emailTextBox
            // 
            this.users_emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_email", true));
            this.users_emailTextBox.Location = new System.Drawing.Point(288, 228);
            this.users_emailTextBox.MaxLength = 100;
            this.users_emailTextBox.Name = "users_emailTextBox";
            this.users_emailTextBox.Size = new System.Drawing.Size(100, 20);
            this.users_emailTextBox.TabIndex = 23;
            // 
            // users_faxTextBox
            // 
            this.users_faxTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_fax", true));
            this.users_faxTextBox.Location = new System.Drawing.Point(288, 189);
            this.users_faxTextBox.MaxLength = 15;
            this.users_faxTextBox.Name = "users_faxTextBox";
            this.users_faxTextBox.Size = new System.Drawing.Size(100, 20);
            this.users_faxTextBox.TabIndex = 21;
            // 
            // users_telTextBox
            // 
            this.users_telTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_tel", true));
            this.users_telTextBox.Location = new System.Drawing.Point(288, 150);
            this.users_telTextBox.MaxLength = 15;
            this.users_telTextBox.Name = "users_telTextBox";
            this.users_telTextBox.Size = new System.Drawing.Size(100, 20);
            this.users_telTextBox.TabIndex = 19;
            // 
            // users_taxcodeTextBox
            // 
            this.users_taxcodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_taxcode", true));
            this.users_taxcodeTextBox.Location = new System.Drawing.Point(133, 150);
            this.users_taxcodeTextBox.MaxLength = 15;
            this.users_taxcodeTextBox.Name = "users_taxcodeTextBox";
            this.users_taxcodeTextBox.Size = new System.Drawing.Size(135, 20);
            this.users_taxcodeTextBox.TabIndex = 17;
            // 
            // users_vatnumberTextBox
            // 
            this.users_vatnumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_vatnumber", true));
            this.users_vatnumberTextBox.Location = new System.Drawing.Point(133, 189);
            this.users_vatnumberTextBox.MaxLength = 15;
            this.users_vatnumberTextBox.Name = "users_vatnumberTextBox";
            this.users_vatnumberTextBox.Size = new System.Drawing.Size(135, 20);
            this.users_vatnumberTextBox.TabIndex = 15;
            // 
            // users_streetTextBox
            // 
            this.users_streetTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_street", true));
            this.users_streetTextBox.Location = new System.Drawing.Point(13, 267);
            this.users_streetTextBox.MaxLength = 100;
            this.users_streetTextBox.Name = "users_streetTextBox";
            this.users_streetTextBox.Size = new System.Drawing.Size(100, 20);
            this.users_streetTextBox.TabIndex = 13;
            // 
            // users_zipcodeTextBox
            // 
            this.users_zipcodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_zipcode", true));
            this.users_zipcodeTextBox.Location = new System.Drawing.Point(13, 228);
            this.users_zipcodeTextBox.MaxLength = 15;
            this.users_zipcodeTextBox.Name = "users_zipcodeTextBox";
            this.users_zipcodeTextBox.Size = new System.Drawing.Size(100, 20);
            this.users_zipcodeTextBox.TabIndex = 11;
            // 
            // users_cityTextBox
            // 
            this.users_cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_city", true));
            this.users_cityTextBox.Location = new System.Drawing.Point(13, 189);
            this.users_cityTextBox.MaxLength = 100;
            this.users_cityTextBox.Name = "users_cityTextBox";
            this.users_cityTextBox.Size = new System.Drawing.Size(100, 20);
            this.users_cityTextBox.TabIndex = 9;
            // 
            // users_stateTextBox
            // 
            this.users_stateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_state", true));
            this.users_stateTextBox.Location = new System.Drawing.Point(13, 150);
            this.users_stateTextBox.MaxLength = 100;
            this.users_stateTextBox.Name = "users_stateTextBox";
            this.users_stateTextBox.Size = new System.Drawing.Size(100, 20);
            this.users_stateTextBox.TabIndex = 7;
            // 
            // users_surnameTextBox
            // 
            this.users_surnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_surname", true));
            this.users_surnameTextBox.Location = new System.Drawing.Point(13, 111);
            this.users_surnameTextBox.MaxLength = 100;
            this.users_surnameTextBox.Name = "users_surnameTextBox";
            this.users_surnameTextBox.Size = new System.Drawing.Size(375, 20);
            this.users_surnameTextBox.TabIndex = 5;
            // 
            // users_aliasTextBox
            // 
            this.users_aliasTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_alias", true));
            this.users_aliasTextBox.Location = new System.Drawing.Point(13, 31);
            this.users_aliasTextBox.MaxLength = 100;
            this.users_aliasTextBox.Name = "users_aliasTextBox";
            this.users_aliasTextBox.Size = new System.Drawing.Size(375, 20);
            this.users_aliasTextBox.TabIndex = 4;
            // 
            // users_nameTextBox
            // 
            this.users_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.usersBindingSource, "users_name", true));
            this.users_nameTextBox.Location = new System.Drawing.Point(13, 72);
            this.users_nameTextBox.MaxLength = 100;
            this.users_nameTextBox.Name = "users_nameTextBox";
            this.users_nameTextBox.Size = new System.Drawing.Size(375, 20);
            this.users_nameTextBox.TabIndex = 3;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 472);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(434, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 512);
            this.panel2.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 40);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(434, 432);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.userssurnameDataGridViewTextBoxColumn,
            this.usersnameDataGridViewTextBoxColumn,
            this.usersaliasDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTableusersBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(434, 432);
            this.dataGridView_main.TabIndex = 0;
            // 
            // userssurnameDataGridViewTextBoxColumn
            // 
            this.userssurnameDataGridViewTextBoxColumn.DataPropertyName = "users_surname";
            this.userssurnameDataGridViewTextBoxColumn.HeaderText = "Surname";
            this.userssurnameDataGridViewTextBoxColumn.Name = "userssurnameDataGridViewTextBoxColumn";
            this.userssurnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.userssurnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // usersnameDataGridViewTextBoxColumn
            // 
            this.usersnameDataGridViewTextBoxColumn.DataPropertyName = "users_name";
            this.usersnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.usersnameDataGridViewTextBoxColumn.Name = "usersnameDataGridViewTextBoxColumn";
            this.usersnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.usersnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // usersaliasDataGridViewTextBoxColumn
            // 
            this.usersaliasDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.usersaliasDataGridViewTextBoxColumn.DataPropertyName = "users_alias";
            this.usersaliasDataGridViewTextBoxColumn.HeaderText = "Alias";
            this.usersaliasDataGridViewTextBoxColumn.Name = "usersaliasDataGridViewTextBoxColumn";
            this.usersaliasDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTableusersBindingSource
            // 
            this.viewDataTableusersBindingSource.DataMember = "viewDataTableusers";
            this.viewDataTableusersBindingSource.DataSource = this.dataSet01V;
            this.viewDataTableusersBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTableusersBindingSource_CurrentChanged);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(434, 512);
            this.panel1.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel_filter);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(434, 40);
            this.panel7.TabIndex = 3;
            // 
            // panel_filter
            // 
            this.panel_filter.Controls.Add(this.textBox_filter_users);
            this.panel_filter.Controls.Add(this.label1);
            this.panel_filter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filter.Location = new System.Drawing.Point(0, 0);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new System.Drawing.Size(434, 40);
            this.panel_filter.TabIndex = 3;
            // 
            // textBox_filter_users
            // 
            this.textBox_filter_users.Location = new System.Drawing.Point(132, 10);
            this.textBox_filter_users.Name = "textBox_filter_users";
            this.textBox_filter_users.Size = new System.Drawing.Size(180, 20);
            this.textBox_filter_users.TabIndex = 1;
            this.textBox_filter_users.TextChanged += new System.EventHandler(this.textBox_filter_users_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "name / surname / alias";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 472);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(434, 40);
            this.panel4.TabIndex = 1;
            // 
            // viewDataTableusersTableAdapter
            // 
            this.viewDataTableusersTableAdapter.ClearBeforeFill = true;
            // 
            // usersTableAdapter
            // 
            this.usersTableAdapter.ClearBeforeFill = true;
            // 
            // FormUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 512);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormUsers";
            this.Text = "Users";
            this.Activated += new System.EventHandler(this.FormUsers_Activated);
            this.Deactivate += new System.EventHandler(this.FormUsers_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormUsers_FormClosing);
            this.Load += new System.EventHandler(this.FormUsers_Load);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.usersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableusersBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel_filter.ResumeLayout(false);
            this.panel_filter.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel6;
        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.BindingSource viewDataTableusersBindingSource;
        private DataSet01VTableAdapters.viewDataTableusersTableAdapter viewDataTableusersTableAdapter;
        private System.Windows.Forms.BindingSource usersBindingSource;
        private DataSet01STableAdapters.usersTableAdapter usersTableAdapter;
        private System.Windows.Forms.TextBox users_notesTextBox;
        private System.Windows.Forms.TextBox users_websiteTextBox;
        private System.Windows.Forms.TextBox users_emailTextBox;
        private System.Windows.Forms.TextBox users_faxTextBox;
        private System.Windows.Forms.TextBox users_telTextBox;
        private System.Windows.Forms.TextBox users_taxcodeTextBox;
        private System.Windows.Forms.TextBox users_vatnumberTextBox;
        private System.Windows.Forms.TextBox users_streetTextBox;
        private System.Windows.Forms.TextBox users_zipcodeTextBox;
        private System.Windows.Forms.TextBox users_cityTextBox;
        private System.Windows.Forms.TextBox users_stateTextBox;
        private System.Windows.Forms.TextBox users_surnameTextBox;
        private System.Windows.Forms.TextBox users_aliasTextBox;
        private System.Windows.Forms.TextBox users_nameTextBox;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox_filter_users;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox users_invoicestextTextBox;
        private System.Windows.Forms.Panel panel_filter;
        private System.Windows.Forms.DataGridViewTextBoxColumn userssurnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usersnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usersaliasDataGridViewTextBoxColumn;
    }
}