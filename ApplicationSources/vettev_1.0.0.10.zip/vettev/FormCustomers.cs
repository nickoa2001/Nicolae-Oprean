﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Resources;

namespace vettev
{
    public partial class FormCustomers : Form
    {
        int customers_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormCustomers()
        {
            InitializeComponent();
        }

        private void FormCustomers_Load(object sender, EventArgs e)
        {
            this.viewDataTablecustomersTableAdapter.Fill(this.dataSet01V.viewDataTablecustomers);

            viewDataTablecustomersBindingSource.Sort = "customers_alias";

            subviewDataTableanimalsBindingSource.Sort = "animals_name";
            subviewDataTableinvoicesBindingSource.Sort = "invoices_date DESC";
            subviewDataTablecalendarsBindingSource.Sort = "calendars_from DESC";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
            
            tabControl_main.SelectedIndex = 0;

            loading = 0;
            viewDataTablecustomersBindingSource_CurrentChanged(null, null);
        }

        private void FormCustomers_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormCustomers_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormCustomers_Load(sender, e);
        }

        private void FormCustomers_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;
                button_Makeinvoicetext.Enabled = true;

                customers_nameTextBox.ReadOnly = false;
                customers_surnameTextBox.ReadOnly = false;
                customers_stateTextBox.ReadOnly = false;
                customers_cityTextBox.ReadOnly = false;
                customers_zipcodeTextBox.ReadOnly = false;
                customers_streetTextBox.ReadOnly = false;
                customers_vatnumberTextBox.ReadOnly = false;
                customers_taxcodeTextBox.ReadOnly = false;
                customers_telTextBox.ReadOnly = false;
                customers_faxTextBox.ReadOnly = false;
                customers_emailTextBox.ReadOnly = false;
                customers_notesTextBox.ReadOnly = false;
                customers_invoicestextTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;

                panel_filter.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Makeinvoicetext.Enabled = false;

                customers_nameTextBox.ReadOnly = true;
                customers_surnameTextBox.ReadOnly = true;
                customers_stateTextBox.ReadOnly = true;
                customers_cityTextBox.ReadOnly = true;
                customers_zipcodeTextBox.ReadOnly = true;
                customers_streetTextBox.ReadOnly = true;
                customers_vatnumberTextBox.ReadOnly = true;
                customers_taxcodeTextBox.ReadOnly = true;
                customers_telTextBox.ReadOnly = true;
                customers_faxTextBox.ReadOnly = true;
                customers_emailTextBox.ReadOnly = true;
                customers_notesTextBox.ReadOnly = true;
                customers_invoicestextTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;

                panel_filter.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            customersBindingSource.AddNew();

            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = false;
            tabPage1.Enabled = true;
            tabControl_main.SelectedIndex = 0;

            customers_dateDateTimePicker.Value = DateTime.Now;
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (customers_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);

                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = false;
                tabPage1.Enabled = true;
                tabControl_main.SelectedIndex = 0;
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (customers_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    bool candelete = true;
                    string candeletetxt = "";

                    {
                        DataSet01STableAdapters.animalsTableAdapter t = new DataSet01STableAdapters.animalsTableAdapter();
                        if (t.GetDataBy2(customers_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "animals" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }
                    
                    {
                        DataSet01STableAdapters.invoicesTableAdapter t = new DataSet01STableAdapters.invoicesTableAdapter();
                        if (t.GetDataBy5(customers_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "invoices" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    {
                        DataSet01STableAdapters.estimatesTableAdapter t = new DataSet01STableAdapters.estimatesTableAdapter();
                        if (t.GetDataBy5(customers_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "estimates" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    if (!candelete)
                    {
                        MessageBox.Show(candeletetxt);
                        return;
                    }

                    {
                        DataSet01STableAdapters.calendarsTableAdapter t = new DataSet01STableAdapters.calendarsTableAdapter();
                        DataSet01S.calendarsDataTable d = t.GetDataBy1(customers_id);
                        foreach (DataSet01S.calendarsRow r in d.Select())
                        {
                            r.Delete();
                        }
                        t.Update(d);
                    }

                    customersBindingSource.RemoveCurrent();
                    customersTableAdapter.Update(dataSet01S.customers);
                    dataSet01S.customers.AcceptChanges();

                    viewDataTablecustomersTableAdapter.Fill(dataSet01V.viewDataTablecustomers);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (customers_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            if (customers_surnameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid surname" + Environment.NewLine;
            }
            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = true;

            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            customersBindingSource.EndEdit();
            customersTableAdapter.Update(dataSet01S.customers);
            dataSet01S.customers.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = customersTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = customers_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTablecustomersTableAdapter.Fill(dataSet01V.viewDataTablecustomers);
            viewDataTablecustomersBindingSource.Position = viewDataTablecustomersBindingSource.Find("customers_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            customersBindingSource.CancelEdit();
            dataSet01S.families.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = true;
        }

        private void viewDataTablecustomersBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            customers_id = -1;

            customersBindingSource.Filter = "customers_id = -1";

            try
            {
                customers_id = (int)((DataSet01V.viewDataTablecustomersRow)((DataRowView)viewDataTablecustomersBindingSource.Current).Row).customers_id;
            }
            catch { }

            customers_dateDateTimePicker.Value = DateTime.Now;

            if (customers_id != -1)
            {
                customersTableAdapter.Fill(dataSet01S.customers, customers_id);

                customersBindingSource.RemoveFilter();
                customersBindingSource.Position = customersBindingSource.Find("customers_id", customers_id);
            }

            subviewDataTableanimalsTableAdapter.Fill(dataSet01V.subviewDataTableanimals, customers_id);
            subviewDataTableinvoicesTableAdapter.Fill(dataSet01V.subviewDataTableinvoices, customers_id);
            subviewDataTablecalendarsTableAdapter.Fill(dataSet01V.subviewDataTablecalendars, customers_id);

        }

        private void setFilter()
        {
            try
            {
                string filter_s = string.Empty;
                if (textBox_filter_customers.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    int search_id = 0;
                    try
                    {
                        int.TryParse(textBox_filter_customers.Text, out search_id);
                    }
                    catch { }
                    if (search_id != 0)
                        filter_s += "customers_id = '" + textBox_filter_customers.Text + "'";
                    else
                        filter_s +=
                            "(customers_alias LIKE '%" + textBox_filter_customers.Text + "%' OR " +
                            "customers_name LIKE '%" + textBox_filter_customers.Text + "%' OR " +
                            "customers_surname LIKE '%" + textBox_filter_customers.Text + "%')";
                }

                viewDataTablecustomersBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void textBox_filter_customers_TextChanged(object sender, EventArgs e)
        {
            setFilter();
        }

        private void button_Makeinvoicetext_Click(object sender, EventArgs e)
        {
            string invoice_text = "";
            if (customers_nameTextBox.Text.CompareTo("") != 0 && customers_surnameTextBox.Text.CompareTo("") != 0)
                invoice_text += customers_nameTextBox.Text + " " + customers_surnameTextBox.Text + Environment.NewLine;
            if (customers_streetTextBox.Text.CompareTo("") != 0)
                invoice_text += customers_streetTextBox.Text + Environment.NewLine;
            if (customers_zipcodeTextBox.Text.CompareTo("") != 0)
                invoice_text += customers_zipcodeTextBox.Text + Environment.NewLine;
            if (customers_cityTextBox.Text.CompareTo("") != 0)
                invoice_text += customers_cityTextBox.Text + Environment.NewLine;
            if (customers_taxcodeTextBox.Text.CompareTo("") != 0)
                invoice_text += Strings.T("customers_taxcodepre") + " " + customers_taxcodeTextBox.Text + Environment.NewLine;
            if (customers_vatnumberTextBox.Text.CompareTo("") != 0)
                invoice_text += Strings.T("customers_vatnumberpre") + " " + customers_vatnumberTextBox.Text + Environment.NewLine;

            customers_invoicestextTextBox.Text = invoice_text;
        }

        private void tabControl_main_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!e.TabPage.Enabled)
                e.Cancel = true;
        }
    }
}
