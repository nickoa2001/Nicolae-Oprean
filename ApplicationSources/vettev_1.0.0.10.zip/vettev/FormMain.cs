﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace vettev
{
    public partial class FormMain : Form
    {
        List<Form> formlist = new List<Form>();

        public FormMain()
        {
            InitializeComponent();

            toolStripStatusLabel_version.Text = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                return;
        }

        private void show_form(Type t)
        {
            bool loadme = true;
            Form f = null;
            foreach (Form fa in this.MdiChildren)
            {
                if (fa.GetType() == t)
                {
                    f = fa;
                    loadme = false;
                }
            }
            if (loadme)
            {
                f = (Form)Activator.CreateInstance(t);
                f.MdiParent = this;
                f.WindowState = FormWindowState.Minimized;
                f.Show();
                f.WindowState = FormWindowState.Maximized;
            }
            else
            {
                f.Show();
                f.WindowState = FormWindowState.Maximized;
            }
        }

        private void minimizeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            foreach (Form fa in this.MdiChildren)
            {
                fa.WindowState = FormWindowState.Minimized;
            }
        }

        private void closeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            foreach (Form fa in this.MdiChildren)
            {
                fa.Close();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            if (MessageBox.Show("Exit this application?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            new FormAbout().ShowDialog();
        }

        private void familiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormFamilies));
        }

        private void breedsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormBreeds));
        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormUsers));
        }

        private void customersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormCustomers));
        }

        private void animalsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormAnimals));
        }

        private void calendarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormCalendars));
        }

        private void invoicesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormInvoices));
        }

        private void estimatesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormEstimates));
        }

        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormRooms));
        }

        private void taxesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormTaxes));
        }

        private void paymentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormPayments));
        }

        private void itemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormTreatments));
        }

        private void itemsCategoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormTreatmentscategories));
        }

        private void treatmentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormTreatments));
        }

        private void treatmentsCategoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormTreatmentscategories));
        }

        private void notesTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormAnimalsnotestypes));
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormReports));
        }

        private void deductionTaxesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormTaxesdeduction));
        }

        private void computedRowsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormComputedrowsdocs));
        }

        private void documentsFootersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormFootersdocs));
        }

        private void checkDataDirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            show_form(typeof(FormCheckdatadir));
        }

        private void backupDBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Program.is_editing_mode)
                return;

            if (MessageBox.Show("Are you shure?", "Backup", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                new FormBackup().ShowDialog();
            }
        }
        
    }
}
