﻿namespace vettev
{
    partial class FormAnimalsnotestypes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label animalsnotestypes_nameLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAnimalsnotestypes));
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.animalsnotestypesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTableanimalsnotestypesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01V = new vettev.DataSet01V();
            this.dataSet01S = new vettev.DataSet01S();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Undo = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.animalsnotestypes_nameTextBox = new System.Windows.Forms.TextBox();
            this.animalsnotestypesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_Delete = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_New = new System.Windows.Forms.Button();
            this.viewDataTableanimalsnotestypesTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTableanimalsnotestypesTableAdapter();
            this.animalsnotestypesTableAdapter = new vettev.DataSet01STableAdapters.animalsnotestypesTableAdapter();
            animalsnotestypes_nameLabel = new System.Windows.Forms.Label();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableanimalsnotestypesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animalsnotestypesBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // animalsnotestypes_nameLabel
            // 
            animalsnotestypes_nameLabel.AutoSize = true;
            animalsnotestypes_nameLabel.Location = new System.Drawing.Point(10, 12);
            animalsnotestypes_nameLabel.Name = "animalsnotestypes_nameLabel";
            animalsnotestypes_nameLabel.Size = new System.Drawing.Size(36, 13);
            animalsnotestypes_nameLabel.TabIndex = 0;
            animalsnotestypes_nameLabel.Text = "name:";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(384, 422);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.animalsnotestypesnameDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTableanimalsnotestypesBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(384, 422);
            this.dataGridView_main.TabIndex = 0;
            // 
            // animalsnotestypesnameDataGridViewTextBoxColumn
            // 
            this.animalsnotestypesnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.animalsnotestypesnameDataGridViewTextBoxColumn.DataPropertyName = "animalsnotestypes_name";
            this.animalsnotestypesnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.animalsnotestypesnameDataGridViewTextBoxColumn.Name = "animalsnotestypesnameDataGridViewTextBoxColumn";
            this.animalsnotestypesnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTableanimalsnotestypesBindingSource
            // 
            this.viewDataTableanimalsnotestypesBindingSource.DataMember = "viewDataTableanimalsnotestypes";
            this.viewDataTableanimalsnotestypesBindingSource.DataSource = this.dataSet01V;
            this.viewDataTableanimalsnotestypesBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTableanimalsnotestypesBindingSource_CurrentChanged);
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 422);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(384, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 462);
            this.panel2.TabIndex = 5;
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.Controls.Add(animalsnotestypes_nameLabel);
            this.panel6.Controls.Add(this.animalsnotestypes_nameTextBox);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(300, 422);
            this.panel6.TabIndex = 1;
            // 
            // animalsnotestypes_nameTextBox
            // 
            this.animalsnotestypes_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalsnotestypesBindingSource, "animalsnotestypes_name", true));
            this.animalsnotestypes_nameTextBox.Location = new System.Drawing.Point(13, 28);
            this.animalsnotestypes_nameTextBox.Name = "animalsnotestypes_nameTextBox";
            this.animalsnotestypes_nameTextBox.Size = new System.Drawing.Size(275, 20);
            this.animalsnotestypes_nameTextBox.TabIndex = 1;
            // 
            // animalsnotestypesBindingSource
            // 
            this.animalsnotestypesBindingSource.DataMember = "animalsnotestypes";
            this.animalsnotestypesBindingSource.DataSource = this.dataSet01S;
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 462);
            this.panel1.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 422);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 40);
            this.panel4.TabIndex = 1;
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // viewDataTableanimalsnotestypesTableAdapter
            // 
            this.viewDataTableanimalsnotestypesTableAdapter.ClearBeforeFill = true;
            // 
            // animalsnotestypesTableAdapter
            // 
            this.animalsnotestypesTableAdapter.ClearBeforeFill = true;
            // 
            // FormAnimalsnotestypes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 462);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAnimalsnotestypes";
            this.Text = "Notes Types";
            this.Activated += new System.EventHandler(this.FormAnimalsnotestypes_Activated);
            this.Deactivate += new System.EventHandler(this.FormAnimalsnotestypes_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormAnimalsnotestypes_FormClosing);
            this.Load += new System.EventHandler(this.FormAnimalsnotestypes_Load);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableanimalsnotestypesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animalsnotestypesBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.BindingSource viewDataTableanimalsnotestypesBindingSource;
        private DataSet01VTableAdapters.viewDataTableanimalsnotestypesTableAdapter viewDataTableanimalsnotestypesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsnotestypesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource animalsnotestypesBindingSource;
        private DataSet01STableAdapters.animalsnotestypesTableAdapter animalsnotestypesTableAdapter;
        private System.Windows.Forms.TextBox animalsnotestypes_nameTextBox;
    }
}