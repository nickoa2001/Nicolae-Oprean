﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormAnimalsnotestypes : Form
    {
        int animalsnotestypes_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormAnimalsnotestypes()
        {
            InitializeComponent();
        }

        private void FormAnimalsnotestypes_Load(object sender, EventArgs e)
        {
            this.viewDataTableanimalsnotestypesTableAdapter.Fill(this.dataSet01V.viewDataTableanimalsnotestypes);

            viewDataTableanimalsnotestypesBindingSource.Sort = "animalsnotestypes_name";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTableanimalsnotestypesBindingSource_CurrentChanged(null, null);
        }

        private void FormAnimalsnotestypes_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }
        
        private void FormAnimalsnotestypes_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormAnimalsnotestypes_Load(sender, e);
        }

        private void FormAnimalsnotestypes_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                animalsnotestypes_nameTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                animalsnotestypes_nameTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            animalsnotestypesBindingSource.AddNew();
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (animalsnotestypes_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (animalsnotestypes_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    bool candelete = true;
                    string candeletetxt = "";

                    {
                        DataSet01STableAdapters.animalsnotesTableAdapter t = new DataSet01STableAdapters.animalsnotesTableAdapter();
                        if (t.GetDataBy1(animalsnotestypes_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "animals notes" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    if (!candelete)
                    {
                        MessageBox.Show(candeletetxt);
                        return;
                    }

                    animalsnotestypesBindingSource.RemoveCurrent();
                    animalsnotestypesTableAdapter.Update(dataSet01S.animalsnotestypes);
                    dataSet01S.animalsnotestypes.AcceptChanges();

                    viewDataTableanimalsnotestypesTableAdapter.Fill(dataSet01V.viewDataTableanimalsnotestypes);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (animalsnotestypes_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.animalsnotestypesTableAdapter t = new DataSet01STableAdapters.animalsnotestypesTableAdapter();
                if (t.GetDataBy1(animalsnotestypes_nameTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1(animalsnotestypes_nameTextBox.Text).Select("animalsnotestypes_id <> " + animalsnotestypes_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
            }
            
            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            animalsnotestypesBindingSource.EndEdit();
            animalsnotestypesTableAdapter.Update(dataSet01S.animalsnotestypes);
            dataSet01S.animalsnotestypes.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = animalsnotestypesTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = animalsnotestypes_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTableanimalsnotestypesTableAdapter.Fill(dataSet01V.viewDataTableanimalsnotestypes);
            viewDataTableanimalsnotestypesBindingSource.Position = viewDataTableanimalsnotestypesBindingSource.Find("animalsnotestypes_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            animalsnotestypesBindingSource.CancelEdit();
            dataSet01S.animalsnotestypes.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTableanimalsnotestypesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            animalsnotestypes_id = -1;

            animalsnotestypesBindingSource.Filter = "animalsnotestypes_id = -1";

            try
            {
                animalsnotestypes_id = (int)((DataSet01V.viewDataTableanimalsnotestypesRow)((DataRowView)viewDataTableanimalsnotestypesBindingSource.Current).Row).animalsnotestypes_id;
            }
            catch { }

            if (animalsnotestypes_id != -1)
            {
                animalsnotestypesTableAdapter.Fill(dataSet01S.animalsnotestypes, animalsnotestypes_id);

                animalsnotestypesBindingSource.RemoveFilter();
                animalsnotestypesBindingSource.Position = animalsnotestypesBindingSource.Find("animalsnotestypes_id", animalsnotestypes_id);
            }
        }
    }
}
