﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Calendar;

namespace vettev
{
    public partial class FormCalendars : Form
    {
        int calendars_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private const int TAB_CALENDAR_DAY = 0;
        private const int TAB_CALENDAR_WEEK = 1;
        private const int TAB_CALENDAR_MONTH = 2;

        private DateTime date_load;
        private string calendars_filter  ="";
        
        private static int loading = 1;

        public FormCalendars()
        {
            InitializeComponent();

            CalendarHighlightRange highlightrange1 = new CalendarHighlightRange();
            highlightrange1.DayOfWeek = DayOfWeek.Monday;
            highlightrange1.StartTime = TimeSpan.Parse(Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourbegin"))+":00:00");
            highlightrange1.EndTime = TimeSpan.Parse((Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourend")) + 1) + ":00:00");
            CalendarHighlightRange highlightrange2 = new CalendarHighlightRange();
            highlightrange2.DayOfWeek = DayOfWeek.Tuesday;
            highlightrange2.StartTime = TimeSpan.Parse(Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourbegin")) + ":00:00");
            highlightrange2.EndTime = TimeSpan.Parse((Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourend")) + 1) + ":00:00");
            CalendarHighlightRange highlightrange3 = new CalendarHighlightRange();
            highlightrange3.DayOfWeek = DayOfWeek.Wednesday;
            highlightrange3.StartTime = TimeSpan.Parse(Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourbegin")) + ":00:00");
            highlightrange3.EndTime = TimeSpan.Parse((Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourend")) + 1) + ":00:00");
            CalendarHighlightRange highlightrange4 = new CalendarHighlightRange();
            highlightrange4.DayOfWeek = DayOfWeek.Thursday;
            highlightrange4.StartTime = TimeSpan.Parse(Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourbegin")) + ":00:00");
            highlightrange4.EndTime = TimeSpan.Parse((Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourend")) + 1) + ":00:00");
            CalendarHighlightRange highlightrange5 = new CalendarHighlightRange();
            highlightrange5.DayOfWeek = DayOfWeek.Friday;
            highlightrange5.StartTime = TimeSpan.Parse(Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourbegin")) + ":00:00");
            highlightrange5.EndTime = TimeSpan.Parse((Convert.ToInt16(CLOptions.ReadValue("calendar_day_hourend")) + 1) + ":00:00");

            CalendarHighlightRange[] highlightrange = {highlightrange1, highlightrange2, highlightrange3, highlightrange4, highlightrange5 };

            calendar_day.HighlightRanges = highlightrange;
            calendar_day.TimeUnitsOffset = -8 * (60 / (int)calendar_day.TimeScale);
            calendar_day.AllowDrop = false;
            calendar_day.AllowItemEdit = false;
            calendar_day.AllowItemResize = false;
            calendar_day.AllowNew = false;

            calendar_week.HighlightRanges = highlightrange;
            calendar_week.TimeUnitsOffset = -8 * (60 / (int)calendar_day.TimeScale);
            calendar_week.AllowDrop = false;
            calendar_week.AllowItemEdit = false;
            calendar_week.AllowItemResize = false;
            calendar_week.AllowNew = false;

            calendar_month.HighlightRanges = highlightrange;
            calendar_month.TimeUnitsOffset = -8 * (60 / (int)calendar_day.TimeScale);
            calendar_month.AllowDrop = false;
            calendar_month.AllowItemEdit = false;
            calendar_month.AllowItemResize = false;
            calendar_month.AllowNew = false;
            calendar_month.MaximumViewDays = 42;
        }
        
        private void FormCalendar_Load(object sender, EventArgs e)
        {
            this.comboviewDataTablecustomersTableAdapter.Fill(this.dataSet01V.comboviewDataTablecustomers);
            this.comboviewDataTableroomsTableAdapter.Fill(this.dataSet01V.comboviewDataTablerooms);
            this.comboviewDataTableusersTableAdapter.Fill(this.dataSet01V.comboviewDataTableusers);
            
            comboBox_filter_rooms_id.Items.Clear();
            comboBox_filter_rooms_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTableroomsRow r in dataSet01V.comboviewDataTablerooms.Select("", "rooms_name"))
            {
                comboBox_filter_rooms_id.Items.Add(new CLItemA(r.rooms_id.ToString(), r.rooms_name.ToString()));
            }
            comboBox_filter_rooms_id.SelectedIndex = 0;

            comboBox_filter_users_id.Items.Clear();
            comboBox_filter_users_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTableusersRow r in dataSet01V.comboviewDataTableusers.Select("", "users_alias"))
            {
                comboBox_filter_users_id.Items.Add(new CLItemA(r.users_id.ToString(), r.users_alias.ToString()));
            }
            comboBox_filter_users_id.SelectedIndex = 0;

            calendars_dateDateTimePicker.Value = DateTime.Now;

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            reload_calendars();
        }

        private void FormCalendar_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormCalendars_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormCalendar_Load(sender, e);
        }

        private void FormCalendars_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                customers_idComboBox.Enabled = true;
                users_idComboBox.Enabled = true;
                rooms_idComboBox.Enabled = true;
                calendars_titleTextBox.ReadOnly = false;
                calendars_dateDateTimePicker.Enabled = true;
                calendars_fromDateTimePicker.Enabled = true;
                calendars_toDateTimePicker.Enabled = true;
                calendars_notesTextBox.ReadOnly = false;

                tabControl_main.Enabled = false;

                panel_filter.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                customers_idComboBox.Enabled = false;
                users_idComboBox.Enabled = false;
                rooms_idComboBox.Enabled = false;
                calendars_titleTextBox.ReadOnly = true;
                calendars_dateDateTimePicker.Enabled = false;
                calendars_fromDateTimePicker.Enabled = false;
                calendars_toDateTimePicker.Enabled = false;
                calendars_notesTextBox.ReadOnly = true;

                tabControl_main.Enabled = true;

                panel_filter.Enabled = true;
            }
        }

        private void calendar_day_ItemCreating(object sender, System.Windows.Forms.Calendar.CalendarItemCancelEventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            button_Delete.Enabled = false;

            calendarsBindingSource.AddNew();

            calendars_dateDateTimePicker.Value = e.Item.StartDate;
            if (e.Item.StartDate.Minute < 30)
            {
                calendars_fromDateTimePicker.Value = new DateTime(e.Item.StartDate.Year, e.Item.StartDate.Month, e.Item.StartDate.Day, e.Item.StartDate.Hour, 0, 0);
                calendars_toDateTimePicker.Value = new DateTime(e.Item.StartDate.Year, e.Item.StartDate.Month, e.Item.StartDate.Day, e.Item.StartDate.Hour, 0, 0).AddMinutes(30);
            }
            else
            {
                calendars_fromDateTimePicker.Value = new DateTime(e.Item.StartDate.Year, e.Item.StartDate.Month, e.Item.StartDate.Day, e.Item.StartDate.Hour, 30, 0);
                calendars_toDateTimePicker.Value = new DateTime(e.Item.StartDate.Year, e.Item.StartDate.Month, e.Item.StartDate.Day, e.Item.StartDate.Hour, 30, 0).AddMinutes(30);
            }

            if (comboBox_filter_rooms_id.SelectedIndex != -1 && comboBox_filter_rooms_id.SelectedIndex != 0)
            {
                rooms_idComboBox.SelectedValue = Convert.ToInt32(((CLItemA)comboBox_filter_rooms_id.SelectedItem).id);
                rooms_idComboBox.Enabled = false;
            }

            if (comboBox_filter_users_id.SelectedIndex != -1 && comboBox_filter_users_id.SelectedIndex != 0)
            {
                users_idComboBox.SelectedValue = Convert.ToInt32(((CLItemA)comboBox_filter_users_id.SelectedItem).id);
                users_idComboBox.Enabled = false;
            }

            e.Cancel = true;
        }

        private void calendar_week_ItemCreating(object sender, CalendarItemCancelEventArgs e)
        {
            calendar_day_ItemCreating(sender, e);
        }

        private void calendar_month_ItemCreating(object sender, CalendarItemCancelEventArgs e)
        {
            e.Cancel = true;
        }

        private void calendar_day_ItemClick(object sender, CalendarItemEventArgs e)
        {
            calendarsBindingSource.RemoveFilter();

            calendars_id = ((CustomCalendarItem)e.Item).calendars_id;

            if (calendars_id != -1)
            {
                calendarsTableAdapter.Fill(dataSet01S.calendars, calendars_id);
                calendarsBindingSource.Position = calendarsBindingSource.Find("calendars_id", calendars_id);

                IS_ACTION = IS_VIEW;
                setEditingMode(false);
            }
        }
        
        private void calendar_week_ItemClick(object sender, CalendarItemEventArgs e)
        {
            calendar_day_ItemClick(sender, e);
        }

        private void calendar_month_ItemClick(object sender, CalendarItemEventArgs e)
        {
            
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (calendars_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (calendars_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    calendarsBindingSource.RemoveCurrent();
                    calendarsTableAdapter.Update(dataSet01S.calendars);
                    dataSet01S.calendars.AcceptChanges();

                    IS_ACTION = IS_VIEW;
                    setEditingMode(false);

                    reload_calendars();
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (calendars_titleTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid title" + Environment.NewLine;
            }
            if (users_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a user" + Environment.NewLine;
            }
            if (rooms_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a room" + Environment.NewLine;
            }
            if (customers_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a customer" + Environment.NewLine;
            }
            if (calendars_toDateTimePicker.Value.Subtract(calendars_fromDateTimePicker.Value).TotalMinutes < 30)
            {
                valid_b = false;
                valid_s += "invalid date interval, min appointment is 30 min" + Environment.NewLine;
            }
            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            if (calendars_fromDateTimePicker.Value.Minute <= 15)
                calendars_fromDateTimePicker.Value = new DateTime(calendars_fromDateTimePicker.Value.Year, calendars_fromDateTimePicker.Value.Month, calendars_fromDateTimePicker.Value.Day, calendars_fromDateTimePicker.Value.Hour, 0, 0);
            else
                calendars_fromDateTimePicker.Value = new DateTime(calendars_fromDateTimePicker.Value.Year, calendars_fromDateTimePicker.Value.Month, calendars_fromDateTimePicker.Value.Day, calendars_fromDateTimePicker.Value.Hour, 30, 0);

            if (calendars_toDateTimePicker.Value.Minute <= 15)
                calendars_toDateTimePicker.Value = new DateTime(calendars_toDateTimePicker.Value.Year, calendars_toDateTimePicker.Value.Month, calendars_toDateTimePicker.Value.Day, calendars_toDateTimePicker.Value.Hour, 0, 0);
            else
                calendars_toDateTimePicker.Value = new DateTime(calendars_toDateTimePicker.Value.Year, calendars_toDateTimePicker.Value.Month, calendars_toDateTimePicker.Value.Day, calendars_toDateTimePicker.Value.Hour, 30, 0);

            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }

            calendarsBindingSource.EndEdit();
            calendarsTableAdapter.Update(dataSet01S.calendars);
            dataSet01S.calendars.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = calendarsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = calendars_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            monthCalendar_filter_day.SetDate(calendars_dateDateTimePicker.Value);

            reload_calendars();
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            calendarsBindingSource.CancelEdit();
            dataSet01S.calendars.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            reload_calendars();
        }

        private List<CustomCalendarItemList> calitems = null;
        private void reload_calendars()
        {
            calendars_id = -1;

            this.viewDataTablecalendarsTableAdapter.Fill(this.dataSet01V.viewDataTablecalendars,
                new DateTime(monthCalendar_filter_day.SelectionStart.Year, monthCalendar_filter_day.SelectionStart.Month, 1),
                new DateTime(monthCalendar_filter_day.SelectionStart.Year, monthCalendar_filter_day.SelectionStart.Month, 1).AddMonths(1).AddSeconds(-1));

            date_load = new DateTime(monthCalendar_filter_day.SelectionStart.Year, monthCalendar_filter_day.SelectionStart.Month, 1);

            dataSet01S.calendars.Clear();
            
            calitems = new List<CustomCalendarItemList>();
            CustomCalendarItemList cal = null;
            foreach (DataSet01V.viewDataTablecalendarsRow r in dataSet01V.viewDataTablecalendars.Select(calendars_filter, "calendars_id"))
            {
                cal = new CustomCalendarItemList();
                cal.datefromt = r.calendars_from;
                cal.dateto = r.calendars_to;
                cal.title = (r.calendars_title.Length > 100 ? r.calendars_title.Substring(0, 100) : r.calendars_title);
                cal.color = get_rooms_color(r.rooms_id);
                cal.calendars_id = r.calendars_id;
                cal.animalstreatments_id = -1;
                calitems.Add(cal);
            }         

            if (checkBox_filter_showanimalstreatments_advices.Checked)
            {
                this.subviewDataTableanimalstreatmentsTableAdapter.FillBy(this.dataSet01V.subviewDataTableanimalstreatments,
                    new DateTime(monthCalendar_filter_day.SelectionStart.Year, monthCalendar_filter_day.SelectionStart.Month, 1),
                    new DateTime(monthCalendar_filter_day.SelectionStart.Year, monthCalendar_filter_day.SelectionStart.Month, 1).AddMonths(1).AddSeconds(-1));

                foreach (DataSet01V.subviewDataTableanimalstreatmentsRow r in dataSet01V.subviewDataTableanimalstreatments.Select("", "animalstreatments_id"))
                {
                    DataSet01STableAdapters.animalstreatmentsTableAdapter animalstreatmentsTableAdapter = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                    DataSet01S.animalstreatmentsRow animalstreatmentsRow = animalstreatmentsTableAdapter.GetData(r.animalstreatments_id).First();
                    DataSet01STableAdapters.animalsTableAdapter animalsTableAdapter = new DataSet01STableAdapters.animalsTableAdapter();
                    DataSet01S.animalsRow animalsRow = animalsTableAdapter.GetData(animalstreatmentsRow.animals_id).First();
                    DataSet01STableAdapters.customersTableAdapter customersTableAdapter = new DataSet01STableAdapters.customersTableAdapter();
                    DataSet01S.customersRow customersRow = customersTableAdapter.GetData(animalsRow.customers_id).First();

                    cal = new CustomCalendarItemList();
                    cal.datefromt = animalstreatmentsRow.animalstreatments_expiration.AddHours(12);
                    cal.dateto = animalstreatmentsRow.animalstreatments_expiration.AddHours(13);
                    cal.title = "[adv] " + customersRow.customers_alias + " - " + animalsRow.animals_name;
                    cal.calendars_id = -1;
                    cal.animalstreatments_id = r.animalstreatments_id;
                    cal.animalstreatments_id = -1;
                    calitems.Add(cal);
                }

            }

            reload_calendarsitems();
        }

        private void reload_calendarsitems()
        {
            if (tabControl_main.SelectedIndex == TAB_CALENDAR_DAY)
            {
                calendar_day.SetViewRange(monthCalendar_filter_day.SelectionStart, monthCalendar_filter_day.SelectionStart);

                calendar_day.Items.Clear();

                foreach (CustomCalendarItemList item in calitems) { 
                    CustomCalendarItem cal = new CustomCalendarItem(calendar_day,
                        item.datefromt,
                        item.dateto,
                        item.title);
                    cal.calendars_id = item.calendars_id;
                    cal.animalstreatments_id = -1;
                    cal.ApplyColor(item.color);

                    if (calendar_day.ViewIntersects(cal))
                        calendar_day.Items.Add(cal);
                }

                calendar_day.Invalidate();
            }
            else if (tabControl_main.SelectedIndex == TAB_CALENDAR_WEEK)
            {
                DateTime firstDayInWeek = monthCalendar_filter_day.SelectionStart.AddDays(DayOfWeek.Monday - monthCalendar_filter_day.SelectionStart.DayOfWeek);
                calendar_week.SetViewRange(firstDayInWeek, firstDayInWeek.AddDays(6));

                calendar_week.Items.Clear();

                foreach (CustomCalendarItemList item in calitems)
                {
                    CustomCalendarItem cal = new CustomCalendarItem(calendar_week,
                        item.datefromt,
                        item.dateto,
                        item.title);
                    cal.calendars_id = item.calendars_id;
                    cal.animalstreatments_id = -1;
                    cal.ApplyColor(item.color);

                    if (calendar_week.ViewIntersects(cal))
                        calendar_week.Items.Add(cal);
                }

                calendar_week.Invalidate();
            }
            else if (tabControl_main.SelectedIndex == TAB_CALENDAR_MONTH)
            {
                DateTime firstDayOfTheMonth = new DateTime(monthCalendar_filter_day.SelectionStart.Year, monthCalendar_filter_day.SelectionStart.Month, 1);
                calendar_month.SetViewRange(firstDayOfTheMonth, firstDayOfTheMonth.AddDays(35));

                calendar_month.Items.Clear();

                foreach (CustomCalendarItemList item in calitems)
                {
                    CustomCalendarItem cal = new CustomCalendarItem(calendar_month,
                        item.datefromt,
                        item.dateto,
                        item.title);
                    cal.calendars_id = item.calendars_id;
                    cal.animalstreatments_id = -1;
                    cal.ApplyColor(item.color);

                    if (calendar_month.ViewIntersects(cal))
                        calendar_month.Items.Add(cal);
                }

                calendar_month.Invalidate();
            }
        }

        private void tabControl_main_SelectedIndexChanged(object sender, EventArgs e)
        {
            calendars_id = -1;
            calendarsBindingSource.Filter = "calendars_id = -1";

            reload_calendarsitems();
        }
        
        private void calendars_dateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            calendars_fromDateTimePicker.Value = new DateTime(calendars_dateDateTimePicker.Value.Year, calendars_dateDateTimePicker.Value.Month, calendars_dateDateTimePicker.Value.Day, calendars_fromDateTimePicker.Value.Hour, calendars_fromDateTimePicker.Value.Minute, 0);
            calendars_toDateTimePicker.Value = new DateTime(calendars_dateDateTimePicker.Value.Year, calendars_dateDateTimePicker.Value.Month, calendars_dateDateTimePicker.Value.Day, calendars_toDateTimePicker.Value.Hour, calendars_toDateTimePicker.Value.Minute, 0);
        }

        private void setFilter()
        {
            try
            {
                string filter_s = string.Empty;
                if (comboBox_filter_users_id.SelectedIndex != -1 && comboBox_filter_users_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "users_id = '" + Convert.ToInt32(((CLItemA)comboBox_filter_users_id.SelectedItem).id) + "'";
                }
                if (comboBox_filter_rooms_id.SelectedIndex != -1 && comboBox_filter_rooms_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "rooms_id = '" + Convert.ToInt32(((CLItemA)comboBox_filter_rooms_id.SelectedItem).id) + "'";
                }

                calendars_filter = filter_s;

                reload_calendars();
            }
            catch { }
        }

        private void comboBox_filter_users_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            setFilter();
        }

        private void comboBox_filter_rooms_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            setFilter();
        }

        private void checkBox_filter_showanimalstreatments_advices_CheckedChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            setFilter();
        }

        private void monthCalendar_filter_DateChanged(object sender, DateRangeEventArgs e)
        {
            if (loading == 1)
                return;

            if (date_load != new DateTime(monthCalendar_filter_day.SelectionStart.Year, monthCalendar_filter_day.SelectionStart.Month, 1))
            {
                reload_calendars();
            }
            else
            {
                reload_calendarsitems();
            }
        }

        private Color get_rooms_color(int id)
        {
            Random randomGen = new Random(id);
            return Color.FromArgb(randomGen.Next(0, 255), randomGen.Next(0, 255), randomGen.Next(0, 255));
        }

        private void calendar_day_ItemSelected(object sender, CalendarItemEventArgs e)
        {
            Random randomGen = new Random();
        }

        private void calendar_day_ItemDeleting(object sender, CalendarItemCancelEventArgs e)
        {
            e.Cancel = true;
        }

    }

    public class CustomCalendarItemList
    {
        private DateTime _datefrom;
        public DateTime datefromt
        {
            get { return _datefrom; }
            set { _datefrom = value; }
        }

        private DateTime _dateto;
        public DateTime dateto
        {
            get { return _dateto; }
            set { _dateto = value; }
        }

        private String _title;
        public String title
        {
            get { return _title; }
            set { _title = value; }
        }

        private Color _color;
        public Color color
        {
            get { return _color; }
            set { _color = value; }
        }

        private int _calendars_id;
        public int calendars_id
        {
            get { return _calendars_id; }
            set { _calendars_id = value; }
        }

        private int _animalstreatments_id;
        public int animalstreatments_id
        {
            get { return _animalstreatments_id; }
            set { _animalstreatments_id = value; }
        }
    }

    public class CustomCalendarItem : CalendarItem
    {
        public CustomCalendarItem(Calendar calendar, DateTime startDate, DateTime endDate, string text) : base(calendar, startDate, endDate, text) { }
        
        private int _calendars_id;
        public int calendars_id
        {
            get { return _calendars_id; }
            set { _calendars_id = value; }
        }

        private int _animalstreatments_id;
        public int animalstreatments_id
        {
            get { return _animalstreatments_id; }
            set { _animalstreatments_id = value; }
        }
    }
}
