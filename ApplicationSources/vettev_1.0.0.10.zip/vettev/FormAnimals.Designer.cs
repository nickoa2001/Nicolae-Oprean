﻿namespace vettev
{
    partial class FormAnimals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label animals_tagLabel;
            System.Windows.Forms.Label animals_nameLabel;
            System.Windows.Forms.Label breeds_idLabel;
            System.Windows.Forms.Label customers_idLabel;
            System.Windows.Forms.Label animals_birthLabel;
            System.Windows.Forms.Label animals_deathLabel;
            System.Windows.Forms.Label animals_notesLabel;
            System.Windows.Forms.Label animals_sexLabel;
            System.Windows.Forms.Label animals_dateLabel;
            System.Windows.Forms.Label animalsnotestypes_idLabel;
            System.Windows.Forms.Label animalsnotes_dateLabel;
            System.Windows.Forms.Label animalsnotes_notesLabel;
            System.Windows.Forms.Label users_idLabel;
            System.Windows.Forms.Label users_idLabel1;
            System.Windows.Forms.Label paystatus_idLabel;
            System.Windows.Forms.Label animalstreatments_dateLabel;
            System.Windows.Forms.Label animalstreatments_notesLabel;
            System.Windows.Forms.Label animalstreatments_expirationLabel;
            System.Windows.Forms.Label animalstreatments_priceLabel;
            System.Windows.Forms.Label animalstreatments_descLabel;
            System.Windows.Forms.Label animals_idLabel;
            System.Windows.Forms.Label treatmentscategories_idLabel;
            System.Windows.Forms.Label animalstreatments_codeLabel;
            System.Windows.Forms.Label animals_sterilizedLabel;
            System.Windows.Forms.Label animalstreatments_idLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAnimals));
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.animalsidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.familiesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.breedsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTableanimalsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01V = new vettev.DataSet01V();
            this.dataSet01S = new vettev.DataSet01S();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tabControl_main = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel15 = new System.Windows.Forms.Panel();
            this.animals_sterilized_NradioButton = new System.Windows.Forms.RadioButton();
            this.animals_sterilized_YradioButton = new System.Windows.Forms.RadioButton();
            this.animals_sterilized_UradioButton = new System.Windows.Forms.RadioButton();
            this.customers_aliasTextBox = new System.Windows.Forms.TextBox();
            this.customers_idTextBox = new System.Windows.Forms.TextBox();
            this.animalsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.animals_idTextBox = new System.Windows.Forms.TextBox();
            this.animals_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.button_Opendatadir = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.animals_sex_FradioButton = new System.Windows.Forms.RadioButton();
            this.animals_sex_MradioButton = new System.Windows.Forms.RadioButton();
            this.animals_sex_UradioButton = new System.Windows.Forms.RadioButton();
            this.animals_notesTextBox = new System.Windows.Forms.TextBox();
            this.animals_birthunknowncheckBox = new System.Windows.Forms.CheckBox();
            this.checkBox_isdeath = new System.Windows.Forms.CheckBox();
            this.animals_deathDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.animals_birthDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.breeds_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTablebreedsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.animals_nameTextBox = new System.Windows.Forms.TextBox();
            this.animals_tagTextBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel14 = new System.Windows.Forms.Panel();
            this.dataGridView_animalstreatmentsmain = new System.Windows.Forms.DataGridView();
            this.animalstreatmentsidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalstreatmentscodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentscategoriesnameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paystatusnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalstreatmentsdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalstreatmentsdescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTableanimalstreatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel13 = new System.Windows.Forms.Panel();
            this.animalstreatments_idTextBox = new System.Windows.Forms.TextBox();
            this.animalstreatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textBox_animalstreatments_invoicesinfo = new System.Windows.Forms.TextBox();
            this.animalstreatments_invoiceableCheckBox = new System.Windows.Forms.CheckBox();
            this.button_animalstreatmentsDelete = new System.Windows.Forms.Button();
            this.button_animalstreatmentsEdit = new System.Windows.Forms.Button();
            this.animalstreatments_codeTextBox = new System.Windows.Forms.TextBox();
            this.button_animalstreatmentsNew = new System.Windows.Forms.Button();
            this.animalstreatments_expirationadviceCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox_animalstreatments_fillfromtreatments = new System.Windows.Forms.GroupBox();
            this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id = new System.Windows.Forms.ComboBox();
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name = new System.Windows.Forms.TextBox();
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code = new System.Windows.Forms.TextBox();
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain = new System.Windows.Forms.DataGridView();
            this.treatmentscodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentscategoriesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentsdescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comboviewDataTabletreatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_animalstreatmentsfillfromtreatments = new System.Windows.Forms.Button();
            this.animalstreatmentstreatmentscategories_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTabletreatmentscategoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.animalstreatmentsusers_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTableusersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.animalstreatments_descTextBox = new System.Windows.Forms.TextBox();
            this.animalstreatmentspaystatus_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTablepaystatusBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.checkBox_animalstreatments_expirationdate = new System.Windows.Forms.CheckBox();
            this.animalstreatments_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.animalstreatments_priceTextBox = new System.Windows.Forms.TextBox();
            this.animalstreatments_notesTextBox = new System.Windows.Forms.TextBox();
            this.animalstreatments_expirationDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel_animalstreatmentsfilter = new System.Windows.Forms.Panel();
            this.textBox_animalstreatmentsfilter_animalstreatments_date = new System.Windows.Forms.TextBox();
            this.comboBox_animalstreatmentsfilter_treamtentscategories_id = new System.Windows.Forms.ComboBox();
            this.textBox_animalstreatmentsfilter_animalstreatments_code = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel11 = new System.Windows.Forms.Panel();
            this.dataGridView_animalsnotesmain = new System.Windows.Forms.DataGridView();
            this.animalsnotestypesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalsnotesdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalsnotesnotesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTableanimalsnotesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel10 = new System.Windows.Forms.Panel();
            this.animalsnotesusers_idComboBox = new System.Windows.Forms.ComboBox();
            this.animalsnotesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_animalsnotesDelete = new System.Windows.Forms.Button();
            this.button_animalsnotesEdit = new System.Windows.Forms.Button();
            this.button_animalsnotesNew = new System.Windows.Forms.Button();
            this.animalsnotestypes_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTableanimalsnotestypesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.animalsnotes_notesTextBox = new System.Windows.Forms.TextBox();
            this.animalsnotes_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel_animalsnotesfilter = new System.Windows.Forms.Panel();
            this.comboBox_animalsnotesfilter_animalsnotestypes_id = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Stopedit = new System.Windows.Forms.Button();
            this.button_Undo = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.comboviewDataTablecustomersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel_filter = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_filter_animals = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_filter_customers_id = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_Print = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_New = new System.Windows.Forms.Button();
            this.viewDataTableanimalsTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTableanimalsTableAdapter();
            this.animalsTableAdapter = new vettev.DataSet01STableAdapters.animalsTableAdapter();
            this.comboviewDataTablebreedsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablebreedsTableAdapter();
            this.subviewDataTableanimalsnotesTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableanimalsnotesTableAdapter();
            this.animalsnotesTableAdapter = new vettev.DataSet01STableAdapters.animalsnotesTableAdapter();
            this.comboviewDataTablecustomersTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablecustomersTableAdapter();
            this.comboviewDataTableanimalsnotestypesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTableanimalsnotestypesTableAdapter();
            this.comboviewDataTableusersTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTableusersTableAdapter();
            this.subviewDataTableanimalstreatmentsTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableanimalstreatmentsTableAdapter();
            this.animalstreatmentsTableAdapter = new vettev.DataSet01STableAdapters.animalstreatmentsTableAdapter();
            this.comboviewDataTabletreatmentscategoriesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletreatmentscategoriesTableAdapter();
            this.comboviewDataTablepaystatusTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablepaystatusTableAdapter();
            this.comboviewDataTabletreatmentsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletreatmentsTableAdapter();
            this.tableAdapterManager = new vettev.DataSet01STableAdapters.TableAdapterManager();
            animals_tagLabel = new System.Windows.Forms.Label();
            animals_nameLabel = new System.Windows.Forms.Label();
            breeds_idLabel = new System.Windows.Forms.Label();
            customers_idLabel = new System.Windows.Forms.Label();
            animals_birthLabel = new System.Windows.Forms.Label();
            animals_deathLabel = new System.Windows.Forms.Label();
            animals_notesLabel = new System.Windows.Forms.Label();
            animals_sexLabel = new System.Windows.Forms.Label();
            animals_dateLabel = new System.Windows.Forms.Label();
            animalsnotestypes_idLabel = new System.Windows.Forms.Label();
            animalsnotes_dateLabel = new System.Windows.Forms.Label();
            animalsnotes_notesLabel = new System.Windows.Forms.Label();
            users_idLabel = new System.Windows.Forms.Label();
            users_idLabel1 = new System.Windows.Forms.Label();
            paystatus_idLabel = new System.Windows.Forms.Label();
            animalstreatments_dateLabel = new System.Windows.Forms.Label();
            animalstreatments_notesLabel = new System.Windows.Forms.Label();
            animalstreatments_expirationLabel = new System.Windows.Forms.Label();
            animalstreatments_priceLabel = new System.Windows.Forms.Label();
            animalstreatments_descLabel = new System.Windows.Forms.Label();
            animals_idLabel = new System.Windows.Forms.Label();
            treatmentscategories_idLabel = new System.Windows.Forms.Label();
            animalstreatments_codeLabel = new System.Windows.Forms.Label();
            animals_sterilizedLabel = new System.Windows.Forms.Label();
            animalstreatments_idLabel = new System.Windows.Forms.Label();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableanimalsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabControl_main.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animalsBindingSource)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablebreedsBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_animalstreatmentsmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableanimalstreatmentsBindingSource)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animalstreatmentsBindingSource)).BeginInit();
            this.groupBox_animalstreatments_fillfromtreatments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_animalstreatmentsfillfromtreatmentsmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentscategoriesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableusersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablepaystatusBindingSource)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel_animalstreatmentsfilter.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_animalsnotesmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableanimalsnotesBindingSource)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animalsnotesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableanimalsnotestypesBindingSource)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel_animalsnotesfilter.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecustomersBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel_filter.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // animals_tagLabel
            // 
            animals_tagLabel.AutoSize = true;
            animals_tagLabel.Location = new System.Drawing.Point(133, 15);
            animals_tagLabel.Name = "animals_tagLabel";
            animals_tagLabel.Size = new System.Drawing.Size(25, 13);
            animals_tagLabel.TabIndex = 0;
            animals_tagLabel.Text = "tag:";
            // 
            // animals_nameLabel
            // 
            animals_nameLabel.AutoSize = true;
            animals_nameLabel.Location = new System.Drawing.Point(11, 54);
            animals_nameLabel.Name = "animals_nameLabel";
            animals_nameLabel.Size = new System.Drawing.Size(36, 13);
            animals_nameLabel.TabIndex = 2;
            animals_nameLabel.Text = "name:";
            // 
            // breeds_idLabel
            // 
            breeds_idLabel.AutoSize = true;
            breeds_idLabel.Location = new System.Drawing.Point(11, 93);
            breeds_idLabel.Name = "breeds_idLabel";
            breeds_idLabel.Size = new System.Drawing.Size(37, 13);
            breeds_idLabel.TabIndex = 4;
            breeds_idLabel.Text = "breed:";
            // 
            // customers_idLabel
            // 
            customers_idLabel.AutoSize = true;
            customers_idLabel.Location = new System.Drawing.Point(11, 133);
            customers_idLabel.Name = "customers_idLabel";
            customers_idLabel.Size = new System.Drawing.Size(53, 13);
            customers_idLabel.TabIndex = 6;
            customers_idLabel.Text = "customer:";
            // 
            // animals_birthLabel
            // 
            animals_birthLabel.AutoSize = true;
            animals_birthLabel.Location = new System.Drawing.Point(11, 173);
            animals_birthLabel.Name = "animals_birthLabel";
            animals_birthLabel.Size = new System.Drawing.Size(30, 13);
            animals_birthLabel.TabIndex = 8;
            animals_birthLabel.Text = "birth:";
            // 
            // animals_deathLabel
            // 
            animals_deathLabel.AutoSize = true;
            animals_deathLabel.Location = new System.Drawing.Point(231, 173);
            animals_deathLabel.Name = "animals_deathLabel";
            animals_deathLabel.Size = new System.Drawing.Size(37, 13);
            animals_deathLabel.TabIndex = 10;
            animals_deathLabel.Text = "death:";
            // 
            // animals_notesLabel
            // 
            animals_notesLabel.AutoSize = true;
            animals_notesLabel.Location = new System.Drawing.Point(11, 212);
            animals_notesLabel.Name = "animals_notesLabel";
            animals_notesLabel.Size = new System.Drawing.Size(36, 13);
            animals_notesLabel.TabIndex = 14;
            animals_notesLabel.Text = "notes:";
            // 
            // animals_sexLabel
            // 
            animals_sexLabel.AutoSize = true;
            animals_sexLabel.Location = new System.Drawing.Point(231, 93);
            animals_sexLabel.Name = "animals_sexLabel";
            animals_sexLabel.Size = new System.Drawing.Size(26, 13);
            animals_sexLabel.TabIndex = 15;
            animals_sexLabel.Text = "sex:";
            // 
            // animals_dateLabel
            // 
            animals_dateLabel.AutoSize = true;
            animals_dateLabel.Location = new System.Drawing.Point(455, 15);
            animals_dateLabel.Name = "animals_dateLabel";
            animals_dateLabel.Size = new System.Drawing.Size(47, 13);
            animals_dateLabel.TabIndex = 20;
            animals_dateLabel.Text = "inserted:";
            // 
            // animalsnotestypes_idLabel
            // 
            animalsnotestypes_idLabel.AutoSize = true;
            animalsnotestypes_idLabel.Location = new System.Drawing.Point(162, 40);
            animalsnotestypes_idLabel.Name = "animalsnotestypes_idLabel";
            animalsnotestypes_idLabel.Size = new System.Drawing.Size(30, 13);
            animalsnotestypes_idLabel.TabIndex = 0;
            animalsnotestypes_idLabel.Text = "type:";
            // 
            // animalsnotes_dateLabel
            // 
            animalsnotes_dateLabel.AutoSize = true;
            animalsnotes_dateLabel.Location = new System.Drawing.Point(322, 40);
            animalsnotes_dateLabel.Name = "animalsnotes_dateLabel";
            animalsnotes_dateLabel.Size = new System.Drawing.Size(31, 13);
            animalsnotes_dateLabel.TabIndex = 2;
            animalsnotes_dateLabel.Text = "date:";
            // 
            // animalsnotes_notesLabel
            // 
            animalsnotes_notesLabel.AutoSize = true;
            animalsnotes_notesLabel.Location = new System.Drawing.Point(10, 80);
            animalsnotes_notesLabel.Name = "animalsnotes_notesLabel";
            animalsnotes_notesLabel.Size = new System.Drawing.Size(36, 13);
            animalsnotes_notesLabel.TabIndex = 4;
            animalsnotes_notesLabel.Text = "notes:";
            // 
            // users_idLabel
            // 
            users_idLabel.AutoSize = true;
            users_idLabel.Location = new System.Drawing.Point(10, 40);
            users_idLabel.Name = "users_idLabel";
            users_idLabel.Size = new System.Drawing.Size(30, 13);
            users_idLabel.TabIndex = 8;
            users_idLabel.Text = "user:";
            // 
            // users_idLabel1
            // 
            users_idLabel1.AutoSize = true;
            users_idLabel1.Location = new System.Drawing.Point(133, 40);
            users_idLabel1.Name = "users_idLabel1";
            users_idLabel1.Size = new System.Drawing.Size(30, 13);
            users_idLabel1.TabIndex = 8;
            users_idLabel1.Text = "user:";
            // 
            // paystatus_idLabel
            // 
            paystatus_idLabel.AutoSize = true;
            paystatus_idLabel.Location = new System.Drawing.Point(133, 120);
            paystatus_idLabel.Name = "paystatus_idLabel";
            paystatus_idLabel.Size = new System.Drawing.Size(55, 13);
            paystatus_idLabel.TabIndex = 9;
            paystatus_idLabel.Text = "paystatus:";
            // 
            // animalstreatments_dateLabel
            // 
            animalstreatments_dateLabel.AutoSize = true;
            animalstreatments_dateLabel.Location = new System.Drawing.Point(310, 41);
            animalstreatments_dateLabel.Name = "animalstreatments_dateLabel";
            animalstreatments_dateLabel.Size = new System.Drawing.Size(31, 13);
            animalstreatments_dateLabel.TabIndex = 11;
            animalstreatments_dateLabel.Text = "date:";
            // 
            // animalstreatments_notesLabel
            // 
            animalstreatments_notesLabel.AutoSize = true;
            animalstreatments_notesLabel.Location = new System.Drawing.Point(331, 158);
            animalstreatments_notesLabel.Name = "animalstreatments_notesLabel";
            animalstreatments_notesLabel.Size = new System.Drawing.Size(36, 13);
            animalstreatments_notesLabel.TabIndex = 12;
            animalstreatments_notesLabel.Text = "notes:";
            // 
            // animalstreatments_expirationLabel
            // 
            animalstreatments_expirationLabel.AutoSize = true;
            animalstreatments_expirationLabel.Location = new System.Drawing.Point(310, 81);
            animalstreatments_expirationLabel.Name = "animalstreatments_expirationLabel";
            animalstreatments_expirationLabel.Size = new System.Drawing.Size(38, 13);
            animalstreatments_expirationLabel.TabIndex = 13;
            animalstreatments_expirationLabel.Text = "expire:";
            // 
            // animalstreatments_priceLabel
            // 
            animalstreatments_priceLabel.AutoSize = true;
            animalstreatments_priceLabel.Location = new System.Drawing.Point(10, 80);
            animalstreatments_priceLabel.Name = "animalstreatments_priceLabel";
            animalstreatments_priceLabel.Size = new System.Drawing.Size(33, 13);
            animalstreatments_priceLabel.TabIndex = 14;
            animalstreatments_priceLabel.Text = "price:";
            // 
            // animalstreatments_descLabel
            // 
            animalstreatments_descLabel.AutoSize = true;
            animalstreatments_descLabel.Location = new System.Drawing.Point(11, 158);
            animalstreatments_descLabel.Name = "animalstreatments_descLabel";
            animalstreatments_descLabel.Size = new System.Drawing.Size(61, 13);
            animalstreatments_descLabel.TabIndex = 19;
            animalstreatments_descLabel.Text = "description:";
            // 
            // animals_idLabel
            // 
            animals_idLabel.AutoSize = true;
            animals_idLabel.Location = new System.Drawing.Point(10, 15);
            animals_idLabel.Name = "animals_idLabel";
            animals_idLabel.Size = new System.Drawing.Size(18, 13);
            animals_idLabel.TabIndex = 21;
            animals_idLabel.Text = "id:";
            // 
            // treatmentscategories_idLabel
            // 
            treatmentscategories_idLabel.AutoSize = true;
            treatmentscategories_idLabel.Location = new System.Drawing.Point(133, 80);
            treatmentscategories_idLabel.Name = "treatmentscategories_idLabel";
            treatmentscategories_idLabel.Size = new System.Drawing.Size(51, 13);
            treatmentscategories_idLabel.TabIndex = 20;
            treatmentscategories_idLabel.Text = "category:";
            // 
            // animalstreatments_codeLabel
            // 
            animalstreatments_codeLabel.AutoSize = true;
            animalstreatments_codeLabel.Location = new System.Drawing.Point(10, 119);
            animalstreatments_codeLabel.Name = "animalstreatments_codeLabel";
            animalstreatments_codeLabel.Size = new System.Drawing.Size(34, 13);
            animalstreatments_codeLabel.TabIndex = 22;
            animalstreatments_codeLabel.Text = "code:";
            // 
            // animals_sterilizedLabel
            // 
            animals_sterilizedLabel.AutoSize = true;
            animals_sterilizedLabel.Location = new System.Drawing.Point(402, 93);
            animals_sterilizedLabel.Name = "animals_sterilizedLabel";
            animals_sterilizedLabel.Size = new System.Drawing.Size(50, 13);
            animals_sterilizedLabel.TabIndex = 26;
            animals_sterilizedLabel.Text = "sterilized:";
            // 
            // animalstreatments_idLabel
            // 
            animalstreatments_idLabel.AutoSize = true;
            animalstreatments_idLabel.Location = new System.Drawing.Point(10, 40);
            animalstreatments_idLabel.Name = "animalstreatments_idLabel";
            animalstreatments_idLabel.Size = new System.Drawing.Size(18, 13);
            animalstreatments_idLabel.TabIndex = 26;
            animalstreatments_idLabel.Text = "id:";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 60);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(384, 537);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.animalsidDataGridViewTextBoxColumn,
            this.familiesnameDataGridViewTextBoxColumn,
            this.breedsnameDataGridViewTextBoxColumn,
            this.animalsnameDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTableanimalsBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(384, 537);
            this.dataGridView_main.TabIndex = 0;
            // 
            // animalsidDataGridViewTextBoxColumn
            // 
            this.animalsidDataGridViewTextBoxColumn.DataPropertyName = "animals_id";
            this.animalsidDataGridViewTextBoxColumn.HeaderText = "Id";
            this.animalsidDataGridViewTextBoxColumn.Name = "animalsidDataGridViewTextBoxColumn";
            this.animalsidDataGridViewTextBoxColumn.ReadOnly = true;
            this.animalsidDataGridViewTextBoxColumn.Width = 50;
            // 
            // familiesnameDataGridViewTextBoxColumn
            // 
            this.familiesnameDataGridViewTextBoxColumn.DataPropertyName = "families_name";
            this.familiesnameDataGridViewTextBoxColumn.HeaderText = "Family";
            this.familiesnameDataGridViewTextBoxColumn.Name = "familiesnameDataGridViewTextBoxColumn";
            this.familiesnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.familiesnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // breedsnameDataGridViewTextBoxColumn
            // 
            this.breedsnameDataGridViewTextBoxColumn.DataPropertyName = "breeds_name";
            this.breedsnameDataGridViewTextBoxColumn.HeaderText = "Breed";
            this.breedsnameDataGridViewTextBoxColumn.Name = "breedsnameDataGridViewTextBoxColumn";
            this.breedsnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.breedsnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // animalsnameDataGridViewTextBoxColumn
            // 
            this.animalsnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.animalsnameDataGridViewTextBoxColumn.DataPropertyName = "animals_name";
            this.animalsnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.animalsnameDataGridViewTextBoxColumn.Name = "animalsnameDataGridViewTextBoxColumn";
            this.animalsnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTableanimalsBindingSource
            // 
            this.viewDataTableanimalsBindingSource.DataMember = "viewDataTableanimals";
            this.viewDataTableanimalsBindingSource.DataSource = this.dataSet01V;
            this.viewDataTableanimalsBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTableanimalsBindingSource_CurrentChanged);
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(384, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 662);
            this.panel2.TabIndex = 5;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.tabControl_main);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(600, 622);
            this.panel6.TabIndex = 1;
            // 
            // tabControl_main
            // 
            this.tabControl_main.Controls.Add(this.tabPage1);
            this.tabControl_main.Controls.Add(this.tabPage2);
            this.tabControl_main.Controls.Add(this.tabPage3);
            this.tabControl_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_main.Location = new System.Drawing.Point(0, 0);
            this.tabControl_main.Name = "tabControl_main";
            this.tabControl_main.SelectedIndex = 0;
            this.tabControl_main.Size = new System.Drawing.Size(600, 622);
            this.tabControl_main.TabIndex = 0;
            this.tabControl_main.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_main_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(animals_sterilizedLabel);
            this.tabPage1.Controls.Add(this.panel15);
            this.tabPage1.Controls.Add(this.customers_aliasTextBox);
            this.tabPage1.Controls.Add(this.customers_idTextBox);
            this.tabPage1.Controls.Add(animals_idLabel);
            this.tabPage1.Controls.Add(this.animals_idTextBox);
            this.tabPage1.Controls.Add(animals_dateLabel);
            this.tabPage1.Controls.Add(this.animals_dateDateTimePicker);
            this.tabPage1.Controls.Add(this.button_Opendatadir);
            this.tabPage1.Controls.Add(this.panel8);
            this.tabPage1.Controls.Add(this.animals_notesTextBox);
            this.tabPage1.Controls.Add(this.animals_birthunknowncheckBox);
            this.tabPage1.Controls.Add(this.checkBox_isdeath);
            this.tabPage1.Controls.Add(animals_sexLabel);
            this.tabPage1.Controls.Add(animals_notesLabel);
            this.tabPage1.Controls.Add(animals_deathLabel);
            this.tabPage1.Controls.Add(this.animals_deathDateTimePicker);
            this.tabPage1.Controls.Add(animals_birthLabel);
            this.tabPage1.Controls.Add(this.animals_birthDateTimePicker);
            this.tabPage1.Controls.Add(customers_idLabel);
            this.tabPage1.Controls.Add(breeds_idLabel);
            this.tabPage1.Controls.Add(this.breeds_idComboBox);
            this.tabPage1.Controls.Add(animals_nameLabel);
            this.tabPage1.Controls.Add(this.animals_nameTextBox);
            this.tabPage1.Controls.Add(animals_tagLabel);
            this.tabPage1.Controls.Add(this.animals_tagTextBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(592, 596);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Info";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.animals_sterilized_NradioButton);
            this.panel15.Controls.Add(this.animals_sterilized_YradioButton);
            this.panel15.Controls.Add(this.animals_sterilized_UradioButton);
            this.panel15.Location = new System.Drawing.Point(405, 109);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(165, 24);
            this.panel15.TabIndex = 25;
            // 
            // animals_sterilized_NradioButton
            // 
            this.animals_sterilized_NradioButton.AutoSize = true;
            this.animals_sterilized_NradioButton.Location = new System.Drawing.Point(115, 3);
            this.animals_sterilized_NradioButton.Name = "animals_sterilized_NradioButton";
            this.animals_sterilized_NradioButton.Size = new System.Drawing.Size(33, 17);
            this.animals_sterilized_NradioButton.TabIndex = 2;
            this.animals_sterilized_NradioButton.Text = "N";
            this.animals_sterilized_NradioButton.UseVisualStyleBackColor = true;
            // 
            // animals_sterilized_YradioButton
            // 
            this.animals_sterilized_YradioButton.AutoSize = true;
            this.animals_sterilized_YradioButton.Location = new System.Drawing.Point(77, 3);
            this.animals_sterilized_YradioButton.Name = "animals_sterilized_YradioButton";
            this.animals_sterilized_YradioButton.Size = new System.Drawing.Size(32, 17);
            this.animals_sterilized_YradioButton.TabIndex = 1;
            this.animals_sterilized_YradioButton.Text = "Y";
            this.animals_sterilized_YradioButton.UseVisualStyleBackColor = true;
            // 
            // animals_sterilized_UradioButton
            // 
            this.animals_sterilized_UradioButton.AutoSize = true;
            this.animals_sterilized_UradioButton.Checked = true;
            this.animals_sterilized_UradioButton.Location = new System.Drawing.Point(3, 4);
            this.animals_sterilized_UradioButton.Name = "animals_sterilized_UradioButton";
            this.animals_sterilized_UradioButton.Size = new System.Drawing.Size(71, 17);
            this.animals_sterilized_UradioButton.TabIndex = 0;
            this.animals_sterilized_UradioButton.TabStop = true;
            this.animals_sterilized_UradioButton.Text = "Unknown";
            this.animals_sterilized_UradioButton.UseVisualStyleBackColor = true;
            // 
            // customers_aliasTextBox
            // 
            this.customers_aliasTextBox.Location = new System.Drawing.Point(99, 150);
            this.customers_aliasTextBox.MaxLength = 50;
            this.customers_aliasTextBox.Name = "customers_aliasTextBox";
            this.customers_aliasTextBox.ReadOnly = true;
            this.customers_aliasTextBox.Size = new System.Drawing.Size(485, 20);
            this.customers_aliasTextBox.TabIndex = 24;
            // 
            // customers_idTextBox
            // 
            this.customers_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalsBindingSource, "customers_id", true));
            this.customers_idTextBox.Location = new System.Drawing.Point(14, 149);
            this.customers_idTextBox.MaxLength = 50;
            this.customers_idTextBox.Name = "customers_idTextBox";
            this.customers_idTextBox.ReadOnly = true;
            this.customers_idTextBox.Size = new System.Drawing.Size(79, 20);
            this.customers_idTextBox.TabIndex = 23;
            this.customers_idTextBox.TextChanged += new System.EventHandler(this.customers_idtextBox_TextChanged);
            // 
            // animalsBindingSource
            // 
            this.animalsBindingSource.DataMember = "animals";
            this.animalsBindingSource.DataSource = this.dataSet01S;
            // 
            // animals_idTextBox
            // 
            this.animals_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalsBindingSource, "animals_id", true));
            this.animals_idTextBox.Location = new System.Drawing.Point(13, 31);
            this.animals_idTextBox.Name = "animals_idTextBox";
            this.animals_idTextBox.ReadOnly = true;
            this.animals_idTextBox.Size = new System.Drawing.Size(80, 20);
            this.animals_idTextBox.TabIndex = 22;
            // 
            // animals_dateDateTimePicker
            // 
            this.animals_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.animalsBindingSource, "animals_date", true));
            this.animals_dateDateTimePicker.Enabled = false;
            this.animals_dateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.animals_dateDateTimePicker.Location = new System.Drawing.Point(458, 31);
            this.animals_dateDateTimePicker.Name = "animals_dateDateTimePicker";
            this.animals_dateDateTimePicker.Size = new System.Drawing.Size(126, 20);
            this.animals_dateDateTimePicker.TabIndex = 21;
            // 
            // button_Opendatadir
            // 
            this.button_Opendatadir.Location = new System.Drawing.Point(293, 28);
            this.button_Opendatadir.Name = "button_Opendatadir";
            this.button_Opendatadir.Size = new System.Drawing.Size(120, 23);
            this.button_Opendatadir.TabIndex = 20;
            this.button_Opendatadir.Text = "Data Dir";
            this.button_Opendatadir.UseVisualStyleBackColor = true;
            this.button_Opendatadir.Click += new System.EventHandler(this.button_Opendatadir_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.animals_sex_FradioButton);
            this.panel8.Controls.Add(this.animals_sex_MradioButton);
            this.panel8.Controls.Add(this.animals_sex_UradioButton);
            this.panel8.Location = new System.Drawing.Point(234, 109);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(165, 24);
            this.panel8.TabIndex = 19;
            // 
            // animals_sex_FradioButton
            // 
            this.animals_sex_FradioButton.AutoSize = true;
            this.animals_sex_FradioButton.Location = new System.Drawing.Point(116, 3);
            this.animals_sex_FradioButton.Name = "animals_sex_FradioButton";
            this.animals_sex_FradioButton.Size = new System.Drawing.Size(31, 17);
            this.animals_sex_FradioButton.TabIndex = 2;
            this.animals_sex_FradioButton.Text = "F";
            this.animals_sex_FradioButton.UseVisualStyleBackColor = true;
            // 
            // animals_sex_MradioButton
            // 
            this.animals_sex_MradioButton.AutoSize = true;
            this.animals_sex_MradioButton.Location = new System.Drawing.Point(76, 3);
            this.animals_sex_MradioButton.Name = "animals_sex_MradioButton";
            this.animals_sex_MradioButton.Size = new System.Drawing.Size(34, 17);
            this.animals_sex_MradioButton.TabIndex = 1;
            this.animals_sex_MradioButton.Text = "M";
            this.animals_sex_MradioButton.UseVisualStyleBackColor = true;
            // 
            // animals_sex_UradioButton
            // 
            this.animals_sex_UradioButton.AutoSize = true;
            this.animals_sex_UradioButton.Checked = true;
            this.animals_sex_UradioButton.Location = new System.Drawing.Point(3, 3);
            this.animals_sex_UradioButton.Name = "animals_sex_UradioButton";
            this.animals_sex_UradioButton.Size = new System.Drawing.Size(71, 17);
            this.animals_sex_UradioButton.TabIndex = 0;
            this.animals_sex_UradioButton.TabStop = true;
            this.animals_sex_UradioButton.Text = "Unknown";
            this.animals_sex_UradioButton.UseVisualStyleBackColor = true;
            // 
            // animals_notesTextBox
            // 
            this.animals_notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalsBindingSource, "animals_notes", true));
            this.animals_notesTextBox.Location = new System.Drawing.Point(14, 228);
            this.animals_notesTextBox.Multiline = true;
            this.animals_notesTextBox.Name = "animals_notesTextBox";
            this.animals_notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.animals_notesTextBox.Size = new System.Drawing.Size(570, 150);
            this.animals_notesTextBox.TabIndex = 15;
            // 
            // animals_birthunknowncheckBox
            // 
            this.animals_birthunknowncheckBox.AutoSize = true;
            this.animals_birthunknowncheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.animalsBindingSource, "animals_birthunknown", true));
            this.animals_birthunknowncheckBox.Location = new System.Drawing.Point(140, 192);
            this.animals_birthunknowncheckBox.Name = "animals_birthunknowncheckBox";
            this.animals_birthunknowncheckBox.Size = new System.Drawing.Size(72, 17);
            this.animals_birthunknowncheckBox.TabIndex = 18;
            this.animals_birthunknowncheckBox.Text = "presumed";
            this.animals_birthunknowncheckBox.UseVisualStyleBackColor = true;
            // 
            // checkBox_isdeath
            // 
            this.checkBox_isdeath.AutoSize = true;
            this.checkBox_isdeath.Location = new System.Drawing.Point(274, 173);
            this.checkBox_isdeath.Name = "checkBox_isdeath";
            this.checkBox_isdeath.Size = new System.Drawing.Size(15, 14);
            this.checkBox_isdeath.TabIndex = 17;
            this.checkBox_isdeath.UseVisualStyleBackColor = true;
            this.checkBox_isdeath.CheckedChanged += new System.EventHandler(this.checkBox_isdeath_CheckedChanged);
            // 
            // animals_deathDateTimePicker
            // 
            this.animals_deathDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.animalsBindingSource, "animals_death", true));
            this.animals_deathDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.animals_deathDateTimePicker.Location = new System.Drawing.Point(234, 189);
            this.animals_deathDateTimePicker.Name = "animals_deathDateTimePicker";
            this.animals_deathDateTimePicker.Size = new System.Drawing.Size(121, 20);
            this.animals_deathDateTimePicker.TabIndex = 11;
            // 
            // animals_birthDateTimePicker
            // 
            this.animals_birthDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.animalsBindingSource, "animals_birth", true));
            this.animals_birthDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.animals_birthDateTimePicker.Location = new System.Drawing.Point(13, 189);
            this.animals_birthDateTimePicker.Name = "animals_birthDateTimePicker";
            this.animals_birthDateTimePicker.Size = new System.Drawing.Size(121, 20);
            this.animals_birthDateTimePicker.TabIndex = 9;
            // 
            // breeds_idComboBox
            // 
            this.breeds_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.animalsBindingSource, "breeds_id", true));
            this.breeds_idComboBox.DataSource = this.comboviewDataTablebreedsBindingSource;
            this.breeds_idComboBox.DisplayMember = "breeds_alias";
            this.breeds_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.breeds_idComboBox.FormattingEnabled = true;
            this.breeds_idComboBox.Location = new System.Drawing.Point(14, 109);
            this.breeds_idComboBox.Name = "breeds_idComboBox";
            this.breeds_idComboBox.Size = new System.Drawing.Size(186, 21);
            this.breeds_idComboBox.TabIndex = 5;
            this.breeds_idComboBox.ValueMember = "breeds_id";
            // 
            // comboviewDataTablebreedsBindingSource
            // 
            this.comboviewDataTablebreedsBindingSource.DataMember = "comboviewDataTablebreeds";
            this.comboviewDataTablebreedsBindingSource.DataSource = this.dataSet01V;
            // 
            // animals_nameTextBox
            // 
            this.animals_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalsBindingSource, "animals_name", true));
            this.animals_nameTextBox.Location = new System.Drawing.Point(14, 70);
            this.animals_nameTextBox.MaxLength = 100;
            this.animals_nameTextBox.Name = "animals_nameTextBox";
            this.animals_nameTextBox.Size = new System.Drawing.Size(570, 20);
            this.animals_nameTextBox.TabIndex = 3;
            // 
            // animals_tagTextBox
            // 
            this.animals_tagTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalsBindingSource, "animals_tag", true));
            this.animals_tagTextBox.Location = new System.Drawing.Point(136, 31);
            this.animals_tagTextBox.MaxLength = 50;
            this.animals_tagTextBox.Name = "animals_tagTextBox";
            this.animals_tagTextBox.Size = new System.Drawing.Size(100, 20);
            this.animals_tagTextBox.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.panel14);
            this.tabPage2.Controls.Add(this.panel13);
            this.tabPage2.Controls.Add(this.panel12);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(592, 596);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Treatments";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.dataGridView_animalstreatmentsmain);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(3, 38);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(586, 127);
            this.panel14.TabIndex = 3;
            // 
            // dataGridView_animalstreatmentsmain
            // 
            this.dataGridView_animalstreatmentsmain.AllowUserToAddRows = false;
            this.dataGridView_animalstreatmentsmain.AllowUserToDeleteRows = false;
            this.dataGridView_animalstreatmentsmain.AllowUserToResizeColumns = false;
            this.dataGridView_animalstreatmentsmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_animalstreatmentsmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_animalstreatmentsmain.AutoGenerateColumns = false;
            this.dataGridView_animalstreatmentsmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_animalstreatmentsmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.animalstreatmentsidDataGridViewTextBoxColumn,
            this.animalstreatmentscodeDataGridViewTextBoxColumn,
            this.treatmentscategoriesnameDataGridViewTextBoxColumn1,
            this.paystatusnameDataGridViewTextBoxColumn,
            this.animalstreatmentsdateDataGridViewTextBoxColumn,
            this.animalstreatmentsdescDataGridViewTextBoxColumn});
            this.dataGridView_animalstreatmentsmain.DataSource = this.subviewDataTableanimalstreatmentsBindingSource;
            this.dataGridView_animalstreatmentsmain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_animalstreatmentsmain.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_animalstreatmentsmain.MultiSelect = false;
            this.dataGridView_animalstreatmentsmain.Name = "dataGridView_animalstreatmentsmain";
            this.dataGridView_animalstreatmentsmain.ReadOnly = true;
            this.dataGridView_animalstreatmentsmain.RowHeadersVisible = false;
            this.dataGridView_animalstreatmentsmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_animalstreatmentsmain.Size = new System.Drawing.Size(586, 127);
            this.dataGridView_animalstreatmentsmain.TabIndex = 1;
            // 
            // animalstreatmentsidDataGridViewTextBoxColumn
            // 
            this.animalstreatmentsidDataGridViewTextBoxColumn.DataPropertyName = "animalstreatments_id";
            this.animalstreatmentsidDataGridViewTextBoxColumn.HeaderText = "Id";
            this.animalstreatmentsidDataGridViewTextBoxColumn.Name = "animalstreatmentsidDataGridViewTextBoxColumn";
            this.animalstreatmentsidDataGridViewTextBoxColumn.ReadOnly = true;
            this.animalstreatmentsidDataGridViewTextBoxColumn.Width = 50;
            // 
            // animalstreatmentscodeDataGridViewTextBoxColumn
            // 
            this.animalstreatmentscodeDataGridViewTextBoxColumn.DataPropertyName = "animalstreatments_code";
            this.animalstreatmentscodeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.animalstreatmentscodeDataGridViewTextBoxColumn.Name = "animalstreatmentscodeDataGridViewTextBoxColumn";
            this.animalstreatmentscodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.animalstreatmentscodeDataGridViewTextBoxColumn.Width = 80;
            // 
            // treatmentscategoriesnameDataGridViewTextBoxColumn1
            // 
            this.treatmentscategoriesnameDataGridViewTextBoxColumn1.DataPropertyName = "treatmentscategories_name";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn1.HeaderText = "Category";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn1.Name = "treatmentscategoriesnameDataGridViewTextBoxColumn1";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.treatmentscategoriesnameDataGridViewTextBoxColumn1.Width = 120;
            // 
            // paystatusnameDataGridViewTextBoxColumn
            // 
            this.paystatusnameDataGridViewTextBoxColumn.DataPropertyName = "paystatus_name";
            this.paystatusnameDataGridViewTextBoxColumn.HeaderText = "Paystatus";
            this.paystatusnameDataGridViewTextBoxColumn.Name = "paystatusnameDataGridViewTextBoxColumn";
            this.paystatusnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.paystatusnameDataGridViewTextBoxColumn.Width = 60;
            // 
            // animalstreatmentsdateDataGridViewTextBoxColumn
            // 
            this.animalstreatmentsdateDataGridViewTextBoxColumn.DataPropertyName = "animalstreatments_date";
            this.animalstreatmentsdateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.animalstreatmentsdateDataGridViewTextBoxColumn.Name = "animalstreatmentsdateDataGridViewTextBoxColumn";
            this.animalstreatmentsdateDataGridViewTextBoxColumn.ReadOnly = true;
            this.animalstreatmentsdateDataGridViewTextBoxColumn.Width = 80;
            // 
            // animalstreatmentsdescDataGridViewTextBoxColumn
            // 
            this.animalstreatmentsdescDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.animalstreatmentsdescDataGridViewTextBoxColumn.DataPropertyName = "animalstreatments_desc";
            this.animalstreatmentsdescDataGridViewTextBoxColumn.HeaderText = "Desc";
            this.animalstreatmentsdescDataGridViewTextBoxColumn.Name = "animalstreatmentsdescDataGridViewTextBoxColumn";
            this.animalstreatmentsdescDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // subviewDataTableanimalstreatmentsBindingSource
            // 
            this.subviewDataTableanimalstreatmentsBindingSource.DataMember = "subviewDataTableanimalstreatments";
            this.subviewDataTableanimalstreatmentsBindingSource.DataSource = this.dataSet01V;
            this.subviewDataTableanimalstreatmentsBindingSource.CurrentChanged += new System.EventHandler(this.subviewDataTableanimalstreatmentsBindingSource_CurrentChanged);
            // 
            // panel13
            // 
            this.panel13.AutoScroll = true;
            this.panel13.Controls.Add(animalstreatments_idLabel);
            this.panel13.Controls.Add(this.animalstreatments_idTextBox);
            this.panel13.Controls.Add(this.textBox_animalstreatments_invoicesinfo);
            this.panel13.Controls.Add(this.animalstreatments_invoiceableCheckBox);
            this.panel13.Controls.Add(this.button_animalstreatmentsDelete);
            this.panel13.Controls.Add(animalstreatments_codeLabel);
            this.panel13.Controls.Add(this.button_animalstreatmentsEdit);
            this.panel13.Controls.Add(this.animalstreatments_codeTextBox);
            this.panel13.Controls.Add(this.button_animalstreatmentsNew);
            this.panel13.Controls.Add(this.animalstreatments_expirationadviceCheckBox);
            this.panel13.Controls.Add(this.groupBox_animalstreatments_fillfromtreatments);
            this.panel13.Controls.Add(treatmentscategories_idLabel);
            this.panel13.Controls.Add(this.animalstreatmentstreatmentscategories_idComboBox);
            this.panel13.Controls.Add(animalstreatments_descLabel);
            this.panel13.Controls.Add(this.animalstreatmentsusers_idComboBox);
            this.panel13.Controls.Add(this.animalstreatments_descTextBox);
            this.panel13.Controls.Add(users_idLabel1);
            this.panel13.Controls.Add(this.animalstreatmentspaystatus_idComboBox);
            this.panel13.Controls.Add(this.checkBox_animalstreatments_expirationdate);
            this.panel13.Controls.Add(paystatus_idLabel);
            this.panel13.Controls.Add(animalstreatments_priceLabel);
            this.panel13.Controls.Add(this.animalstreatments_dateDateTimePicker);
            this.panel13.Controls.Add(this.animalstreatments_priceTextBox);
            this.panel13.Controls.Add(animalstreatments_dateLabel);
            this.panel13.Controls.Add(animalstreatments_expirationLabel);
            this.panel13.Controls.Add(this.animalstreatments_notesTextBox);
            this.panel13.Controls.Add(this.animalstreatments_expirationDateTimePicker);
            this.panel13.Controls.Add(animalstreatments_notesLabel);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel13.Location = new System.Drawing.Point(3, 165);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(586, 428);
            this.panel13.TabIndex = 2;
            // 
            // animalstreatments_idTextBox
            // 
            this.animalstreatments_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalstreatmentsBindingSource, "animalstreatments_id", true));
            this.animalstreatments_idTextBox.Location = new System.Drawing.Point(13, 56);
            this.animalstreatments_idTextBox.Name = "animalstreatments_idTextBox";
            this.animalstreatments_idTextBox.ReadOnly = true;
            this.animalstreatments_idTextBox.Size = new System.Drawing.Size(80, 20);
            this.animalstreatments_idTextBox.TabIndex = 27;
            // 
            // animalstreatmentsBindingSource
            // 
            this.animalstreatmentsBindingSource.DataMember = "animalstreatments";
            this.animalstreatmentsBindingSource.DataSource = this.dataSet01S;
            // 
            // textBox_animalstreatments_invoicesinfo
            // 
            this.textBox_animalstreatments_invoicesinfo.Location = new System.Drawing.Point(331, 135);
            this.textBox_animalstreatments_invoicesinfo.Name = "textBox_animalstreatments_invoicesinfo";
            this.textBox_animalstreatments_invoicesinfo.ReadOnly = true;
            this.textBox_animalstreatments_invoicesinfo.Size = new System.Drawing.Size(241, 20);
            this.textBox_animalstreatments_invoicesinfo.TabIndex = 26;
            // 
            // animalstreatments_invoiceableCheckBox
            // 
            this.animalstreatments_invoiceableCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.animalstreatmentsBindingSource, "animalstreatments_invoiceable", true));
            this.animalstreatments_invoiceableCheckBox.Location = new System.Drawing.Point(240, 133);
            this.animalstreatments_invoiceableCheckBox.Name = "animalstreatments_invoiceableCheckBox";
            this.animalstreatments_invoiceableCheckBox.Size = new System.Drawing.Size(85, 24);
            this.animalstreatments_invoiceableCheckBox.TabIndex = 24;
            this.animalstreatments_invoiceableCheckBox.Text = "invoice able";
            this.animalstreatments_invoiceableCheckBox.UseVisualStyleBackColor = true;
            // 
            // button_animalstreatmentsDelete
            // 
            this.button_animalstreatmentsDelete.Location = new System.Drawing.Point(165, 6);
            this.button_animalstreatmentsDelete.Name = "button_animalstreatmentsDelete";
            this.button_animalstreatmentsDelete.Size = new System.Drawing.Size(75, 23);
            this.button_animalstreatmentsDelete.TabIndex = 8;
            this.button_animalstreatmentsDelete.Text = "Delete";
            this.button_animalstreatmentsDelete.UseVisualStyleBackColor = true;
            this.button_animalstreatmentsDelete.Click += new System.EventHandler(this.button_animalstreatmentsDelete_Click);
            // 
            // button_animalstreatmentsEdit
            // 
            this.button_animalstreatmentsEdit.Location = new System.Drawing.Point(84, 6);
            this.button_animalstreatmentsEdit.Name = "button_animalstreatmentsEdit";
            this.button_animalstreatmentsEdit.Size = new System.Drawing.Size(75, 23);
            this.button_animalstreatmentsEdit.TabIndex = 7;
            this.button_animalstreatmentsEdit.Text = "Edit";
            this.button_animalstreatmentsEdit.UseVisualStyleBackColor = true;
            this.button_animalstreatmentsEdit.Click += new System.EventHandler(this.button_animalstreatmentsEdit_Click);
            // 
            // animalstreatments_codeTextBox
            // 
            this.animalstreatments_codeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalstreatmentsBindingSource, "animalstreatments_code", true));
            this.animalstreatments_codeTextBox.Location = new System.Drawing.Point(13, 135);
            this.animalstreatments_codeTextBox.MaxLength = 15;
            this.animalstreatments_codeTextBox.Name = "animalstreatments_codeTextBox";
            this.animalstreatments_codeTextBox.Size = new System.Drawing.Size(100, 20);
            this.animalstreatments_codeTextBox.TabIndex = 23;
            // 
            // button_animalstreatmentsNew
            // 
            this.button_animalstreatmentsNew.Location = new System.Drawing.Point(3, 6);
            this.button_animalstreatmentsNew.Name = "button_animalstreatmentsNew";
            this.button_animalstreatmentsNew.Size = new System.Drawing.Size(75, 23);
            this.button_animalstreatmentsNew.TabIndex = 6;
            this.button_animalstreatmentsNew.Text = "New";
            this.button_animalstreatmentsNew.UseVisualStyleBackColor = true;
            this.button_animalstreatmentsNew.Click += new System.EventHandler(this.button_animalstreatmentsNew_Click);
            // 
            // animalstreatments_expirationadviceCheckBox
            // 
            this.animalstreatments_expirationadviceCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.animalstreatmentsBindingSource, "animalstreatments_expirationadvice", true));
            this.animalstreatments_expirationadviceCheckBox.Location = new System.Drawing.Point(419, 94);
            this.animalstreatments_expirationadviceCheckBox.Name = "animalstreatments_expirationadviceCheckBox";
            this.animalstreatments_expirationadviceCheckBox.Size = new System.Drawing.Size(63, 24);
            this.animalstreatments_expirationadviceCheckBox.TabIndex = 22;
            this.animalstreatments_expirationadviceCheckBox.Text = "advice";
            this.animalstreatments_expirationadviceCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox_animalstreatments_fillfromtreatments
            // 
            this.groupBox_animalstreatments_fillfromtreatments.Controls.Add(this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id);
            this.groupBox_animalstreatments_fillfromtreatments.Controls.Add(this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name);
            this.groupBox_animalstreatments_fillfromtreatments.Controls.Add(this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code);
            this.groupBox_animalstreatments_fillfromtreatments.Controls.Add(this.dataGridView_animalstreatmentsfillfromtreatmentsmain);
            this.groupBox_animalstreatments_fillfromtreatments.Controls.Add(this.button_animalstreatmentsfillfromtreatments);
            this.groupBox_animalstreatments_fillfromtreatments.Location = new System.Drawing.Point(13, 305);
            this.groupBox_animalstreatments_fillfromtreatments.Name = "groupBox_animalstreatments_fillfromtreatments";
            this.groupBox_animalstreatments_fillfromtreatments.Size = new System.Drawing.Size(559, 115);
            this.groupBox_animalstreatments_fillfromtreatments.TabIndex = 17;
            this.groupBox_animalstreatments_fillfromtreatments.TabStop = false;
            this.groupBox_animalstreatments_fillfromtreatments.Text = "fill from treatments";
            // 
            // comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id
            // 
            this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.FormattingEnabled = true;
            this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.Location = new System.Drawing.Point(69, 18);
            this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.Name = "comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id";
            this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.Size = new System.Drawing.Size(74, 21);
            this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.TabIndex = 6;
            this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id_SelectedIndexChanged);
            // 
            // textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name
            // 
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name.Location = new System.Drawing.Point(149, 19);
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name.Name = "textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name";
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name.Size = new System.Drawing.Size(113, 20);
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name.TabIndex = 5;
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name.TextChanged += new System.EventHandler(this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name_TextChanged);
            // 
            // textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code
            // 
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code.Location = new System.Drawing.Point(7, 19);
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code.Name = "textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code";
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code.Size = new System.Drawing.Size(58, 20);
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code.TabIndex = 3;
            this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code.TextChanged += new System.EventHandler(this.textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code_TextChanged);
            // 
            // dataGridView_animalstreatmentsfillfromtreatmentsmain
            // 
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.AllowUserToAddRows = false;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.AllowUserToDeleteRows = false;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.AllowUserToResizeColumns = false;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.AutoGenerateColumns = false;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.treatmentscodeDataGridViewTextBoxColumn,
            this.treatmentscategoriesnameDataGridViewTextBoxColumn,
            this.treatmentsnameDataGridViewTextBoxColumn,
            this.treatmentsdescDataGridViewTextBoxColumn});
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.DataSource = this.comboviewDataTabletreatmentsBindingSource;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.Location = new System.Drawing.Point(6, 40);
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.MultiSelect = false;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.Name = "dataGridView_animalstreatmentsfillfromtreatmentsmain";
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.ReadOnly = true;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.RowHeadersVisible = false;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.Size = new System.Drawing.Size(466, 68);
            this.dataGridView_animalstreatmentsfillfromtreatmentsmain.TabIndex = 2;
            // 
            // treatmentscodeDataGridViewTextBoxColumn
            // 
            this.treatmentscodeDataGridViewTextBoxColumn.DataPropertyName = "treatments_code";
            this.treatmentscodeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.treatmentscodeDataGridViewTextBoxColumn.Name = "treatmentscodeDataGridViewTextBoxColumn";
            this.treatmentscodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentscodeDataGridViewTextBoxColumn.Width = 60;
            // 
            // treatmentscategoriesnameDataGridViewTextBoxColumn
            // 
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.DataPropertyName = "treatmentscategories_name";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.HeaderText = "Category";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.Name = "treatmentscategoriesnameDataGridViewTextBoxColumn";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // treatmentsnameDataGridViewTextBoxColumn
            // 
            this.treatmentsnameDataGridViewTextBoxColumn.DataPropertyName = "treatments_name";
            this.treatmentsnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.treatmentsnameDataGridViewTextBoxColumn.Name = "treatmentsnameDataGridViewTextBoxColumn";
            this.treatmentsnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentsnameDataGridViewTextBoxColumn.Width = 120;
            // 
            // treatmentsdescDataGridViewTextBoxColumn
            // 
            this.treatmentsdescDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.treatmentsdescDataGridViewTextBoxColumn.DataPropertyName = "treatments_desc";
            this.treatmentsdescDataGridViewTextBoxColumn.HeaderText = "Desc";
            this.treatmentsdescDataGridViewTextBoxColumn.Name = "treatmentsdescDataGridViewTextBoxColumn";
            this.treatmentsdescDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // comboviewDataTabletreatmentsBindingSource
            // 
            this.comboviewDataTabletreatmentsBindingSource.DataMember = "comboviewDataTabletreatments";
            this.comboviewDataTabletreatmentsBindingSource.DataSource = this.dataSet01V;
            // 
            // button_animalstreatmentsfillfromtreatments
            // 
            this.button_animalstreatmentsfillfromtreatments.Location = new System.Drawing.Point(478, 85);
            this.button_animalstreatmentsfillfromtreatments.Name = "button_animalstreatmentsfillfromtreatments";
            this.button_animalstreatmentsfillfromtreatments.Size = new System.Drawing.Size(75, 23);
            this.button_animalstreatmentsfillfromtreatments.TabIndex = 1;
            this.button_animalstreatmentsfillfromtreatments.Text = "Fill";
            this.button_animalstreatmentsfillfromtreatments.UseVisualStyleBackColor = true;
            this.button_animalstreatmentsfillfromtreatments.Click += new System.EventHandler(this.button_animalstreatmentsfillfromtreatments_Click);
            // 
            // animalstreatmentstreatmentscategories_idComboBox
            // 
            this.animalstreatmentstreatmentscategories_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.animalstreatmentsBindingSource, "treatmentscategories_id", true));
            this.animalstreatmentstreatmentscategories_idComboBox.DataSource = this.comboviewDataTabletreatmentscategoriesBindingSource;
            this.animalstreatmentstreatmentscategories_idComboBox.DisplayMember = "treatmentscategories_name";
            this.animalstreatmentstreatmentscategories_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.animalstreatmentstreatmentscategories_idComboBox.FormattingEnabled = true;
            this.animalstreatmentstreatmentscategories_idComboBox.Location = new System.Drawing.Point(136, 96);
            this.animalstreatmentstreatmentscategories_idComboBox.Name = "animalstreatmentstreatmentscategories_idComboBox";
            this.animalstreatmentstreatmentscategories_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.animalstreatmentstreatmentscategories_idComboBox.TabIndex = 21;
            this.animalstreatmentstreatmentscategories_idComboBox.ValueMember = "treatmentscategories_id";
            // 
            // comboviewDataTabletreatmentscategoriesBindingSource
            // 
            this.comboviewDataTabletreatmentscategoriesBindingSource.DataMember = "comboviewDataTabletreatmentscategories";
            this.comboviewDataTabletreatmentscategoriesBindingSource.DataSource = this.dataSet01V;
            // 
            // animalstreatmentsusers_idComboBox
            // 
            this.animalstreatmentsusers_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.animalstreatmentsBindingSource, "users_id", true));
            this.animalstreatmentsusers_idComboBox.DataSource = this.comboviewDataTableusersBindingSource;
            this.animalstreatmentsusers_idComboBox.DisplayMember = "users_alias";
            this.animalstreatmentsusers_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.animalstreatmentsusers_idComboBox.FormattingEnabled = true;
            this.animalstreatmentsusers_idComboBox.Location = new System.Drawing.Point(136, 56);
            this.animalstreatmentsusers_idComboBox.Name = "animalstreatmentsusers_idComboBox";
            this.animalstreatmentsusers_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.animalstreatmentsusers_idComboBox.TabIndex = 9;
            this.animalstreatmentsusers_idComboBox.ValueMember = "users_id";
            // 
            // comboviewDataTableusersBindingSource
            // 
            this.comboviewDataTableusersBindingSource.DataMember = "comboviewDataTableusers";
            this.comboviewDataTableusersBindingSource.DataSource = this.dataSet01V;
            // 
            // animalstreatments_descTextBox
            // 
            this.animalstreatments_descTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalstreatmentsBindingSource, "animalstreatments_desc", true));
            this.animalstreatments_descTextBox.Location = new System.Drawing.Point(14, 174);
            this.animalstreatments_descTextBox.Multiline = true;
            this.animalstreatments_descTextBox.Name = "animalstreatments_descTextBox";
            this.animalstreatments_descTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.animalstreatments_descTextBox.Size = new System.Drawing.Size(311, 125);
            this.animalstreatments_descTextBox.TabIndex = 20;
            // 
            // animalstreatmentspaystatus_idComboBox
            // 
            this.animalstreatmentspaystatus_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.animalstreatmentsBindingSource, "paystatus_id", true));
            this.animalstreatmentspaystatus_idComboBox.DataSource = this.comboviewDataTablepaystatusBindingSource;
            this.animalstreatmentspaystatus_idComboBox.DisplayMember = "paystatus_name";
            this.animalstreatmentspaystatus_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.animalstreatmentspaystatus_idComboBox.FormattingEnabled = true;
            this.animalstreatmentspaystatus_idComboBox.Location = new System.Drawing.Point(136, 136);
            this.animalstreatmentspaystatus_idComboBox.Name = "animalstreatmentspaystatus_idComboBox";
            this.animalstreatmentspaystatus_idComboBox.Size = new System.Drawing.Size(80, 21);
            this.animalstreatmentspaystatus_idComboBox.TabIndex = 10;
            this.animalstreatmentspaystatus_idComboBox.ValueMember = "paystatus_id";
            this.animalstreatmentspaystatus_idComboBox.SelectedIndexChanged += new System.EventHandler(this.animalstreatmentspaystatus_idComboBox_SelectedIndexChanged);
            // 
            // comboviewDataTablepaystatusBindingSource
            // 
            this.comboviewDataTablepaystatusBindingSource.DataMember = "comboviewDataTablepaystatus";
            this.comboviewDataTablepaystatusBindingSource.DataSource = this.dataSet01V;
            // 
            // checkBox_animalstreatments_expirationdate
            // 
            this.checkBox_animalstreatments_expirationdate.AutoSize = true;
            this.checkBox_animalstreatments_expirationdate.Location = new System.Drawing.Point(354, 80);
            this.checkBox_animalstreatments_expirationdate.Name = "checkBox_animalstreatments_expirationdate";
            this.checkBox_animalstreatments_expirationdate.Size = new System.Drawing.Size(15, 14);
            this.checkBox_animalstreatments_expirationdate.TabIndex = 16;
            this.checkBox_animalstreatments_expirationdate.UseVisualStyleBackColor = true;
            this.checkBox_animalstreatments_expirationdate.CheckedChanged += new System.EventHandler(this.checkBox_animalstreatments_expirationdate_CheckedChanged);
            // 
            // animalstreatments_dateDateTimePicker
            // 
            this.animalstreatments_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.animalstreatmentsBindingSource, "animalstreatments_date", true));
            this.animalstreatments_dateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.animalstreatments_dateDateTimePicker.Location = new System.Drawing.Point(313, 57);
            this.animalstreatments_dateDateTimePicker.Name = "animalstreatments_dateDateTimePicker";
            this.animalstreatments_dateDateTimePicker.Size = new System.Drawing.Size(100, 20);
            this.animalstreatments_dateDateTimePicker.TabIndex = 12;
            // 
            // animalstreatments_priceTextBox
            // 
            this.animalstreatments_priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalstreatmentsBindingSource, "animalstreatments_price", true));
            this.animalstreatments_priceTextBox.Location = new System.Drawing.Point(13, 96);
            this.animalstreatments_priceTextBox.MaxLength = 11;
            this.animalstreatments_priceTextBox.Name = "animalstreatments_priceTextBox";
            this.animalstreatments_priceTextBox.Size = new System.Drawing.Size(70, 20);
            this.animalstreatments_priceTextBox.TabIndex = 15;
            this.animalstreatments_priceTextBox.Leave += new System.EventHandler(this.animalstreatments_priceTextBox_Leave);
            // 
            // animalstreatments_notesTextBox
            // 
            this.animalstreatments_notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalstreatmentsBindingSource, "animalstreatments_notes", true));
            this.animalstreatments_notesTextBox.Location = new System.Drawing.Point(331, 174);
            this.animalstreatments_notesTextBox.Multiline = true;
            this.animalstreatments_notesTextBox.Name = "animalstreatments_notesTextBox";
            this.animalstreatments_notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.animalstreatments_notesTextBox.Size = new System.Drawing.Size(241, 125);
            this.animalstreatments_notesTextBox.TabIndex = 13;
            // 
            // animalstreatments_expirationDateTimePicker
            // 
            this.animalstreatments_expirationDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.animalstreatmentsBindingSource, "animalstreatments_expiration", true));
            this.animalstreatments_expirationDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.animalstreatments_expirationDateTimePicker.Location = new System.Drawing.Point(313, 97);
            this.animalstreatments_expirationDateTimePicker.Name = "animalstreatments_expirationDateTimePicker";
            this.animalstreatments_expirationDateTimePicker.Size = new System.Drawing.Size(100, 20);
            this.animalstreatments_expirationDateTimePicker.TabIndex = 14;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.panel_animalstreatmentsfilter);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(3, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(586, 35);
            this.panel12.TabIndex = 1;
            // 
            // panel_animalstreatmentsfilter
            // 
            this.panel_animalstreatmentsfilter.Controls.Add(this.textBox_animalstreatmentsfilter_animalstreatments_date);
            this.panel_animalstreatmentsfilter.Controls.Add(this.comboBox_animalstreatmentsfilter_treamtentscategories_id);
            this.panel_animalstreatmentsfilter.Controls.Add(this.textBox_animalstreatmentsfilter_animalstreatments_code);
            this.panel_animalstreatmentsfilter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_animalstreatmentsfilter.Location = new System.Drawing.Point(0, 0);
            this.panel_animalstreatmentsfilter.Name = "panel_animalstreatmentsfilter";
            this.panel_animalstreatmentsfilter.Size = new System.Drawing.Size(586, 35);
            this.panel_animalstreatmentsfilter.TabIndex = 1;
            // 
            // textBox_animalstreatmentsfilter_animalstreatments_date
            // 
            this.textBox_animalstreatmentsfilter_animalstreatments_date.Location = new System.Drawing.Point(313, 11);
            this.textBox_animalstreatmentsfilter_animalstreatments_date.Name = "textBox_animalstreatmentsfilter_animalstreatments_date";
            this.textBox_animalstreatmentsfilter_animalstreatments_date.Size = new System.Drawing.Size(71, 20);
            this.textBox_animalstreatmentsfilter_animalstreatments_date.TabIndex = 5;
            this.textBox_animalstreatmentsfilter_animalstreatments_date.TextChanged += new System.EventHandler(this.textBox_animalstreatmentsfilter_animalstreatments_date_TextChanged);
            // 
            // comboBox_animalstreatmentsfilter_treamtentscategories_id
            // 
            this.comboBox_animalstreatmentsfilter_treamtentscategories_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_animalstreatmentsfilter_treamtentscategories_id.FormattingEnabled = true;
            this.comboBox_animalstreatmentsfilter_treamtentscategories_id.Location = new System.Drawing.Point(131, 11);
            this.comboBox_animalstreatmentsfilter_treamtentscategories_id.Name = "comboBox_animalstreatmentsfilter_treamtentscategories_id";
            this.comboBox_animalstreatmentsfilter_treamtentscategories_id.Size = new System.Drawing.Size(123, 21);
            this.comboBox_animalstreatmentsfilter_treamtentscategories_id.TabIndex = 2;
            this.comboBox_animalstreatmentsfilter_treamtentscategories_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_animalstreatmentsfilter_treamtentscategories_id_SelectedIndexChanged);
            // 
            // textBox_animalstreatmentsfilter_animalstreatments_code
            // 
            this.textBox_animalstreatmentsfilter_animalstreatments_code.Location = new System.Drawing.Point(53, 11);
            this.textBox_animalstreatmentsfilter_animalstreatments_code.Name = "textBox_animalstreatmentsfilter_animalstreatments_code";
            this.textBox_animalstreatmentsfilter_animalstreatments_code.Size = new System.Drawing.Size(71, 20);
            this.textBox_animalstreatmentsfilter_animalstreatments_code.TabIndex = 4;
            this.textBox_animalstreatmentsfilter_animalstreatments_code.TextChanged += new System.EventHandler(this.textBox_animalstreatmentsfilter_animalstreatments_code_TextChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.panel11);
            this.tabPage3.Controls.Add(this.panel10);
            this.tabPage3.Controls.Add(this.panel9);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(592, 596);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Notes";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.dataGridView_animalsnotesmain);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(3, 38);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(586, 353);
            this.panel11.TabIndex = 2;
            // 
            // dataGridView_animalsnotesmain
            // 
            this.dataGridView_animalsnotesmain.AllowUserToAddRows = false;
            this.dataGridView_animalsnotesmain.AllowUserToDeleteRows = false;
            this.dataGridView_animalsnotesmain.AllowUserToResizeColumns = false;
            this.dataGridView_animalsnotesmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_animalsnotesmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView_animalsnotesmain.AutoGenerateColumns = false;
            this.dataGridView_animalsnotesmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_animalsnotesmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.animalsnotestypesnameDataGridViewTextBoxColumn,
            this.animalsnotesdateDataGridViewTextBoxColumn,
            this.animalsnotesnotesDataGridViewTextBoxColumn});
            this.dataGridView_animalsnotesmain.DataSource = this.subviewDataTableanimalsnotesBindingSource;
            this.dataGridView_animalsnotesmain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_animalsnotesmain.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_animalsnotesmain.MultiSelect = false;
            this.dataGridView_animalsnotesmain.Name = "dataGridView_animalsnotesmain";
            this.dataGridView_animalsnotesmain.ReadOnly = true;
            this.dataGridView_animalsnotesmain.RowHeadersVisible = false;
            this.dataGridView_animalsnotesmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_animalsnotesmain.Size = new System.Drawing.Size(586, 353);
            this.dataGridView_animalsnotesmain.TabIndex = 1;
            // 
            // animalsnotestypesnameDataGridViewTextBoxColumn
            // 
            this.animalsnotestypesnameDataGridViewTextBoxColumn.DataPropertyName = "animalsnotestypes_name";
            this.animalsnotestypesnameDataGridViewTextBoxColumn.HeaderText = "Type";
            this.animalsnotestypesnameDataGridViewTextBoxColumn.Name = "animalsnotestypesnameDataGridViewTextBoxColumn";
            this.animalsnotestypesnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.animalsnotestypesnameDataGridViewTextBoxColumn.Width = 120;
            // 
            // animalsnotesdateDataGridViewTextBoxColumn
            // 
            this.animalsnotesdateDataGridViewTextBoxColumn.DataPropertyName = "animalsnotes_date";
            this.animalsnotesdateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.animalsnotesdateDataGridViewTextBoxColumn.Name = "animalsnotesdateDataGridViewTextBoxColumn";
            this.animalsnotesdateDataGridViewTextBoxColumn.ReadOnly = true;
            this.animalsnotesdateDataGridViewTextBoxColumn.Width = 80;
            // 
            // animalsnotesnotesDataGridViewTextBoxColumn
            // 
            this.animalsnotesnotesDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.animalsnotesnotesDataGridViewTextBoxColumn.DataPropertyName = "animalsnotes_notes";
            this.animalsnotesnotesDataGridViewTextBoxColumn.HeaderText = "Note";
            this.animalsnotesnotesDataGridViewTextBoxColumn.Name = "animalsnotesnotesDataGridViewTextBoxColumn";
            this.animalsnotesnotesDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // subviewDataTableanimalsnotesBindingSource
            // 
            this.subviewDataTableanimalsnotesBindingSource.DataMember = "subviewDataTableanimalsnotes";
            this.subviewDataTableanimalsnotesBindingSource.DataSource = this.dataSet01V;
            this.subviewDataTableanimalsnotesBindingSource.CurrentChanged += new System.EventHandler(this.subviewDataTableanimalsnotesBindingSource_CurrentChanged);
            // 
            // panel10
            // 
            this.panel10.AutoScroll = true;
            this.panel10.Controls.Add(users_idLabel);
            this.panel10.Controls.Add(this.animalsnotesusers_idComboBox);
            this.panel10.Controls.Add(this.button_animalsnotesDelete);
            this.panel10.Controls.Add(this.button_animalsnotesEdit);
            this.panel10.Controls.Add(animalsnotestypes_idLabel);
            this.panel10.Controls.Add(this.button_animalsnotesNew);
            this.panel10.Controls.Add(this.animalsnotestypes_idComboBox);
            this.panel10.Controls.Add(animalsnotes_notesLabel);
            this.panel10.Controls.Add(animalsnotes_dateLabel);
            this.panel10.Controls.Add(this.animalsnotes_notesTextBox);
            this.panel10.Controls.Add(this.animalsnotes_dateDateTimePicker);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(3, 391);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(586, 202);
            this.panel10.TabIndex = 1;
            // 
            // animalsnotesusers_idComboBox
            // 
            this.animalsnotesusers_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.animalsnotesBindingSource, "users_id", true));
            this.animalsnotesusers_idComboBox.DataSource = this.comboviewDataTableusersBindingSource;
            this.animalsnotesusers_idComboBox.DisplayMember = "users_alias";
            this.animalsnotesusers_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.animalsnotesusers_idComboBox.FormattingEnabled = true;
            this.animalsnotesusers_idComboBox.Location = new System.Drawing.Point(13, 56);
            this.animalsnotesusers_idComboBox.Name = "animalsnotesusers_idComboBox";
            this.animalsnotesusers_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.animalsnotesusers_idComboBox.TabIndex = 9;
            this.animalsnotesusers_idComboBox.ValueMember = "users_id";
            // 
            // animalsnotesBindingSource
            // 
            this.animalsnotesBindingSource.DataMember = "animalsnotes";
            this.animalsnotesBindingSource.DataSource = this.dataSet01S;
            // 
            // button_animalsnotesDelete
            // 
            this.button_animalsnotesDelete.Location = new System.Drawing.Point(165, 6);
            this.button_animalsnotesDelete.Name = "button_animalsnotesDelete";
            this.button_animalsnotesDelete.Size = new System.Drawing.Size(75, 23);
            this.button_animalsnotesDelete.TabIndex = 8;
            this.button_animalsnotesDelete.Text = "Delete";
            this.button_animalsnotesDelete.UseVisualStyleBackColor = true;
            this.button_animalsnotesDelete.Click += new System.EventHandler(this.button_animalsnotesDelete_Click);
            // 
            // button_animalsnotesEdit
            // 
            this.button_animalsnotesEdit.Location = new System.Drawing.Point(84, 6);
            this.button_animalsnotesEdit.Name = "button_animalsnotesEdit";
            this.button_animalsnotesEdit.Size = new System.Drawing.Size(75, 23);
            this.button_animalsnotesEdit.TabIndex = 7;
            this.button_animalsnotesEdit.Text = "Edit";
            this.button_animalsnotesEdit.UseVisualStyleBackColor = true;
            this.button_animalsnotesEdit.Click += new System.EventHandler(this.button_animalsnotesEdit_Click);
            // 
            // button_animalsnotesNew
            // 
            this.button_animalsnotesNew.Location = new System.Drawing.Point(3, 6);
            this.button_animalsnotesNew.Name = "button_animalsnotesNew";
            this.button_animalsnotesNew.Size = new System.Drawing.Size(75, 23);
            this.button_animalsnotesNew.TabIndex = 6;
            this.button_animalsnotesNew.Text = "New";
            this.button_animalsnotesNew.UseVisualStyleBackColor = true;
            this.button_animalsnotesNew.Click += new System.EventHandler(this.button_animalsnotesNew_Click);
            // 
            // animalsnotestypes_idComboBox
            // 
            this.animalsnotestypes_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.animalsnotesBindingSource, "animalsnotestypes_id", true));
            this.animalsnotestypes_idComboBox.DataSource = this.comboviewDataTableanimalsnotestypesBindingSource;
            this.animalsnotestypes_idComboBox.DisplayMember = "animalsnotestypes_name";
            this.animalsnotestypes_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.animalsnotestypes_idComboBox.FormattingEnabled = true;
            this.animalsnotestypes_idComboBox.Location = new System.Drawing.Point(165, 56);
            this.animalsnotestypes_idComboBox.Name = "animalsnotestypes_idComboBox";
            this.animalsnotestypes_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.animalsnotestypes_idComboBox.TabIndex = 1;
            this.animalsnotestypes_idComboBox.ValueMember = "animalsnotestypes_id";
            // 
            // comboviewDataTableanimalsnotestypesBindingSource
            // 
            this.comboviewDataTableanimalsnotestypesBindingSource.DataMember = "comboviewDataTableanimalsnotestypes";
            this.comboviewDataTableanimalsnotestypesBindingSource.DataSource = this.dataSet01V;
            // 
            // animalsnotes_notesTextBox
            // 
            this.animalsnotes_notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.animalsnotesBindingSource, "animalsnotes_notes", true));
            this.animalsnotes_notesTextBox.Location = new System.Drawing.Point(13, 96);
            this.animalsnotes_notesTextBox.Multiline = true;
            this.animalsnotes_notesTextBox.Name = "animalsnotes_notesTextBox";
            this.animalsnotes_notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.animalsnotes_notesTextBox.Size = new System.Drawing.Size(568, 100);
            this.animalsnotes_notesTextBox.TabIndex = 5;
            // 
            // animalsnotes_dateDateTimePicker
            // 
            this.animalsnotes_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.animalsnotesBindingSource, "animalsnotes_date", true));
            this.animalsnotes_dateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.animalsnotes_dateDateTimePicker.Location = new System.Drawing.Point(325, 56);
            this.animalsnotes_dateDateTimePicker.Name = "animalsnotes_dateDateTimePicker";
            this.animalsnotes_dateDateTimePicker.Size = new System.Drawing.Size(100, 20);
            this.animalsnotes_dateDateTimePicker.TabIndex = 3;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel_animalsnotesfilter);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(3, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(586, 35);
            this.panel9.TabIndex = 0;
            // 
            // panel_animalsnotesfilter
            // 
            this.panel_animalsnotesfilter.Controls.Add(this.comboBox_animalsnotesfilter_animalsnotestypes_id);
            this.panel_animalsnotesfilter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_animalsnotesfilter.Location = new System.Drawing.Point(0, 0);
            this.panel_animalsnotesfilter.Name = "panel_animalsnotesfilter";
            this.panel_animalsnotesfilter.Size = new System.Drawing.Size(586, 35);
            this.panel_animalsnotesfilter.TabIndex = 1;
            // 
            // comboBox_animalsnotesfilter_animalsnotestypes_id
            // 
            this.comboBox_animalsnotesfilter_animalsnotestypes_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_animalsnotesfilter_animalsnotestypes_id.FormattingEnabled = true;
            this.comboBox_animalsnotesfilter_animalsnotestypes_id.Location = new System.Drawing.Point(3, 11);
            this.comboBox_animalsnotesfilter_animalsnotestypes_id.Name = "comboBox_animalsnotesfilter_animalsnotestypes_id";
            this.comboBox_animalsnotesfilter_animalsnotestypes_id.Size = new System.Drawing.Size(121, 21);
            this.comboBox_animalsnotesfilter_animalsnotestypes_id.TabIndex = 1;
            this.comboBox_animalsnotesfilter_animalsnotestypes_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_animalsnotesfilter_animalsnotestypes_id_SelectedIndexChanged);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Stopedit);
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 622);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(600, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Stopedit
            // 
            this.button_Stopedit.Location = new System.Drawing.Point(168, 5);
            this.button_Stopedit.Name = "button_Stopedit";
            this.button_Stopedit.Size = new System.Drawing.Size(75, 23);
            this.button_Stopedit.TabIndex = 2;
            this.button_Stopedit.Text = "End Edit";
            this.button_Stopedit.UseVisualStyleBackColor = true;
            this.button_Stopedit.Click += new System.EventHandler(this.button_Stopedit_Click);
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // comboviewDataTablecustomersBindingSource
            // 
            this.comboviewDataTablecustomersBindingSource.DataMember = "comboviewDataTablecustomers";
            this.comboviewDataTablecustomersBindingSource.DataSource = this.dataSet01V;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 662);
            this.panel1.TabIndex = 4;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel_filter);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(384, 60);
            this.panel7.TabIndex = 3;
            // 
            // panel_filter
            // 
            this.panel_filter.Controls.Add(this.label3);
            this.panel_filter.Controls.Add(this.textBox_filter_animals);
            this.panel_filter.Controls.Add(this.label1);
            this.panel_filter.Controls.Add(this.comboBox_filter_customers_id);
            this.panel_filter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filter.Location = new System.Drawing.Point(0, 0);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new System.Drawing.Size(384, 60);
            this.panel_filter.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(208, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "name / tag / id";
            // 
            // textBox_filter_animals
            // 
            this.textBox_filter_animals.Location = new System.Drawing.Point(211, 37);
            this.textBox_filter_animals.Name = "textBox_filter_animals";
            this.textBox_filter_animals.Size = new System.Drawing.Size(100, 20);
            this.textBox_filter_animals.TabIndex = 3;
            this.textBox_filter_animals.TextChanged += new System.EventHandler(this.textBox_filter_animals_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "customer";
            // 
            // comboBox_filter_customers_id
            // 
            this.comboBox_filter_customers_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox_filter_customers_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_filter_customers_id.FormattingEnabled = true;
            this.comboBox_filter_customers_id.Location = new System.Drawing.Point(66, 12);
            this.comboBox_filter_customers_id.Name = "comboBox_filter_customers_id";
            this.comboBox_filter_customers_id.Size = new System.Drawing.Size(121, 21);
            this.comboBox_filter_customers_id.TabIndex = 1;
            this.comboBox_filter_customers_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_customers_id_SelectedIndexChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Print);
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 597);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 65);
            this.panel4.TabIndex = 1;
            // 
            // button_Print
            // 
            this.button_Print.Location = new System.Drawing.Point(13, 35);
            this.button_Print.Name = "button_Print";
            this.button_Print.Size = new System.Drawing.Size(75, 23);
            this.button_Print.TabIndex = 3;
            this.button_Print.Text = "Print";
            this.button_Print.UseVisualStyleBackColor = true;
            this.button_Print.Click += new System.EventHandler(this.button_Print_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // viewDataTableanimalsTableAdapter
            // 
            this.viewDataTableanimalsTableAdapter.ClearBeforeFill = true;
            // 
            // animalsTableAdapter
            // 
            this.animalsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablebreedsTableAdapter
            // 
            this.comboviewDataTablebreedsTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableanimalsnotesTableAdapter
            // 
            this.subviewDataTableanimalsnotesTableAdapter.ClearBeforeFill = true;
            // 
            // animalsnotesTableAdapter
            // 
            this.animalsnotesTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablecustomersTableAdapter
            // 
            this.comboviewDataTablecustomersTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTableanimalsnotestypesTableAdapter
            // 
            this.comboviewDataTableanimalsnotestypesTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTableusersTableAdapter
            // 
            this.comboviewDataTableusersTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableanimalstreatmentsTableAdapter
            // 
            this.subviewDataTableanimalstreatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // animalstreatmentsTableAdapter
            // 
            this.animalstreatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletreatmentscategoriesTableAdapter
            // 
            this.comboviewDataTabletreatmentscategoriesTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablepaystatusTableAdapter
            // 
            this.comboviewDataTablepaystatusTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletreatmentsTableAdapter
            // 
            this.comboviewDataTabletreatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.animalsnotesTableAdapter = this.animalsnotesTableAdapter;
            this.tableAdapterManager.animalsnotestypesTableAdapter = null;
            this.tableAdapterManager.animalsTableAdapter = this.animalsTableAdapter;
            this.tableAdapterManager.animalstreatmentsTableAdapter = this.animalstreatmentsTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.breedsTableAdapter = null;
            this.tableAdapterManager.calendarsTableAdapter = null;
            this.tableAdapterManager.computedrowsdocsTableAdapter = null;
            this.tableAdapterManager.customersTableAdapter = null;
            this.tableAdapterManager.estimatesitemsTableAdapter = null;
            this.tableAdapterManager.estimatesTableAdapter = null;
            this.tableAdapterManager.familiesTableAdapter = null;
            this.tableAdapterManager.footersdocsTableAdapter = null;
            this.tableAdapterManager.invoicesitemsTableAdapter = null;
            this.tableAdapterManager.invoicespaymentsTableAdapter = null;
            this.tableAdapterManager.invoicesTableAdapter = null;
            this.tableAdapterManager.paymentsTableAdapter = null;
            this.tableAdapterManager.paystatusTableAdapter = null;
            this.tableAdapterManager.reportsTableAdapter = null;
            this.tableAdapterManager.roomsTableAdapter = null;
            this.tableAdapterManager.taxesdeductionTableAdapter = null;
            this.tableAdapterManager.taxesTableAdapter = null;
            this.tableAdapterManager.treatmentscategoriesTableAdapter = null;
            this.tableAdapterManager.treatmentsTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = vettev.DataSet01STableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.usersTableAdapter = null;
            // 
            // FormAnimals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAnimals";
            this.Text = "Animals";
            this.Activated += new System.EventHandler(this.FormAnimals_Activated);
            this.Deactivate += new System.EventHandler(this.FormAnimals_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormAnimals_FormClosing);
            this.Load += new System.EventHandler(this.FormAnimals_Load);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableanimalsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.tabControl_main.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animalsBindingSource)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablebreedsBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_animalstreatmentsmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableanimalstreatmentsBindingSource)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animalstreatmentsBindingSource)).EndInit();
            this.groupBox_animalstreatments_fillfromtreatments.ResumeLayout(false);
            this.groupBox_animalstreatments_fillfromtreatments.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_animalstreatmentsfillfromtreatmentsmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentscategoriesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableusersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablepaystatusBindingSource)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel_animalstreatmentsfilter.ResumeLayout(false);
            this.panel_animalstreatmentsfilter.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_animalsnotesmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableanimalsnotesBindingSource)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.animalsnotesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableanimalsnotestypesBindingSource)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel_animalsnotesfilter.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecustomersBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel_filter.ResumeLayout(false);
            this.panel_filter.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.TabControl tabControl_main;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.ComboBox comboBox_filter_customers_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource viewDataTableanimalsBindingSource;
        private DataSet01VTableAdapters.viewDataTableanimalsTableAdapter viewDataTableanimalsTableAdapter;
        private System.Windows.Forms.BindingSource animalsBindingSource;
        private DataSet01STableAdapters.animalsTableAdapter animalsTableAdapter;
        private System.Windows.Forms.TextBox animals_notesTextBox;
        private System.Windows.Forms.DateTimePicker animals_deathDateTimePicker;
        private System.Windows.Forms.DateTimePicker animals_birthDateTimePicker;
        private System.Windows.Forms.ComboBox breeds_idComboBox;
        private System.Windows.Forms.TextBox animals_nameTextBox;
        private System.Windows.Forms.TextBox animals_tagTextBox;
        private System.Windows.Forms.BindingSource comboviewDataTablebreedsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablebreedsTableAdapter comboviewDataTablebreedsTableAdapter;
        private System.Windows.Forms.CheckBox checkBox_isdeath;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton animals_sex_FradioButton;
        private System.Windows.Forms.RadioButton animals_sex_MradioButton;
        private System.Windows.Forms.RadioButton animals_sex_UradioButton;
        private System.Windows.Forms.CheckBox animals_birthunknowncheckBox;
        private System.Windows.Forms.Button button_Opendatadir;
        private System.Windows.Forms.DateTimePicker animals_dateDateTimePicker;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.DataGridView dataGridView_animalsnotesmain;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.BindingSource subviewDataTableanimalsnotesBindingSource;
        private DataSet01VTableAdapters.subviewDataTableanimalsnotesTableAdapter subviewDataTableanimalsnotesTableAdapter;
        private System.Windows.Forms.BindingSource animalsnotesBindingSource;
        private DataSet01STableAdapters.animalsnotesTableAdapter animalsnotesTableAdapter;
        private System.Windows.Forms.TextBox animalsnotes_notesTextBox;
        private System.Windows.Forms.DateTimePicker animalsnotes_dateDateTimePicker;
        private System.Windows.Forms.ComboBox animalsnotestypes_idComboBox;
        private System.Windows.Forms.Button button_animalsnotesDelete;
        private System.Windows.Forms.Button button_animalsnotesEdit;
        private System.Windows.Forms.Button button_animalsnotesNew;
        private System.Windows.Forms.ComboBox comboBox_animalsnotesfilter_animalsnotestypes_id;
        private System.Windows.Forms.BindingSource comboviewDataTablecustomersBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablecustomersTableAdapter comboviewDataTablecustomersTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTableanimalsnotestypesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTableanimalsnotestypesTableAdapter comboviewDataTableanimalsnotestypesTableAdapter;
        private System.Windows.Forms.ComboBox animalsnotesusers_idComboBox;
        private System.Windows.Forms.BindingSource comboviewDataTableusersBindingSource;
        private DataSet01VTableAdapters.comboviewDataTableusersTableAdapter comboviewDataTableusersTableAdapter;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.DataGridView dataGridView_animalstreatmentsmain;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button_animalstreatmentsDelete;
        private System.Windows.Forms.Button button_animalstreatmentsEdit;
        private System.Windows.Forms.Button button_animalstreatmentsNew;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.BindingSource subviewDataTableanimalstreatmentsBindingSource;
        private DataSet01VTableAdapters.subviewDataTableanimalstreatmentsTableAdapter subviewDataTableanimalstreatmentsTableAdapter;
        private System.Windows.Forms.BindingSource animalstreatmentsBindingSource;
        private DataSet01STableAdapters.animalstreatmentsTableAdapter animalstreatmentsTableAdapter;
        private System.Windows.Forms.TextBox animalstreatments_notesTextBox;
        private System.Windows.Forms.DateTimePicker animalstreatments_dateDateTimePicker;
        private System.Windows.Forms.ComboBox animalstreatmentspaystatus_idComboBox;
        private System.Windows.Forms.ComboBox animalstreatmentsusers_idComboBox;
        private System.Windows.Forms.DateTimePicker animalstreatments_expirationDateTimePicker;
        private System.Windows.Forms.CheckBox checkBox_animalstreatments_expirationdate;
        private System.Windows.Forms.TextBox animalstreatments_priceTextBox;
        private System.Windows.Forms.GroupBox groupBox_animalstreatments_fillfromtreatments;
        private System.Windows.Forms.Button button_animalstreatmentsfillfromtreatments;
        private System.Windows.Forms.BindingSource comboviewDataTabletreatmentscategoriesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletreatmentscategoriesTableAdapter comboviewDataTabletreatmentscategoriesTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTablepaystatusBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablepaystatusTableAdapter comboviewDataTablepaystatusTableAdapter;
        private System.Windows.Forms.TextBox animalstreatments_descTextBox;
        private System.Windows.Forms.BindingSource comboviewDataTabletreatmentsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletreatmentsTableAdapter comboviewDataTabletreatmentsTableAdapter;
        private System.Windows.Forms.TextBox animals_idTextBox;
        private System.Windows.Forms.TextBox textBox_filter_animals;
        private System.Windows.Forms.ComboBox comboBox_animalstreatmentsfilter_treamtentscategories_id;
        private System.Windows.Forms.ComboBox animalstreatmentstreatmentscategories_idComboBox;
        private System.Windows.Forms.CheckBox animalstreatments_expirationadviceCheckBox;
        private System.Windows.Forms.DataGridView dataGridView_animalstreatmentsfillfromtreatmentsmain;
        private System.Windows.Forms.TextBox textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name;
        private System.Windows.Forms.TextBox textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscategoriesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentsdescDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id;
        private System.Windows.Forms.TextBox animalstreatments_codeTextBox;
        private System.Windows.Forms.TextBox textBox_animalstreatmentsfilter_animalstreatments_code;
        private System.Windows.Forms.CheckBox animalstreatments_invoiceableCheckBox;
        private System.Windows.Forms.TextBox textBox_animalstreatments_invoicesinfo;
        private System.Windows.Forms.Panel panel_filter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel_animalstreatmentsfilter;
        private System.Windows.Forms.Panel panel_animalsnotesfilter;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsnotestypesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsnotesdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsnotesnotesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn familiesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn breedsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button_Print;
        private System.Windows.Forms.Button button_Stopedit;
        private System.Windows.Forms.TextBox customers_idTextBox;
        private System.Windows.Forms.TextBox customers_aliasTextBox;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.RadioButton animals_sterilized_NradioButton;
        private System.Windows.Forms.RadioButton animals_sterilized_YradioButton;
        private System.Windows.Forms.RadioButton animals_sterilized_UradioButton;
        private System.Windows.Forms.TextBox textBox_animalstreatmentsfilter_animalstreatments_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalstreatmentsidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalstreatmentscodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscategoriesnameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn paystatusnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalstreatmentsdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalstreatmentsdescDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox animalstreatments_idTextBox;
        private DataSet01STableAdapters.TableAdapterManager tableAdapterManager;
    }
}