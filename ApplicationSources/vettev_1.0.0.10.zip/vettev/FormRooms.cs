﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormRooms : Form
    {
        int rooms_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormRooms()
        {
            InitializeComponent();
        }

        private void FormRooms_Load(object sender, EventArgs e)
        {
            this.viewDataTableroomsTableAdapter.Fill(this.dataSet01V.viewDataTablerooms);

            viewDataTableroomsBindingSource.Sort = "rooms_name";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTableroomsBindingSource_CurrentChanged(null, null);
        }

        private void FormRooms_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormRooms_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormRooms_Load(sender, e);
        }

        private void FormRooms_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                rooms_nameTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                rooms_nameTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            roomsBindingSource.AddNew();
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (rooms_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (rooms_id != -1 && rooms_id != 1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    {
                        DataSet01STableAdapters.calendarsTableAdapter t = new DataSet01STableAdapters.calendarsTableAdapter();
                        foreach (DataSet01S.calendarsRow r in t.GetDataBy3(rooms_id).Select())
                        {
                            r.rooms_id = 1;
                            t.Update(r);
                        }
                    }

                    roomsBindingSource.RemoveCurrent();
                    roomsTableAdapter.Update(dataSet01S.rooms);
                    dataSet01S.rooms.AcceptChanges();

                    viewDataTableroomsTableAdapter.Fill(dataSet01V.viewDataTablerooms);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (rooms_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.roomsTableAdapter t = new DataSet01STableAdapters.roomsTableAdapter();
                if (t.GetDataBy1(rooms_nameTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1(rooms_nameTextBox.Text).Select("rooms_id <> " + rooms_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            roomsBindingSource.EndEdit();
            roomsTableAdapter.Update(dataSet01S.rooms);
            dataSet01S.rooms.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = roomsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = rooms_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTableroomsTableAdapter.Fill(dataSet01V.viewDataTablerooms);
            viewDataTableroomsBindingSource.Position = viewDataTableroomsBindingSource.Find("rooms_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            roomsBindingSource.CancelEdit();
            dataSet01S.rooms.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTableroomsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            rooms_id = -1;

            roomsBindingSource.Filter = "rooms_id = -1";

            try
            {
                rooms_id = (int)((DataSet01V.viewDataTableroomsRow)((DataRowView)viewDataTableroomsBindingSource.Current).Row).rooms_id;
            }
            catch { }

            if (rooms_id != -1)
            {
                roomsTableAdapter.Fill(dataSet01S.rooms, rooms_id);

                roomsBindingSource.RemoveFilter();
                roomsBindingSource.Position = roomsBindingSource.Find("rooms_id", rooms_id);
            }
        }
    }
}
