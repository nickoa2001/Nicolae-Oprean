﻿namespace vettev
{
    partial class FormFamilies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label families_nameLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormFamilies));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.familiesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTablefamiliesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01V = new vettev.DataSet01V();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_New = new System.Windows.Forms.Button();
            this.dataSet01S = new vettev.DataSet01S();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.families_nameTextBox = new System.Windows.Forms.TextBox();
            this.familiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Undo = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.viewDataTablefamiliesTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTablefamiliesTableAdapter();
            this.familiesTableAdapter = new vettev.DataSet01STableAdapters.familiesTableAdapter();
            families_nameLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablefamiliesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.familiesBindingSource)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // families_nameLabel
            // 
            families_nameLabel.AutoSize = true;
            families_nameLabel.Location = new System.Drawing.Point(10, 15);
            families_nameLabel.Name = "families_nameLabel";
            families_nameLabel.Size = new System.Drawing.Size(36, 13);
            families_nameLabel.TabIndex = 0;
            families_nameLabel.Text = "name:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(378, 462);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(378, 422);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.familiesnameDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTablefamiliesBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(378, 422);
            this.dataGridView_main.TabIndex = 0;
            // 
            // familiesnameDataGridViewTextBoxColumn
            // 
            this.familiesnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.familiesnameDataGridViewTextBoxColumn.DataPropertyName = "families_name";
            this.familiesnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.familiesnameDataGridViewTextBoxColumn.Name = "familiesnameDataGridViewTextBoxColumn";
            this.familiesnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTablefamiliesBindingSource
            // 
            this.viewDataTablefamiliesBindingSource.DataMember = "viewDataTablefamilies";
            this.viewDataTablefamiliesBindingSource.DataSource = this.dataSet01V;
            this.viewDataTablefamiliesBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTablefamiliesBindingSource_CurrentChanged);
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 422);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(378, 40);
            this.panel4.TabIndex = 1;
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(378, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(306, 462);
            this.panel2.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(families_nameLabel);
            this.panel6.Controls.Add(this.families_nameTextBox);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(306, 422);
            this.panel6.TabIndex = 1;
            // 
            // families_nameTextBox
            // 
            this.families_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.familiesBindingSource, "families_name", true));
            this.families_nameTextBox.Location = new System.Drawing.Point(13, 31);
            this.families_nameTextBox.MaxLength = 100;
            this.families_nameTextBox.Name = "families_nameTextBox";
            this.families_nameTextBox.Size = new System.Drawing.Size(281, 20);
            this.families_nameTextBox.TabIndex = 1;
            // 
            // familiesBindingSource
            // 
            this.familiesBindingSource.DataMember = "families";
            this.familiesBindingSource.DataSource = this.dataSet01S;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 422);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(306, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // viewDataTablefamiliesTableAdapter
            // 
            this.viewDataTablefamiliesTableAdapter.ClearBeforeFill = true;
            // 
            // familiesTableAdapter
            // 
            this.familiesTableAdapter.ClearBeforeFill = true;
            // 
            // FormFamilies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 462);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormFamilies";
            this.Text = "Families";
            this.Activated += new System.EventHandler(this.FormFamilies_Activated);
            this.Deactivate += new System.EventHandler(this.FormFamilies_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormFamilies_FormClosing);
            this.Load += new System.EventHandler(this.FormFamilies_Load);
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablefamiliesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.familiesBindingSource)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.BindingSource viewDataTablefamiliesBindingSource;
        private DataSet01VTableAdapters.viewDataTablefamiliesTableAdapter viewDataTablefamiliesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn familiesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.BindingSource familiesBindingSource;
        private DataSet01STableAdapters.familiesTableAdapter familiesTableAdapter;
        private System.Windows.Forms.TextBox families_nameTextBox;
    }
}