﻿namespace vettev
{
    partial class FormPayments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label payments_descLabel;
            System.Windows.Forms.Label payments_nameLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPayments));
            this.dataSet01S = new vettev.DataSet01S();
            this.dataSet01V = new vettev.DataSet01V();
            this.panel6 = new System.Windows.Forms.Panel();
            this.payments_nameTextBox = new System.Windows.Forms.TextBox();
            this.paymentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.payments_descTextBox = new System.Windows.Forms.TextBox();
            this.button_New = new System.Windows.Forms.Button();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.paymentsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTablepaymentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Undo = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.viewDataTablepaymentsTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTablepaymentsTableAdapter();
            this.paymentsTableAdapter = new vettev.DataSet01STableAdapters.paymentsTableAdapter();
            payments_descLabel = new System.Windows.Forms.Label();
            payments_nameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablepaymentsBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // payments_descLabel
            // 
            payments_descLabel.AutoSize = true;
            payments_descLabel.Location = new System.Drawing.Point(6, 54);
            payments_descLabel.Name = "payments_descLabel";
            payments_descLabel.Size = new System.Drawing.Size(61, 13);
            payments_descLabel.TabIndex = 2;
            payments_descLabel.Text = "description:";
            // 
            // payments_nameLabel
            // 
            payments_nameLabel.AutoSize = true;
            payments_nameLabel.Location = new System.Drawing.Point(10, 15);
            payments_nameLabel.Name = "payments_nameLabel";
            payments_nameLabel.Size = new System.Drawing.Size(36, 13);
            payments_nameLabel.TabIndex = 4;
            payments_nameLabel.Text = "name:";
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(payments_nameLabel);
            this.panel6.Controls.Add(this.payments_nameTextBox);
            this.panel6.Controls.Add(payments_descLabel);
            this.panel6.Controls.Add(this.payments_descTextBox);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(300, 422);
            this.panel6.TabIndex = 1;
            // 
            // payments_nameTextBox
            // 
            this.payments_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentsBindingSource, "payments_name", true));
            this.payments_nameTextBox.Location = new System.Drawing.Point(9, 31);
            this.payments_nameTextBox.MaxLength = 100;
            this.payments_nameTextBox.Name = "payments_nameTextBox";
            this.payments_nameTextBox.Size = new System.Drawing.Size(279, 20);
            this.payments_nameTextBox.TabIndex = 5;
            // 
            // paymentsBindingSource
            // 
            this.paymentsBindingSource.DataMember = "payments";
            this.paymentsBindingSource.DataSource = this.dataSet01S;
            // 
            // payments_descTextBox
            // 
            this.payments_descTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentsBindingSource, "payments_desc", true));
            this.payments_descTextBox.Location = new System.Drawing.Point(9, 70);
            this.payments_descTextBox.Multiline = true;
            this.payments_descTextBox.Name = "payments_descTextBox";
            this.payments_descTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.payments_descTextBox.Size = new System.Drawing.Size(279, 50);
            this.payments_descTextBox.TabIndex = 3;
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.paymentsnameDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTablepaymentsBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(384, 422);
            this.dataGridView_main.TabIndex = 0;
            // 
            // paymentsnameDataGridViewTextBoxColumn
            // 
            this.paymentsnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.paymentsnameDataGridViewTextBoxColumn.DataPropertyName = "payments_name";
            this.paymentsnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.paymentsnameDataGridViewTextBoxColumn.Name = "paymentsnameDataGridViewTextBoxColumn";
            this.paymentsnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTablepaymentsBindingSource
            // 
            this.viewDataTablepaymentsBindingSource.DataMember = "viewDataTablepayments";
            this.viewDataTablepaymentsBindingSource.DataSource = this.dataSet01V;
            this.viewDataTablepaymentsBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTablepaymentsBindingSource_CurrentChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 462);
            this.panel1.TabIndex = 4;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(384, 422);
            this.panel5.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 422);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 40);
            this.panel4.TabIndex = 1;
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(384, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(300, 462);
            this.panel2.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 422);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(300, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // viewDataTablepaymentsTableAdapter
            // 
            this.viewDataTablepaymentsTableAdapter.ClearBeforeFill = true;
            // 
            // paymentsTableAdapter
            // 
            this.paymentsTableAdapter.ClearBeforeFill = true;
            // 
            // FormPayments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 462);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormPayments";
            this.Text = "Payments";
            this.Activated += new System.EventHandler(this.FormPayments_Activated);
            this.Deactivate += new System.EventHandler(this.FormPayments_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormPayments_FormClosing);
            this.Load += new System.EventHandler(this.FormPayments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablepaymentsBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.BindingSource viewDataTablepaymentsBindingSource;
        private DataSet01VTableAdapters.viewDataTablepaymentsTableAdapter viewDataTablepaymentsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource paymentsBindingSource;
        private DataSet01STableAdapters.paymentsTableAdapter paymentsTableAdapter;
        private System.Windows.Forms.TextBox payments_nameTextBox;
        private System.Windows.Forms.TextBox payments_descTextBox;
    }
}