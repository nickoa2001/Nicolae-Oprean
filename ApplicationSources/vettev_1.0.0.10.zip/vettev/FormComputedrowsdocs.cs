﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormComputedrowsdocs : Form
    {
        int computedrowsdocs_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormComputedrowsdocs()
        {
            InitializeComponent();
        }

        private void FormComputedrowsdocs_Load(object sender, EventArgs e)
        {
            this.viewDataTablecomputedrowsdocsTableAdapter.Fill(this.dataSet01V.viewDataTablecomputedrowsdocs);

            viewDataTablecomputedrowsdocsBindingSource.Sort = "computedrowsdocs_name";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTablecomputedrowsdocsBindingSource_CurrentChanged(null, null);
        }

        private void FormComputedrowsdocs_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormComputedrowsdocs_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormComputedrowsdocs_Load(sender, e);
        }

        private void FormComputedrowsdocs_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                computedrowsdocs_nameTextBox.ReadOnly = false;
                computedrowsdocs_percentTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                computedrowsdocs_nameTextBox.ReadOnly = true;
                computedrowsdocs_percentTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            computedrowsdocsBindingSource.AddNew();

            computedrowsdocs_percentTextBox.Text = "0";
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (computedrowsdocs_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (computedrowsdocs_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    bool candelete = true;
                    string candeletetxt = "";

                    {
                        DataSet01STableAdapters.treatmentsTableAdapter t = new DataSet01STableAdapters.treatmentsTableAdapter();
                        if (t.GetDataBy3(computedrowsdocs_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "treatments" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    if (!candelete)
                    {
                        MessageBox.Show(candeletetxt);
                        return;
                    }

                    computedrowsdocsBindingSource.RemoveCurrent();
                    computedrowsdocsTableAdapter.Update(dataSet01S.computedrowsdocs);
                    dataSet01S.computedrowsdocs.AcceptChanges();

                    viewDataTablecomputedrowsdocsTableAdapter.Fill(dataSet01V.viewDataTablecomputedrowsdocs);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (computedrowsdocs_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.computedrowsdocsTableAdapter t = new DataSet01STableAdapters.computedrowsdocsTableAdapter();
                if (t.GetDataBy1(computedrowsdocs_nameTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1(computedrowsdocs_nameTextBox.Text).Select("computedrowsdocs_id <> " + computedrowsdocs_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
            }
            if (computedrowsdocs_percentTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid percent" + Environment.NewLine;
            }
            else
            {
                try
                {
                    decimal d = Convert.ToDecimal(computedrowsdocs_percentTextBox.Text);
                    if (d < 0 || d > 100)
                    {
                        valid_b = false;
                        valid_s += "invalid percent" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid percent" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            computedrowsdocsBindingSource.EndEdit();
            computedrowsdocsTableAdapter.Update(dataSet01S.computedrowsdocs);
            dataSet01S.computedrowsdocs.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = computedrowsdocsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = computedrowsdocs_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTablecomputedrowsdocsTableAdapter.Fill(dataSet01V.viewDataTablecomputedrowsdocs);
            viewDataTablecomputedrowsdocsBindingSource.Position = viewDataTablecomputedrowsdocsBindingSource.Find("computedrowsdocs_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            computedrowsdocsBindingSource.CancelEdit();
            dataSet01S.computedrowsdocs.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTablecomputedrowsdocsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            computedrowsdocs_id = -1;

            computedrowsdocsBindingSource.Filter = "computedrowsdocs_id = -1";

            try
            {
                computedrowsdocs_id = (int)((DataSet01V.viewDataTablecomputedrowsdocsRow)((DataRowView)viewDataTablecomputedrowsdocsBindingSource.Current).Row).computedrowsdocs_id;
            }
            catch { }

            if (computedrowsdocs_id != -1)
            {
                computedrowsdocsTableAdapter.Fill(dataSet01S.computedrowsdocs, computedrowsdocs_id);

                computedrowsdocsBindingSource.RemoveFilter();
                computedrowsdocsBindingSource.Position = computedrowsdocsBindingSource.Find("computedrowsdocs_id", computedrowsdocs_id);
            }
        }

        private void computedrowsdocs_percentTextBox_Leave(object sender, EventArgs e)
        {
            if (!computedrowsdocs_percentTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(computedrowsdocs_percentTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }
    }
}
