﻿namespace vettev
{
    partial class FormCustomers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label customers_notesLabel;
            System.Windows.Forms.Label customers_emailLabel;
            System.Windows.Forms.Label customers_faxLabel;
            System.Windows.Forms.Label customers_telLabel;
            System.Windows.Forms.Label customers_taxcodeLabel;
            System.Windows.Forms.Label customers_vatnumberLabel;
            System.Windows.Forms.Label customers_streetLabel;
            System.Windows.Forms.Label customers_zipcodeLabel;
            System.Windows.Forms.Label customers_cityLabel;
            System.Windows.Forms.Label customers_stateLabel;
            System.Windows.Forms.Label customers_surnameLabel;
            System.Windows.Forms.Label customers_nameLabel;
            System.Windows.Forms.Label customers_dateLabel;
            System.Windows.Forms.Label customers_idLabel;
            System.Windows.Forms.Label customers_invoicestextLabel;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCustomers));
            this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01S = new vettev.DataSet01S();
            this.dataSet01V = new vettev.DataSet01V();
            this.customers_notesTextBox = new System.Windows.Forms.TextBox();
            this.customers_faxTextBox = new System.Windows.Forms.TextBox();
            this.customers_emailTextBox = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel_filter = new System.Windows.Forms.Panel();
            this.textBox_filter_customers = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.customers_telTextBox = new System.Windows.Forms.TextBox();
            this.button_Delete = new System.Windows.Forms.Button();
            this.customers_taxcodeTextBox = new System.Windows.Forms.TextBox();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.customersidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerssurnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customersnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customersaliasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTablecustomersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tabControl_main = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button_Makeinvoicetext = new System.Windows.Forms.Button();
            this.customers_invoicestextTextBox = new System.Windows.Forms.TextBox();
            this.customers_idTextBox = new System.Windows.Forms.TextBox();
            this.customers_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.customers_nameTextBox = new System.Windows.Forms.TextBox();
            this.customers_surnameTextBox = new System.Windows.Forms.TextBox();
            this.customers_stateTextBox = new System.Windows.Forms.TextBox();
            this.customers_cityTextBox = new System.Windows.Forms.TextBox();
            this.customers_zipcodeTextBox = new System.Windows.Forms.TextBox();
            this.customers_streetTextBox = new System.Windows.Forms.TextBox();
            this.customers_vatnumberTextBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.familiesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.breedsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.animalsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTableanimalsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel10 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.invoicesdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoicesnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paystatusnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersaliasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invoicestotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTableinvoicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.calendarsfromDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calendarstoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.calendarstitleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersaliasDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTablecalendarsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Undo = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button_New = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.viewDataTablecustomersTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTablecustomersTableAdapter();
            this.customersTableAdapter = new vettev.DataSet01STableAdapters.customersTableAdapter();
            this.subviewDataTableanimalsTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableanimalsTableAdapter();
            this.subviewDataTableinvoicesTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableinvoicesTableAdapter();
            this.subviewDataTablecalendarsTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTablecalendarsTableAdapter();
            customers_notesLabel = new System.Windows.Forms.Label();
            customers_emailLabel = new System.Windows.Forms.Label();
            customers_faxLabel = new System.Windows.Forms.Label();
            customers_telLabel = new System.Windows.Forms.Label();
            customers_taxcodeLabel = new System.Windows.Forms.Label();
            customers_vatnumberLabel = new System.Windows.Forms.Label();
            customers_streetLabel = new System.Windows.Forms.Label();
            customers_zipcodeLabel = new System.Windows.Forms.Label();
            customers_cityLabel = new System.Windows.Forms.Label();
            customers_stateLabel = new System.Windows.Forms.Label();
            customers_surnameLabel = new System.Windows.Forms.Label();
            customers_nameLabel = new System.Windows.Forms.Label();
            customers_dateLabel = new System.Windows.Forms.Label();
            customers_idLabel = new System.Windows.Forms.Label();
            customers_invoicestextLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel_filter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablecustomersBindingSource)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabControl_main.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableanimalsBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableinvoicesBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTablecalendarsBindingSource)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // customers_notesLabel
            // 
            customers_notesLabel.AutoSize = true;
            customers_notesLabel.Location = new System.Drawing.Point(10, 363);
            customers_notesLabel.Name = "customers_notesLabel";
            customers_notesLabel.Size = new System.Drawing.Size(36, 13);
            customers_notesLabel.TabIndex = 26;
            customers_notesLabel.Text = "notes:";
            // 
            // customers_emailLabel
            // 
            customers_emailLabel.AutoSize = true;
            customers_emailLabel.Location = new System.Drawing.Point(281, 216);
            customers_emailLabel.Name = "customers_emailLabel";
            customers_emailLabel.Size = new System.Drawing.Size(34, 13);
            customers_emailLabel.TabIndex = 22;
            customers_emailLabel.Text = "email:";
            // 
            // customers_faxLabel
            // 
            customers_faxLabel.AutoSize = true;
            customers_faxLabel.Location = new System.Drawing.Point(282, 171);
            customers_faxLabel.Name = "customers_faxLabel";
            customers_faxLabel.Size = new System.Drawing.Size(24, 13);
            customers_faxLabel.TabIndex = 20;
            customers_faxLabel.Text = "fax:";
            // 
            // customers_telLabel
            // 
            customers_telLabel.AutoSize = true;
            customers_telLabel.Location = new System.Drawing.Point(282, 132);
            customers_telLabel.Name = "customers_telLabel";
            customers_telLabel.Size = new System.Drawing.Size(21, 13);
            customers_telLabel.TabIndex = 18;
            customers_telLabel.Text = "tel:";
            // 
            // customers_taxcodeLabel
            // 
            customers_taxcodeLabel.AutoSize = true;
            customers_taxcodeLabel.Location = new System.Drawing.Point(130, 132);
            customers_taxcodeLabel.Name = "customers_taxcodeLabel";
            customers_taxcodeLabel.Size = new System.Drawing.Size(51, 13);
            customers_taxcodeLabel.TabIndex = 16;
            customers_taxcodeLabel.Text = "tax code:";
            // 
            // customers_vatnumberLabel
            // 
            customers_vatnumberLabel.AutoSize = true;
            customers_vatnumberLabel.Location = new System.Drawing.Point(127, 171);
            customers_vatnumberLabel.Name = "customers_vatnumberLabel";
            customers_vatnumberLabel.Size = new System.Drawing.Size(63, 13);
            customers_vatnumberLabel.TabIndex = 14;
            customers_vatnumberLabel.Text = "vat number:";
            // 
            // customers_streetLabel
            // 
            customers_streetLabel.AutoSize = true;
            customers_streetLabel.Location = new System.Drawing.Point(10, 255);
            customers_streetLabel.Name = "customers_streetLabel";
            customers_streetLabel.Size = new System.Drawing.Size(36, 13);
            customers_streetLabel.TabIndex = 12;
            customers_streetLabel.Text = "street:";
            // 
            // customers_zipcodeLabel
            // 
            customers_zipcodeLabel.AutoSize = true;
            customers_zipcodeLabel.Location = new System.Drawing.Point(10, 216);
            customers_zipcodeLabel.Name = "customers_zipcodeLabel";
            customers_zipcodeLabel.Size = new System.Drawing.Size(50, 13);
            customers_zipcodeLabel.TabIndex = 10;
            customers_zipcodeLabel.Text = "zip code:";
            // 
            // customers_cityLabel
            // 
            customers_cityLabel.AutoSize = true;
            customers_cityLabel.Location = new System.Drawing.Point(10, 171);
            customers_cityLabel.Name = "customers_cityLabel";
            customers_cityLabel.Size = new System.Drawing.Size(26, 13);
            customers_cityLabel.TabIndex = 8;
            customers_cityLabel.Text = "city:";
            // 
            // customers_stateLabel
            // 
            customers_stateLabel.AutoSize = true;
            customers_stateLabel.Location = new System.Drawing.Point(10, 132);
            customers_stateLabel.Name = "customers_stateLabel";
            customers_stateLabel.Size = new System.Drawing.Size(33, 13);
            customers_stateLabel.TabIndex = 6;
            customers_stateLabel.Text = "state:";
            // 
            // customers_surnameLabel
            // 
            customers_surnameLabel.AutoSize = true;
            customers_surnameLabel.Location = new System.Drawing.Point(10, 93);
            customers_surnameLabel.Name = "customers_surnameLabel";
            customers_surnameLabel.Size = new System.Drawing.Size(50, 13);
            customers_surnameLabel.TabIndex = 4;
            customers_surnameLabel.Text = "surname:";
            // 
            // customers_nameLabel
            // 
            customers_nameLabel.AutoSize = true;
            customers_nameLabel.Location = new System.Drawing.Point(10, 54);
            customers_nameLabel.Name = "customers_nameLabel";
            customers_nameLabel.Size = new System.Drawing.Size(36, 13);
            customers_nameLabel.TabIndex = 2;
            customers_nameLabel.Text = "name:";
            // 
            // customers_dateLabel
            // 
            customers_dateLabel.AutoSize = true;
            customers_dateLabel.Location = new System.Drawing.Point(283, 13);
            customers_dateLabel.Name = "customers_dateLabel";
            customers_dateLabel.Size = new System.Drawing.Size(47, 13);
            customers_dateLabel.TabIndex = 29;
            customers_dateLabel.Text = "inserted:";
            // 
            // customers_idLabel
            // 
            customers_idLabel.AutoSize = true;
            customers_idLabel.Location = new System.Drawing.Point(10, 15);
            customers_idLabel.Name = "customers_idLabel";
            customers_idLabel.Size = new System.Drawing.Size(18, 13);
            customers_idLabel.TabIndex = 30;
            customers_idLabel.Text = "id:";
            // 
            // customers_invoicestextLabel
            // 
            customers_invoicestextLabel.AutoSize = true;
            customers_invoicestextLabel.Location = new System.Drawing.Point(10, 294);
            customers_invoicestextLabel.Name = "customers_invoicestextLabel";
            customers_invoicestextLabel.Size = new System.Drawing.Size(64, 13);
            customers_invoicestextLabel.TabIndex = 31;
            customers_invoicestextLabel.Text = "invoice text:";
            // 
            // customersBindingSource
            // 
            this.customersBindingSource.DataMember = "customers";
            this.customersBindingSource.DataSource = this.dataSet01S;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customers_notesTextBox
            // 
            this.customers_notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_notes", true));
            this.customers_notesTextBox.Location = new System.Drawing.Point(14, 379);
            this.customers_notesTextBox.Multiline = true;
            this.customers_notesTextBox.Name = "customers_notesTextBox";
            this.customers_notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.customers_notesTextBox.Size = new System.Drawing.Size(371, 50);
            this.customers_notesTextBox.TabIndex = 27;
            // 
            // customers_faxTextBox
            // 
            this.customers_faxTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_fax", true));
            this.customers_faxTextBox.Location = new System.Drawing.Point(285, 190);
            this.customers_faxTextBox.MaxLength = 15;
            this.customers_faxTextBox.Name = "customers_faxTextBox";
            this.customers_faxTextBox.Size = new System.Drawing.Size(100, 20);
            this.customers_faxTextBox.TabIndex = 21;
            // 
            // customers_emailTextBox
            // 
            this.customers_emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_email", true));
            this.customers_emailTextBox.Location = new System.Drawing.Point(285, 232);
            this.customers_emailTextBox.MaxLength = 100;
            this.customers_emailTextBox.Name = "customers_emailTextBox";
            this.customers_emailTextBox.Size = new System.Drawing.Size(100, 20);
            this.customers_emailTextBox.TabIndex = 23;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel_filter);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(434, 40);
            this.panel7.TabIndex = 3;
            // 
            // panel_filter
            // 
            this.panel_filter.Controls.Add(this.textBox_filter_customers);
            this.panel_filter.Controls.Add(this.label1);
            this.panel_filter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filter.Location = new System.Drawing.Point(0, 0);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new System.Drawing.Size(434, 40);
            this.panel_filter.TabIndex = 3;
            // 
            // textBox_filter_customers
            // 
            this.textBox_filter_customers.Location = new System.Drawing.Point(151, 12);
            this.textBox_filter_customers.Name = "textBox_filter_customers";
            this.textBox_filter_customers.Size = new System.Drawing.Size(180, 20);
            this.textBox_filter_customers.TabIndex = 1;
            this.textBox_filter_customers.TextChanged += new System.EventHandler(this.textBox_filter_customers_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "name / surname / id";
            // 
            // customers_telTextBox
            // 
            this.customers_telTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_tel", true));
            this.customers_telTextBox.Location = new System.Drawing.Point(284, 148);
            this.customers_telTextBox.MaxLength = 15;
            this.customers_telTextBox.Name = "customers_telTextBox";
            this.customers_telTextBox.Size = new System.Drawing.Size(100, 20);
            this.customers_telTextBox.TabIndex = 19;
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // customers_taxcodeTextBox
            // 
            this.customers_taxcodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_taxcode", true));
            this.customers_taxcodeTextBox.Location = new System.Drawing.Point(130, 148);
            this.customers_taxcodeTextBox.MaxLength = 25;
            this.customers_taxcodeTextBox.Name = "customers_taxcodeTextBox";
            this.customers_taxcodeTextBox.Size = new System.Drawing.Size(135, 20);
            this.customers_taxcodeTextBox.TabIndex = 17;
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customersidDataGridViewTextBoxColumn,
            this.customerssurnameDataGridViewTextBoxColumn,
            this.customersnameDataGridViewTextBoxColumn,
            this.customersaliasDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTablecustomersBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(434, 432);
            this.dataGridView_main.TabIndex = 0;
            // 
            // customersidDataGridViewTextBoxColumn
            // 
            this.customersidDataGridViewTextBoxColumn.DataPropertyName = "customers_id";
            this.customersidDataGridViewTextBoxColumn.HeaderText = "Id";
            this.customersidDataGridViewTextBoxColumn.Name = "customersidDataGridViewTextBoxColumn";
            this.customersidDataGridViewTextBoxColumn.ReadOnly = true;
            this.customersidDataGridViewTextBoxColumn.Width = 50;
            // 
            // customerssurnameDataGridViewTextBoxColumn
            // 
            this.customerssurnameDataGridViewTextBoxColumn.DataPropertyName = "customers_surname";
            this.customerssurnameDataGridViewTextBoxColumn.HeaderText = "Surname";
            this.customerssurnameDataGridViewTextBoxColumn.Name = "customerssurnameDataGridViewTextBoxColumn";
            this.customerssurnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.customerssurnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // customersnameDataGridViewTextBoxColumn
            // 
            this.customersnameDataGridViewTextBoxColumn.DataPropertyName = "customers_name";
            this.customersnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.customersnameDataGridViewTextBoxColumn.Name = "customersnameDataGridViewTextBoxColumn";
            this.customersnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.customersnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // customersaliasDataGridViewTextBoxColumn
            // 
            this.customersaliasDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customersaliasDataGridViewTextBoxColumn.DataPropertyName = "customers_alias";
            this.customersaliasDataGridViewTextBoxColumn.HeaderText = "Alias";
            this.customersaliasDataGridViewTextBoxColumn.Name = "customersaliasDataGridViewTextBoxColumn";
            this.customersaliasDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // viewDataTablecustomersBindingSource
            // 
            this.viewDataTablecustomersBindingSource.DataMember = "viewDataTablecustomers";
            this.viewDataTablecustomersBindingSource.DataSource = this.dataSet01V;
            this.viewDataTablecustomersBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTablecustomersBindingSource_CurrentChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(434, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 512);
            this.panel2.TabIndex = 5;
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.Controls.Add(this.tabControl_main);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 472);
            this.panel6.TabIndex = 1;
            // 
            // tabControl_main
            // 
            this.tabControl_main.Controls.Add(this.tabPage1);
            this.tabControl_main.Controls.Add(this.tabPage2);
            this.tabControl_main.Controls.Add(this.tabPage3);
            this.tabControl_main.Controls.Add(this.tabPage4);
            this.tabControl_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_main.Location = new System.Drawing.Point(0, 0);
            this.tabControl_main.Name = "tabControl_main";
            this.tabControl_main.SelectedIndex = 0;
            this.tabControl_main.Size = new System.Drawing.Size(400, 472);
            this.tabControl_main.TabIndex = 30;
            this.tabControl_main.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_main_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.button_Makeinvoicetext);
            this.tabPage1.Controls.Add(customers_invoicestextLabel);
            this.tabPage1.Controls.Add(this.customers_invoicestextTextBox);
            this.tabPage1.Controls.Add(customers_idLabel);
            this.tabPage1.Controls.Add(this.customers_idTextBox);
            this.tabPage1.Controls.Add(customers_dateLabel);
            this.tabPage1.Controls.Add(this.customers_dateDateTimePicker);
            this.tabPage1.Controls.Add(this.customers_nameTextBox);
            this.tabPage1.Controls.Add(customers_nameLabel);
            this.tabPage1.Controls.Add(customers_notesLabel);
            this.tabPage1.Controls.Add(this.customers_surnameTextBox);
            this.tabPage1.Controls.Add(this.customers_notesTextBox);
            this.tabPage1.Controls.Add(customers_surnameLabel);
            this.tabPage1.Controls.Add(customers_emailLabel);
            this.tabPage1.Controls.Add(this.customers_stateTextBox);
            this.tabPage1.Controls.Add(this.customers_emailTextBox);
            this.tabPage1.Controls.Add(customers_stateLabel);
            this.tabPage1.Controls.Add(customers_faxLabel);
            this.tabPage1.Controls.Add(this.customers_cityTextBox);
            this.tabPage1.Controls.Add(this.customers_faxTextBox);
            this.tabPage1.Controls.Add(customers_cityLabel);
            this.tabPage1.Controls.Add(customers_telLabel);
            this.tabPage1.Controls.Add(this.customers_zipcodeTextBox);
            this.tabPage1.Controls.Add(this.customers_telTextBox);
            this.tabPage1.Controls.Add(customers_zipcodeLabel);
            this.tabPage1.Controls.Add(customers_taxcodeLabel);
            this.tabPage1.Controls.Add(this.customers_streetTextBox);
            this.tabPage1.Controls.Add(this.customers_taxcodeTextBox);
            this.tabPage1.Controls.Add(customers_streetLabel);
            this.tabPage1.Controls.Add(customers_vatnumberLabel);
            this.tabPage1.Controls.Add(this.customers_vatnumberTextBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(392, 446);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "customer";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button_Makeinvoicetext
            // 
            this.button_Makeinvoicetext.Location = new System.Drawing.Point(262, 281);
            this.button_Makeinvoicetext.Name = "button_Makeinvoicetext";
            this.button_Makeinvoicetext.Size = new System.Drawing.Size(120, 23);
            this.button_Makeinvoicetext.TabIndex = 33;
            this.button_Makeinvoicetext.Text = "Make Invoice Text";
            this.button_Makeinvoicetext.UseVisualStyleBackColor = true;
            this.button_Makeinvoicetext.Click += new System.EventHandler(this.button_Makeinvoicetext_Click);
            // 
            // customers_invoicestextTextBox
            // 
            this.customers_invoicestextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_invoicestext", true));
            this.customers_invoicestextTextBox.Location = new System.Drawing.Point(13, 310);
            this.customers_invoicestextTextBox.Multiline = true;
            this.customers_invoicestextTextBox.Name = "customers_invoicestextTextBox";
            this.customers_invoicestextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.customers_invoicestextTextBox.Size = new System.Drawing.Size(371, 50);
            this.customers_invoicestextTextBox.TabIndex = 32;
            // 
            // customers_idTextBox
            // 
            this.customers_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_id", true));
            this.customers_idTextBox.Location = new System.Drawing.Point(13, 31);
            this.customers_idTextBox.Name = "customers_idTextBox";
            this.customers_idTextBox.ReadOnly = true;
            this.customers_idTextBox.Size = new System.Drawing.Size(100, 20);
            this.customers_idTextBox.TabIndex = 31;
            // 
            // customers_dateDateTimePicker
            // 
            this.customers_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.customersBindingSource, "customers_date", true));
            this.customers_dateDateTimePicker.Enabled = false;
            this.customers_dateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.customers_dateDateTimePicker.Location = new System.Drawing.Point(286, 31);
            this.customers_dateDateTimePicker.Name = "customers_dateDateTimePicker";
            this.customers_dateDateTimePicker.Size = new System.Drawing.Size(100, 20);
            this.customers_dateDateTimePicker.TabIndex = 30;
            // 
            // customers_nameTextBox
            // 
            this.customers_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_name", true));
            this.customers_nameTextBox.Location = new System.Drawing.Point(13, 70);
            this.customers_nameTextBox.MaxLength = 100;
            this.customers_nameTextBox.Name = "customers_nameTextBox";
            this.customers_nameTextBox.Size = new System.Drawing.Size(371, 20);
            this.customers_nameTextBox.TabIndex = 3;
            // 
            // customers_surnameTextBox
            // 
            this.customers_surnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_surname", true));
            this.customers_surnameTextBox.Location = new System.Drawing.Point(13, 109);
            this.customers_surnameTextBox.MaxLength = 100;
            this.customers_surnameTextBox.Name = "customers_surnameTextBox";
            this.customers_surnameTextBox.Size = new System.Drawing.Size(371, 20);
            this.customers_surnameTextBox.TabIndex = 5;
            // 
            // customers_stateTextBox
            // 
            this.customers_stateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_state", true));
            this.customers_stateTextBox.Location = new System.Drawing.Point(13, 148);
            this.customers_stateTextBox.MaxLength = 100;
            this.customers_stateTextBox.Name = "customers_stateTextBox";
            this.customers_stateTextBox.Size = new System.Drawing.Size(100, 20);
            this.customers_stateTextBox.TabIndex = 7;
            // 
            // customers_cityTextBox
            // 
            this.customers_cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_city", true));
            this.customers_cityTextBox.Location = new System.Drawing.Point(13, 190);
            this.customers_cityTextBox.MaxLength = 100;
            this.customers_cityTextBox.Name = "customers_cityTextBox";
            this.customers_cityTextBox.Size = new System.Drawing.Size(100, 20);
            this.customers_cityTextBox.TabIndex = 9;
            // 
            // customers_zipcodeTextBox
            // 
            this.customers_zipcodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_zipcode", true));
            this.customers_zipcodeTextBox.Location = new System.Drawing.Point(13, 232);
            this.customers_zipcodeTextBox.MaxLength = 15;
            this.customers_zipcodeTextBox.Name = "customers_zipcodeTextBox";
            this.customers_zipcodeTextBox.Size = new System.Drawing.Size(100, 20);
            this.customers_zipcodeTextBox.TabIndex = 11;
            // 
            // customers_streetTextBox
            // 
            this.customers_streetTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_street", true));
            this.customers_streetTextBox.Location = new System.Drawing.Point(13, 271);
            this.customers_streetTextBox.MaxLength = 100;
            this.customers_streetTextBox.Name = "customers_streetTextBox";
            this.customers_streetTextBox.Size = new System.Drawing.Size(100, 20);
            this.customers_streetTextBox.TabIndex = 13;
            // 
            // customers_vatnumberTextBox
            // 
            this.customers_vatnumberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customersBindingSource, "customers_vatnumber", true));
            this.customers_vatnumberTextBox.Location = new System.Drawing.Point(130, 190);
            this.customers_vatnumberTextBox.MaxLength = 15;
            this.customers_vatnumberTextBox.Name = "customers_vatnumberTextBox";
            this.customers_vatnumberTextBox.Size = new System.Drawing.Size(135, 20);
            this.customers_vatnumberTextBox.TabIndex = 15;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panel8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(392, 446);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "animals";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.dataGridView1);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(386, 440);
            this.panel8.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.familiesnameDataGridViewTextBoxColumn,
            this.breedsnameDataGridViewTextBoxColumn,
            this.animalsnameDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.subviewDataTableanimalsBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(386, 440);
            this.dataGridView1.TabIndex = 1;
            // 
            // familiesnameDataGridViewTextBoxColumn
            // 
            this.familiesnameDataGridViewTextBoxColumn.DataPropertyName = "families_name";
            this.familiesnameDataGridViewTextBoxColumn.HeaderText = "Family";
            this.familiesnameDataGridViewTextBoxColumn.Name = "familiesnameDataGridViewTextBoxColumn";
            this.familiesnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.familiesnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // breedsnameDataGridViewTextBoxColumn
            // 
            this.breedsnameDataGridViewTextBoxColumn.DataPropertyName = "breeds_name";
            this.breedsnameDataGridViewTextBoxColumn.HeaderText = "Breed";
            this.breedsnameDataGridViewTextBoxColumn.Name = "breedsnameDataGridViewTextBoxColumn";
            this.breedsnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.breedsnameDataGridViewTextBoxColumn.Width = 80;
            // 
            // animalsnameDataGridViewTextBoxColumn
            // 
            this.animalsnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.animalsnameDataGridViewTextBoxColumn.DataPropertyName = "animals_name";
            this.animalsnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.animalsnameDataGridViewTextBoxColumn.Name = "animalsnameDataGridViewTextBoxColumn";
            this.animalsnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // subviewDataTableanimalsBindingSource
            // 
            this.subviewDataTableanimalsBindingSource.DataMember = "subviewDataTableanimals";
            this.subviewDataTableanimalsBindingSource.DataSource = this.dataSet01V;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel10);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(392, 446);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "invoices";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.dataGridView2);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(386, 440);
            this.panel10.TabIndex = 1;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AllowUserToResizeColumns = false;
            this.dataGridView2.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.invoicesdateDataGridViewTextBoxColumn,
            this.invoicesnumberDataGridViewTextBoxColumn,
            this.paystatusnameDataGridViewTextBoxColumn,
            this.usersaliasDataGridViewTextBoxColumn,
            this.invoicestotalDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.subviewDataTableinvoicesBindingSource;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(386, 440);
            this.dataGridView2.TabIndex = 2;
            // 
            // invoicesdateDataGridViewTextBoxColumn
            // 
            this.invoicesdateDataGridViewTextBoxColumn.DataPropertyName = "invoices_date";
            this.invoicesdateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.invoicesdateDataGridViewTextBoxColumn.Name = "invoicesdateDataGridViewTextBoxColumn";
            this.invoicesdateDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicesdateDataGridViewTextBoxColumn.Width = 80;
            // 
            // invoicesnumberDataGridViewTextBoxColumn
            // 
            this.invoicesnumberDataGridViewTextBoxColumn.DataPropertyName = "invoices_number";
            this.invoicesnumberDataGridViewTextBoxColumn.HeaderText = "Number";
            this.invoicesnumberDataGridViewTextBoxColumn.Name = "invoicesnumberDataGridViewTextBoxColumn";
            this.invoicesnumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicesnumberDataGridViewTextBoxColumn.Width = 60;
            // 
            // paystatusnameDataGridViewTextBoxColumn
            // 
            this.paystatusnameDataGridViewTextBoxColumn.DataPropertyName = "paystatus_name";
            this.paystatusnameDataGridViewTextBoxColumn.HeaderText = "PayStatus";
            this.paystatusnameDataGridViewTextBoxColumn.Name = "paystatusnameDataGridViewTextBoxColumn";
            this.paystatusnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.paystatusnameDataGridViewTextBoxColumn.Width = 60;
            // 
            // usersaliasDataGridViewTextBoxColumn
            // 
            this.usersaliasDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.usersaliasDataGridViewTextBoxColumn.DataPropertyName = "users_alias";
            this.usersaliasDataGridViewTextBoxColumn.HeaderText = "User";
            this.usersaliasDataGridViewTextBoxColumn.Name = "usersaliasDataGridViewTextBoxColumn";
            this.usersaliasDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // invoicestotalDataGridViewTextBoxColumn
            // 
            this.invoicestotalDataGridViewTextBoxColumn.DataPropertyName = "invoices_total";
            this.invoicestotalDataGridViewTextBoxColumn.HeaderText = "Total";
            this.invoicestotalDataGridViewTextBoxColumn.Name = "invoicestotalDataGridViewTextBoxColumn";
            this.invoicestotalDataGridViewTextBoxColumn.ReadOnly = true;
            this.invoicestotalDataGridViewTextBoxColumn.Width = 60;
            // 
            // subviewDataTableinvoicesBindingSource
            // 
            this.subviewDataTableinvoicesBindingSource.DataMember = "subviewDataTableinvoices";
            this.subviewDataTableinvoicesBindingSource.DataSource = this.dataSet01V;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel9);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(392, 446);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "appointments";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.dataGridView3);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 3);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(386, 440);
            this.panel9.TabIndex = 0;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AllowUserToResizeColumns = false;
            this.dataGridView3.AllowUserToResizeRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.calendarsfromDataGridViewTextBoxColumn,
            this.calendarstoDataGridViewTextBoxColumn,
            this.calendarstitleDataGridViewTextBoxColumn,
            this.usersaliasDataGridViewTextBoxColumn1});
            this.dataGridView3.DataSource = this.subviewDataTablecalendarsBindingSource;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(0, 0);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.Size = new System.Drawing.Size(386, 440);
            this.dataGridView3.TabIndex = 1;
            // 
            // calendarsfromDataGridViewTextBoxColumn
            // 
            this.calendarsfromDataGridViewTextBoxColumn.DataPropertyName = "calendars_from";
            this.calendarsfromDataGridViewTextBoxColumn.HeaderText = "From";
            this.calendarsfromDataGridViewTextBoxColumn.Name = "calendarsfromDataGridViewTextBoxColumn";
            this.calendarsfromDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // calendarstoDataGridViewTextBoxColumn
            // 
            this.calendarstoDataGridViewTextBoxColumn.DataPropertyName = "calendars_to";
            this.calendarstoDataGridViewTextBoxColumn.HeaderText = "To";
            this.calendarstoDataGridViewTextBoxColumn.Name = "calendarstoDataGridViewTextBoxColumn";
            this.calendarstoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // calendarstitleDataGridViewTextBoxColumn
            // 
            this.calendarstitleDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.calendarstitleDataGridViewTextBoxColumn.DataPropertyName = "calendars_title";
            this.calendarstitleDataGridViewTextBoxColumn.HeaderText = "Title";
            this.calendarstitleDataGridViewTextBoxColumn.Name = "calendarstitleDataGridViewTextBoxColumn";
            this.calendarstitleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // usersaliasDataGridViewTextBoxColumn1
            // 
            this.usersaliasDataGridViewTextBoxColumn1.DataPropertyName = "users_alias";
            this.usersaliasDataGridViewTextBoxColumn1.HeaderText = "User";
            this.usersaliasDataGridViewTextBoxColumn1.Name = "usersaliasDataGridViewTextBoxColumn1";
            this.usersaliasDataGridViewTextBoxColumn1.ReadOnly = true;
            this.usersaliasDataGridViewTextBoxColumn1.Width = 120;
            // 
            // subviewDataTablecalendarsBindingSource
            // 
            this.subviewDataTablecalendarsBindingSource.DataMember = "subviewDataTablecalendars";
            this.subviewDataTablecalendarsBindingSource.DataSource = this.dataSet01V;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 472);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 40);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(434, 432);
            this.panel5.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 472);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(434, 40);
            this.panel4.TabIndex = 1;
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(434, 512);
            this.panel1.TabIndex = 4;
            // 
            // viewDataTablecustomersTableAdapter
            // 
            this.viewDataTablecustomersTableAdapter.ClearBeforeFill = true;
            // 
            // customersTableAdapter
            // 
            this.customersTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableanimalsTableAdapter
            // 
            this.subviewDataTableanimalsTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableinvoicesTableAdapter
            // 
            this.subviewDataTableinvoicesTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTablecalendarsTableAdapter
            // 
            this.subviewDataTablecalendarsTableAdapter.ClearBeforeFill = true;
            // 
            // FormCustomers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 512);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormCustomers";
            this.Text = "Customers";
            this.Activated += new System.EventHandler(this.FormCustomers_Activated);
            this.Deactivate += new System.EventHandler(this.FormCustomers_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormCustomers_FormClosing);
            this.Load += new System.EventHandler(this.FormCustomers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel_filter.ResumeLayout(false);
            this.panel_filter.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablecustomersBindingSource)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.tabControl_main.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableanimalsBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableinvoicesBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTablecalendarsBindingSource)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.TextBox customers_notesTextBox;
        private System.Windows.Forms.TextBox customers_faxTextBox;
        private System.Windows.Forms.TextBox customers_emailTextBox;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox_filter_customers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox customers_telTextBox;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.TextBox customers_taxcodeTextBox;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox customers_vatnumberTextBox;
        private System.Windows.Forms.TextBox customers_streetTextBox;
        private System.Windows.Forms.TextBox customers_zipcodeTextBox;
        private System.Windows.Forms.TextBox customers_cityTextBox;
        private System.Windows.Forms.TextBox customers_stateTextBox;
        private System.Windows.Forms.TextBox customers_surnameTextBox;
        private System.Windows.Forms.TextBox customers_nameTextBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.BindingSource viewDataTablecustomersBindingSource;
        private DataSet01VTableAdapters.viewDataTablecustomersTableAdapter viewDataTablecustomersTableAdapter;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private DataSet01STableAdapters.customersTableAdapter customersTableAdapter;
        private System.Windows.Forms.TabControl tabControl_main;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DateTimePicker customers_dateDateTimePicker;
        private System.Windows.Forms.TextBox customers_idTextBox;
        private System.Windows.Forms.TextBox customers_invoicestextTextBox;
        private System.Windows.Forms.Panel panel_filter;
        private System.Windows.Forms.DataGridViewTextBoxColumn customersidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerssurnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customersnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customersaliasDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource subviewDataTableanimalsBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicesdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicesnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paystatusnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usersaliasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invoicestotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource subviewDataTableinvoicesBindingSource;
        private DataSet01VTableAdapters.subviewDataTableanimalsTableAdapter subviewDataTableanimalsTableAdapter;
        private DataSet01VTableAdapters.subviewDataTableinvoicesTableAdapter subviewDataTableinvoicesTableAdapter;
        private System.Windows.Forms.BindingSource subviewDataTablecalendarsBindingSource;
        private DataSet01VTableAdapters.subviewDataTablecalendarsTableAdapter subviewDataTablecalendarsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn calendarsfromDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn calendarstoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn calendarstitleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usersaliasDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn familiesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn breedsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn animalsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button_Makeinvoicetext;
    }
}