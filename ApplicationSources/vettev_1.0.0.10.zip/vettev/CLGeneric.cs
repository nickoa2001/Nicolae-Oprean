﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vettev
{
    class CLGeneric
    {
        public static string make_random_string(int size)
        {
            Random r = new Random();
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < size; i++)
            {
                //26 letters in the alfabet, ascii + 65 for the capital letters
                builder.Append(Convert.ToChar(Convert.ToInt32(Math.Floor(26 * r.NextDouble() + 65))));
            }
            return builder.ToString();
        }
    }
}
