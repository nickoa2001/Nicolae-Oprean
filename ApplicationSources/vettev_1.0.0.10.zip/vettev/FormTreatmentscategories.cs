﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormTreatmentscategories : Form
    {
        int treatmentscategories_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormTreatmentscategories()
        {
            InitializeComponent();
        }

        private void FormTreatmentscategories_Load(object sender, EventArgs e)
        {
            this.viewDataTabletreatmentscategoriesTableAdapter.Fill(this.dataSet01V.viewDataTabletreatmentscategories);

            viewDataTabletreatmentscategoriesBindingSource.Sort = "treatmentscategories_name";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTabletreatmentscategoriesBindingSource_CurrentChanged(null, null);
        }

        private void FormTreatmentscategories_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormTreatmentscategories_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormTreatmentscategories_Load(sender, e);
        }

        private void FormTreatmentscategories_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                treatmentscategories_nameTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                treatmentscategories_nameTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            treatmentscategoriesBindingSource.AddNew();
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (treatmentscategories_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (treatmentscategories_id != -1 && treatmentscategories_id != 1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    {
                        DataSet01STableAdapters.animalstreatmentsTableAdapter t = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                        foreach (DataSet01S.animalstreatmentsRow r in t.GetDataBy3(treatmentscategories_id).Select())
                        {
                            r.treatmentscategories_id = 1;
                            t.Update(r);
                        }
                    }

                    {
                        DataSet01STableAdapters.treatmentsTableAdapter t = new DataSet01STableAdapters.treatmentsTableAdapter();
                        foreach (DataSet01S.treatmentsRow r in t.GetDataBy2(treatmentscategories_id).Select())
                        {
                            r.treatmentscategories_id = 1;
                            t.Update(r);
                        }
                    }

                    treatmentscategoriesBindingSource.RemoveCurrent();
                    treatmentscategoriesTableAdapter.Update(dataSet01S.treatmentscategories);
                    dataSet01S.treatmentscategories.AcceptChanges();

                    viewDataTabletreatmentscategoriesTableAdapter.Fill(dataSet01V.viewDataTabletreatmentscategories);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (treatmentscategories_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.treatmentscategoriesTableAdapter t = new DataSet01STableAdapters.treatmentscategoriesTableAdapter();
                if (t.GetDataBy1(treatmentscategories_nameTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1("treatmentscategories_id <> " + treatmentscategories_id).Select().Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }

            }
            
            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            treatmentscategoriesBindingSource.EndEdit();
            treatmentscategoriesTableAdapter.Update(dataSet01S.treatmentscategories);
            dataSet01S.treatmentscategories.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = treatmentscategoriesTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = treatmentscategories_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTabletreatmentscategoriesTableAdapter.Fill(dataSet01V.viewDataTabletreatmentscategories);
            viewDataTabletreatmentscategoriesBindingSource.Position = viewDataTabletreatmentscategoriesBindingSource.Find("treatmentscategories_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            treatmentscategoriesBindingSource.CancelEdit();
            dataSet01S.treatmentscategories.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTabletreatmentscategoriesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            treatmentscategories_id = -1;

            treatmentscategoriesBindingSource.Filter = "treatmentscategories_id = -1";

            try
            {
                treatmentscategories_id = (int)((DataSet01V.viewDataTabletreatmentscategoriesRow)((DataRowView)viewDataTabletreatmentscategoriesBindingSource.Current).Row).treatmentscategories_id;
            }
            catch { }

            if (treatmentscategories_id != -1)
            {
                treatmentscategoriesTableAdapter.Fill(dataSet01S.treatmentscategories, treatmentscategories_id);

                treatmentscategoriesBindingSource.RemoveFilter();
                treatmentscategoriesBindingSource.Position = treatmentscategoriesBindingSource.Find("treatmentscategories_id", treatmentscategories_id);
            }
        }
    }
}
