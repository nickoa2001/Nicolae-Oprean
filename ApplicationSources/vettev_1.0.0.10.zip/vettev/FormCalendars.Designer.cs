﻿namespace vettev
{
    partial class FormCalendars
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label customers_idLabel;
            System.Windows.Forms.Label users_idLabel;
            System.Windows.Forms.Label rooms_idLabel;
            System.Windows.Forms.Label calendars_fromLabel;
            System.Windows.Forms.Label calendars_toLabel;
            System.Windows.Forms.Label calendars_notesLabel;
            System.Windows.Forms.Label calendars_titleLabel;
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange1 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange2 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange3 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange4 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange5 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange6 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange7 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange8 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange9 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange10 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange11 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange12 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange13 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange14 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.Windows.Forms.Calendar.CalendarHighlightRange calendarHighlightRange15 = new System.Windows.Forms.Calendar.CalendarHighlightRange();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCalendars));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tabControl_main = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.calendar_day = new System.Windows.Forms.Calendar.Calendar();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.calendar_week = new System.Windows.Forms.Calendar.Calendar();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.calendar_month = new System.Windows.Forms.Calendar.Calendar();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel_filter = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox_filter_showanimalstreatments_advices = new System.Windows.Forms.CheckBox();
            this.monthCalendar_filter_day = new System.Windows.Forms.MonthCalendar();
            this.comboBox_filter_users_id = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox_filter_rooms_id = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.calendars_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.calendarsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01S = new vettev.DataSet01S();
            this.calendars_titleTextBox = new System.Windows.Forms.TextBox();
            this.customers_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTablecustomersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01V = new vettev.DataSet01V();
            this.users_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTableusersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.calendars_notesTextBox = new System.Windows.Forms.TextBox();
            this.rooms_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTableroomsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.calendars_toDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.calendars_fromDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_Undo = new System.Windows.Forms.Button();
            this.button_Save = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.calendarsTableAdapter = new vettev.DataSet01STableAdapters.calendarsTableAdapter();
            this.viewDataTablecalendarsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viewDataTablecalendarsTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTablecalendarsTableAdapter();
            this.comboviewDataTableusersTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTableusersTableAdapter();
            this.comboviewDataTableroomsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTableroomsTableAdapter();
            this.comboviewDataTablecustomersTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablecustomersTableAdapter();
            this.subviewDataTableanimalstreatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.subviewDataTableanimalstreatmentsTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableanimalstreatmentsTableAdapter();
            customers_idLabel = new System.Windows.Forms.Label();
            users_idLabel = new System.Windows.Forms.Label();
            rooms_idLabel = new System.Windows.Forms.Label();
            calendars_fromLabel = new System.Windows.Forms.Label();
            calendars_toLabel = new System.Windows.Forms.Label();
            calendars_notesLabel = new System.Windows.Forms.Label();
            calendars_titleLabel = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabControl_main.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel_filter.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.calendarsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecustomersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableusersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableroomsBindingSource)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablecalendarsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableanimalstreatmentsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // customers_idLabel
            // 
            customers_idLabel.AutoSize = true;
            customers_idLabel.Location = new System.Drawing.Point(10, 15);
            customers_idLabel.Name = "customers_idLabel";
            customers_idLabel.Size = new System.Drawing.Size(53, 13);
            customers_idLabel.TabIndex = 0;
            customers_idLabel.Text = "customer:";
            // 
            // users_idLabel
            // 
            users_idLabel.AutoSize = true;
            users_idLabel.Location = new System.Drawing.Point(12, 55);
            users_idLabel.Name = "users_idLabel";
            users_idLabel.Size = new System.Drawing.Size(30, 13);
            users_idLabel.TabIndex = 2;
            users_idLabel.Text = "user:";
            // 
            // rooms_idLabel
            // 
            rooms_idLabel.AutoSize = true;
            rooms_idLabel.Location = new System.Drawing.Point(12, 95);
            rooms_idLabel.Name = "rooms_idLabel";
            rooms_idLabel.Size = new System.Drawing.Size(33, 13);
            rooms_idLabel.TabIndex = 4;
            rooms_idLabel.Text = "room:";
            // 
            // calendars_fromLabel
            // 
            calendars_fromLabel.AutoSize = true;
            calendars_fromLabel.Location = new System.Drawing.Point(288, 12);
            calendars_fromLabel.Name = "calendars_fromLabel";
            calendars_fromLabel.Size = new System.Drawing.Size(30, 13);
            calendars_fromLabel.TabIndex = 6;
            calendars_fromLabel.Text = "from:";
            // 
            // calendars_toLabel
            // 
            calendars_toLabel.AutoSize = true;
            calendars_toLabel.Location = new System.Drawing.Point(299, 52);
            calendars_toLabel.Name = "calendars_toLabel";
            calendars_toLabel.Size = new System.Drawing.Size(19, 13);
            calendars_toLabel.TabIndex = 8;
            calendars_toLabel.Text = "to:";
            // 
            // calendars_notesLabel
            // 
            calendars_notesLabel.AutoSize = true;
            calendars_notesLabel.Location = new System.Drawing.Point(13, 174);
            calendars_notesLabel.Name = "calendars_notesLabel";
            calendars_notesLabel.Size = new System.Drawing.Size(36, 13);
            calendars_notesLabel.TabIndex = 10;
            calendars_notesLabel.Text = "notes:";
            // 
            // calendars_titleLabel
            // 
            calendars_titleLabel.AutoSize = true;
            calendars_titleLabel.Location = new System.Drawing.Point(13, 135);
            calendars_titleLabel.Name = "calendars_titleLabel";
            calendars_titleLabel.Size = new System.Drawing.Size(26, 13);
            calendars_titleLabel.TabIndex = 12;
            calendars_titleLabel.Text = "title:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(584, 662);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tabControl_main);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(584, 662);
            this.panel4.TabIndex = 1;
            // 
            // tabControl_main
            // 
            this.tabControl_main.Controls.Add(this.tabPage1);
            this.tabControl_main.Controls.Add(this.tabPage2);
            this.tabControl_main.Controls.Add(this.tabPage3);
            this.tabControl_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_main.Location = new System.Drawing.Point(0, 0);
            this.tabControl_main.Name = "tabControl_main";
            this.tabControl_main.SelectedIndex = 0;
            this.tabControl_main.Size = new System.Drawing.Size(584, 662);
            this.tabControl_main.TabIndex = 1;
            this.tabControl_main.SelectedIndexChanged += new System.EventHandler(this.tabControl_main_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.calendar_day);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(576, 636);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "day";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // calendar_day
            // 
            this.calendar_day.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calendar_day.Font = new System.Drawing.Font("Segoe UI", 9F);
            calendarHighlightRange1.DayOfWeek = System.DayOfWeek.Monday;
            calendarHighlightRange1.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange1.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange2.DayOfWeek = System.DayOfWeek.Tuesday;
            calendarHighlightRange2.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange2.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange3.DayOfWeek = System.DayOfWeek.Wednesday;
            calendarHighlightRange3.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange3.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange4.DayOfWeek = System.DayOfWeek.Thursday;
            calendarHighlightRange4.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange4.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange5.DayOfWeek = System.DayOfWeek.Friday;
            calendarHighlightRange5.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange5.StartTime = System.TimeSpan.Parse("08:00:00");
            this.calendar_day.HighlightRanges = new System.Windows.Forms.Calendar.CalendarHighlightRange[] {
        calendarHighlightRange1,
        calendarHighlightRange2,
        calendarHighlightRange3,
        calendarHighlightRange4,
        calendarHighlightRange5};
            this.calendar_day.ItemsTimeFormat = "HH:mm";
            this.calendar_day.Location = new System.Drawing.Point(3, 3);
            this.calendar_day.Name = "calendar_day";
            this.calendar_day.Size = new System.Drawing.Size(570, 630);
            this.calendar_day.TabIndex = 0;
            this.calendar_day.Text = "calendar1";
            this.calendar_day.ItemCreating += new System.Windows.Forms.Calendar.Calendar.CalendarItemCancelEventHandler(this.calendar_day_ItemCreating);
            this.calendar_day.ItemDeleting += new System.Windows.Forms.Calendar.Calendar.CalendarItemCancelEventHandler(this.calendar_day_ItemDeleting);
            this.calendar_day.ItemClick += new System.Windows.Forms.Calendar.Calendar.CalendarItemEventHandler(this.calendar_day_ItemClick);
            this.calendar_day.ItemSelected += new System.Windows.Forms.Calendar.Calendar.CalendarItemEventHandler(this.calendar_day_ItemSelected);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.calendar_week);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(576, 636);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "week";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // calendar_week
            // 
            this.calendar_week.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calendar_week.Font = new System.Drawing.Font("Segoe UI", 9F);
            calendarHighlightRange6.DayOfWeek = System.DayOfWeek.Monday;
            calendarHighlightRange6.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange6.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange7.DayOfWeek = System.DayOfWeek.Tuesday;
            calendarHighlightRange7.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange7.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange8.DayOfWeek = System.DayOfWeek.Wednesday;
            calendarHighlightRange8.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange8.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange9.DayOfWeek = System.DayOfWeek.Thursday;
            calendarHighlightRange9.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange9.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange10.DayOfWeek = System.DayOfWeek.Friday;
            calendarHighlightRange10.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange10.StartTime = System.TimeSpan.Parse("08:00:00");
            this.calendar_week.HighlightRanges = new System.Windows.Forms.Calendar.CalendarHighlightRange[] {
        calendarHighlightRange6,
        calendarHighlightRange7,
        calendarHighlightRange8,
        calendarHighlightRange9,
        calendarHighlightRange10};
            this.calendar_week.Location = new System.Drawing.Point(3, 3);
            this.calendar_week.Name = "calendar_week";
            this.calendar_week.Size = new System.Drawing.Size(570, 630);
            this.calendar_week.TabIndex = 1;
            this.calendar_week.Text = "calendar1";
            this.calendar_week.ItemCreating += new System.Windows.Forms.Calendar.Calendar.CalendarItemCancelEventHandler(this.calendar_week_ItemCreating);
            this.calendar_week.ItemClick += new System.Windows.Forms.Calendar.Calendar.CalendarItemEventHandler(this.calendar_week_ItemClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.calendar_month);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(576, 636);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "month";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // calendar_month
            // 
            this.calendar_month.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calendar_month.Font = new System.Drawing.Font("Segoe UI", 9F);
            calendarHighlightRange11.DayOfWeek = System.DayOfWeek.Monday;
            calendarHighlightRange11.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange11.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange12.DayOfWeek = System.DayOfWeek.Tuesday;
            calendarHighlightRange12.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange12.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange13.DayOfWeek = System.DayOfWeek.Wednesday;
            calendarHighlightRange13.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange13.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange14.DayOfWeek = System.DayOfWeek.Thursday;
            calendarHighlightRange14.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange14.StartTime = System.TimeSpan.Parse("08:00:00");
            calendarHighlightRange15.DayOfWeek = System.DayOfWeek.Friday;
            calendarHighlightRange15.EndTime = System.TimeSpan.Parse("17:00:00");
            calendarHighlightRange15.StartTime = System.TimeSpan.Parse("08:00:00");
            this.calendar_month.HighlightRanges = new System.Windows.Forms.Calendar.CalendarHighlightRange[] {
        calendarHighlightRange11,
        calendarHighlightRange12,
        calendarHighlightRange13,
        calendarHighlightRange14,
        calendarHighlightRange15};
            this.calendar_month.Location = new System.Drawing.Point(3, 3);
            this.calendar_month.Name = "calendar_month";
            this.calendar_month.Size = new System.Drawing.Size(570, 630);
            this.calendar_month.TabIndex = 2;
            this.calendar_month.Text = "calendar1";
            this.calendar_month.ItemCreating += new System.Windows.Forms.Calendar.Calendar.CalendarItemCancelEventHandler(this.calendar_month_ItemCreating);
            this.calendar_month.ItemClick += new System.Windows.Forms.Calendar.Calendar.CalendarItemEventHandler(this.calendar_month_ItemClick);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel_filter);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 185);
            this.panel3.TabIndex = 0;
            // 
            // panel_filter
            // 
            this.panel_filter.Controls.Add(this.label1);
            this.panel_filter.Controls.Add(this.checkBox_filter_showanimalstreatments_advices);
            this.panel_filter.Controls.Add(this.monthCalendar_filter_day);
            this.panel_filter.Controls.Add(this.comboBox_filter_users_id);
            this.panel_filter.Controls.Add(this.label2);
            this.panel_filter.Controls.Add(this.comboBox_filter_rooms_id);
            this.panel_filter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filter.Location = new System.Drawing.Point(0, 0);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new System.Drawing.Size(400, 185);
            this.panel_filter.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(249, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "user";
            // 
            // checkBox_filter_showanimalstreatments_advices
            // 
            this.checkBox_filter_showanimalstreatments_advices.AutoSize = true;
            this.checkBox_filter_showanimalstreatments_advices.Location = new System.Drawing.Point(249, 15);
            this.checkBox_filter_showanimalstreatments_advices.Name = "checkBox_filter_showanimalstreatments_advices";
            this.checkBox_filter_showanimalstreatments_advices.Size = new System.Drawing.Size(143, 17);
            this.checkBox_filter_showanimalstreatments_advices.TabIndex = 8;
            this.checkBox_filter_showanimalstreatments_advices.Text = "show treatments advices";
            this.checkBox_filter_showanimalstreatments_advices.UseVisualStyleBackColor = true;
            this.checkBox_filter_showanimalstreatments_advices.CheckedChanged += new System.EventHandler(this.checkBox_filter_showanimalstreatments_advices_CheckedChanged);
            // 
            // monthCalendar_filter_day
            // 
            this.monthCalendar_filter_day.Location = new System.Drawing.Point(10, 15);
            this.monthCalendar_filter_day.Name = "monthCalendar_filter_day";
            this.monthCalendar_filter_day.TabIndex = 0;
            this.monthCalendar_filter_day.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar_filter_DateChanged);
            // 
            // comboBox_filter_users_id
            // 
            this.comboBox_filter_users_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_filter_users_id.FormattingEnabled = true;
            this.comboBox_filter_users_id.Location = new System.Drawing.Point(252, 51);
            this.comboBox_filter_users_id.Name = "comboBox_filter_users_id";
            this.comboBox_filter_users_id.Size = new System.Drawing.Size(136, 21);
            this.comboBox_filter_users_id.TabIndex = 1;
            this.comboBox_filter_users_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_users_id_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(252, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "room";
            // 
            // comboBox_filter_rooms_id
            // 
            this.comboBox_filter_rooms_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_filter_rooms_id.FormattingEnabled = true;
            this.comboBox_filter_rooms_id.Location = new System.Drawing.Point(252, 91);
            this.comboBox_filter_rooms_id.Name = "comboBox_filter_rooms_id";
            this.comboBox_filter_rooms_id.Size = new System.Drawing.Size(136, 21);
            this.comboBox_filter_rooms_id.TabIndex = 4;
            this.comboBox_filter_rooms_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_rooms_id_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(584, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 662);
            this.panel2.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.calendars_dateDateTimePicker);
            this.panel7.Controls.Add(calendars_titleLabel);
            this.panel7.Controls.Add(customers_idLabel);
            this.panel7.Controls.Add(this.calendars_titleTextBox);
            this.panel7.Controls.Add(this.customers_idComboBox);
            this.panel7.Controls.Add(calendars_notesLabel);
            this.panel7.Controls.Add(this.users_idComboBox);
            this.panel7.Controls.Add(this.calendars_notesTextBox);
            this.panel7.Controls.Add(users_idLabel);
            this.panel7.Controls.Add(calendars_toLabel);
            this.panel7.Controls.Add(this.rooms_idComboBox);
            this.panel7.Controls.Add(this.calendars_toDateTimePicker);
            this.panel7.Controls.Add(rooms_idLabel);
            this.panel7.Controls.Add(calendars_fromLabel);
            this.panel7.Controls.Add(this.calendars_fromDateTimePicker);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 185);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(400, 415);
            this.panel7.TabIndex = 2;
            // 
            // calendars_dateDateTimePicker
            // 
            this.calendars_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.calendarsBindingSource, "calendars_from", true));
            this.calendars_dateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.calendars_dateDateTimePicker.Location = new System.Drawing.Point(218, 29);
            this.calendars_dateDateTimePicker.Name = "calendars_dateDateTimePicker";
            this.calendars_dateDateTimePicker.Size = new System.Drawing.Size(100, 20);
            this.calendars_dateDateTimePicker.TabIndex = 14;
            this.calendars_dateDateTimePicker.ValueChanged += new System.EventHandler(this.calendars_dateDateTimePicker_ValueChanged);
            // 
            // calendarsBindingSource
            // 
            this.calendarsBindingSource.DataMember = "calendars";
            this.calendarsBindingSource.DataSource = this.dataSet01S;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // calendars_titleTextBox
            // 
            this.calendars_titleTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.calendarsBindingSource, "calendars_title", true));
            this.calendars_titleTextBox.Location = new System.Drawing.Point(16, 151);
            this.calendars_titleTextBox.MaxLength = 100;
            this.calendars_titleTextBox.Name = "calendars_titleTextBox";
            this.calendars_titleTextBox.Size = new System.Drawing.Size(372, 20);
            this.calendars_titleTextBox.TabIndex = 13;
            // 
            // customers_idComboBox
            // 
            this.customers_idComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.customers_idComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.customers_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.calendarsBindingSource, "customers_id", true));
            this.customers_idComboBox.DataSource = this.comboviewDataTablecustomersBindingSource;
            this.customers_idComboBox.DisplayMember = "customers_alias";
            this.customers_idComboBox.FormattingEnabled = true;
            this.customers_idComboBox.Location = new System.Drawing.Point(13, 31);
            this.customers_idComboBox.Name = "customers_idComboBox";
            this.customers_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.customers_idComboBox.TabIndex = 1;
            this.customers_idComboBox.ValueMember = "customers_id";
            // 
            // comboviewDataTablecustomersBindingSource
            // 
            this.comboviewDataTablecustomersBindingSource.DataMember = "comboviewDataTablecustomers";
            this.comboviewDataTablecustomersBindingSource.DataSource = this.dataSet01V;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // users_idComboBox
            // 
            this.users_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.calendarsBindingSource, "users_id", true));
            this.users_idComboBox.DataSource = this.comboviewDataTableusersBindingSource;
            this.users_idComboBox.DisplayMember = "users_alias";
            this.users_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.users_idComboBox.FormattingEnabled = true;
            this.users_idComboBox.Location = new System.Drawing.Point(13, 71);
            this.users_idComboBox.Name = "users_idComboBox";
            this.users_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.users_idComboBox.TabIndex = 3;
            this.users_idComboBox.ValueMember = "users_id";
            // 
            // comboviewDataTableusersBindingSource
            // 
            this.comboviewDataTableusersBindingSource.DataMember = "comboviewDataTableusers";
            this.comboviewDataTableusersBindingSource.DataSource = this.dataSet01V;
            // 
            // calendars_notesTextBox
            // 
            this.calendars_notesTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.calendarsBindingSource, "calendars_notes", true));
            this.calendars_notesTextBox.Location = new System.Drawing.Point(16, 190);
            this.calendars_notesTextBox.Multiline = true;
            this.calendars_notesTextBox.Name = "calendars_notesTextBox";
            this.calendars_notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.calendars_notesTextBox.Size = new System.Drawing.Size(372, 70);
            this.calendars_notesTextBox.TabIndex = 11;
            // 
            // rooms_idComboBox
            // 
            this.rooms_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.calendarsBindingSource, "rooms_id", true));
            this.rooms_idComboBox.DataSource = this.comboviewDataTableroomsBindingSource;
            this.rooms_idComboBox.DisplayMember = "rooms_name";
            this.rooms_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.rooms_idComboBox.FormattingEnabled = true;
            this.rooms_idComboBox.Location = new System.Drawing.Point(13, 111);
            this.rooms_idComboBox.Name = "rooms_idComboBox";
            this.rooms_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.rooms_idComboBox.TabIndex = 5;
            this.rooms_idComboBox.ValueMember = "rooms_id";
            // 
            // comboviewDataTableroomsBindingSource
            // 
            this.comboviewDataTableroomsBindingSource.DataMember = "comboviewDataTablerooms";
            this.comboviewDataTableroomsBindingSource.DataSource = this.dataSet01V;
            // 
            // calendars_toDateTimePicker
            // 
            this.calendars_toDateTimePicker.CustomFormat = "HH:mm";
            this.calendars_toDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.calendarsBindingSource, "calendars_to", true));
            this.calendars_toDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.calendars_toDateTimePicker.Location = new System.Drawing.Point(324, 52);
            this.calendars_toDateTimePicker.Name = "calendars_toDateTimePicker";
            this.calendars_toDateTimePicker.ShowUpDown = true;
            this.calendars_toDateTimePicker.Size = new System.Drawing.Size(64, 20);
            this.calendars_toDateTimePicker.TabIndex = 9;
            // 
            // calendars_fromDateTimePicker
            // 
            this.calendars_fromDateTimePicker.CustomFormat = "HH:mm";
            this.calendars_fromDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.calendarsBindingSource, "calendars_from", true));
            this.calendars_fromDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.calendars_fromDateTimePicker.Location = new System.Drawing.Point(324, 28);
            this.calendars_fromDateTimePicker.Name = "calendars_fromDateTimePicker";
            this.calendars_fromDateTimePicker.ShowUpDown = true;
            this.calendars_fromDateTimePicker.Size = new System.Drawing.Size(64, 20);
            this.calendars_fromDateTimePicker.TabIndex = 7;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button_Edit);
            this.panel6.Controls.Add(this.button_Undo);
            this.panel6.Controls.Add(this.button_Save);
            this.panel6.Controls.Add(this.button_Delete);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 600);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 62);
            this.panel6.TabIndex = 1;
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(10, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 3;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(91, 33);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 2;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(10, 33);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 1;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(91, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 0;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // calendarsTableAdapter
            // 
            this.calendarsTableAdapter.ClearBeforeFill = true;
            // 
            // viewDataTablecalendarsBindingSource
            // 
            this.viewDataTablecalendarsBindingSource.DataMember = "viewDataTablecalendars";
            this.viewDataTablecalendarsBindingSource.DataSource = this.dataSet01V;
            // 
            // viewDataTablecalendarsTableAdapter
            // 
            this.viewDataTablecalendarsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTableusersTableAdapter
            // 
            this.comboviewDataTableusersTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTableroomsTableAdapter
            // 
            this.comboviewDataTableroomsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablecustomersTableAdapter
            // 
            this.comboviewDataTablecustomersTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableanimalstreatmentsBindingSource
            // 
            this.subviewDataTableanimalstreatmentsBindingSource.DataMember = "subviewDataTableanimalstreatments";
            this.subviewDataTableanimalstreatmentsBindingSource.DataSource = this.dataSet01V;
            // 
            // subviewDataTableanimalstreatmentsTableAdapter
            // 
            this.subviewDataTableanimalstreatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // FormCalendars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormCalendars";
            this.Text = "Calendar";
            this.Activated += new System.EventHandler(this.FormCalendars_Activated);
            this.Deactivate += new System.EventHandler(this.FormCalendars_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormCalendar_FormClosing);
            this.Load += new System.EventHandler(this.FormCalendar_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.tabControl_main.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel_filter.ResumeLayout(false);
            this.panel_filter.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.calendarsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecustomersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableusersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableroomsBindingSource)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTablecalendarsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableanimalstreatmentsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.MonthCalendar monthCalendar_filter_day;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_filter_users_id;
        private System.Windows.Forms.ComboBox comboBox_filter_rooms_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private DataSet01S dataSet01S;
		private DataSet01V dataSet01V;
        private System.Windows.Forms.BindingSource calendarsBindingSource;
        private DataSet01STableAdapters.calendarsTableAdapter calendarsTableAdapter;
        private System.Windows.Forms.TextBox calendars_titleTextBox;
        private System.Windows.Forms.TextBox calendars_notesTextBox;
        private System.Windows.Forms.DateTimePicker calendars_toDateTimePicker;
        private System.Windows.Forms.DateTimePicker calendars_fromDateTimePicker;
        private System.Windows.Forms.ComboBox rooms_idComboBox;
        private System.Windows.Forms.ComboBox users_idComboBox;
        private System.Windows.Forms.ComboBox customers_idComboBox;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.TabControl tabControl_main;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DateTimePicker calendars_dateDateTimePicker;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.BindingSource viewDataTablecalendarsBindingSource;
        private System.Windows.Forms.BindingSource comboviewDataTableusersBindingSource;
        private DataSet01VTableAdapters.comboviewDataTableusersTableAdapter comboviewDataTableusersTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTableroomsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTableroomsTableAdapter comboviewDataTableroomsTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTablecustomersBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablecustomersTableAdapter comboviewDataTablecustomersTableAdapter;
        private DataSet01VTableAdapters.viewDataTablecalendarsTableAdapter viewDataTablecalendarsTableAdapter;
        private System.Windows.Forms.CheckBox checkBox_filter_showanimalstreatments_advices;
        private System.Windows.Forms.BindingSource subviewDataTableanimalstreatmentsBindingSource;
        private DataSet01VTableAdapters.subviewDataTableanimalstreatmentsTableAdapter subviewDataTableanimalstreatmentsTableAdapter;
        private System.Windows.Forms.Panel panel_filter;
        private System.Windows.Forms.Calendar.Calendar calendar_day;
        private System.Windows.Forms.Calendar.Calendar calendar_week;
        private System.Windows.Forms.Calendar.Calendar calendar_month;
        private System.Windows.Forms.Button button_Edit;
    }
}