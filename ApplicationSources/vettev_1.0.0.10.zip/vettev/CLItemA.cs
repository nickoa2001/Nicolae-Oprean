﻿//VERSION 1.0.0.0

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vettev
{
    class CLItemA
    {
        public string id;
        public string name;

        public CLItemA(string _id, string _name)
        {
            this.id = _id;
            this.name = _name;
        }

        public override string ToString()
        {
            if (name.Length > 70)
                return name.Substring(0, 70) + "...";
            else
                return name;
        }

    }
}
