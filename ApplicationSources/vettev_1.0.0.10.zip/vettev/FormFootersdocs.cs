﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormFootersdocs : Form
    {
        int footersdocs_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormFootersdocs()
        {
            InitializeComponent();
        }

        private void FormFootersdocs_Load(object sender, EventArgs e)
        {
            this.viewDataTablefootersdocsTableAdapter.Fill(this.dataSet01V.viewDataTablefootersdocs);

            viewDataTablefootersdocsBindingSource.Sort = "footersdocs_desc";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTablefootersdocsBindingSource_CurrentChanged(null, null);
        }

        private void FormFootersdocs_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormFootersdocs_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormFootersdocs_Load(sender, e);
        }

        private void FormFootersdocs_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                footersdocs_descTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                footersdocs_descTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            footersdocsBindingSource.AddNew();
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (footersdocs_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (footersdocs_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    footersdocsBindingSource.RemoveCurrent();
                    footersdocsTableAdapter.Update(dataSet01S.footersdocs);
                    dataSet01S.footersdocs.AcceptChanges();

                    viewDataTablefootersdocsTableAdapter.Fill(dataSet01V.viewDataTablefootersdocs);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (footersdocs_descTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid description" + Environment.NewLine;
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            footersdocsBindingSource.EndEdit();
            footersdocsTableAdapter.Update(dataSet01S.footersdocs);
            dataSet01S.footersdocs.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = footersdocsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = footersdocs_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTablefootersdocsTableAdapter.Fill(dataSet01V.viewDataTablefootersdocs);
            viewDataTablefootersdocsBindingSource.Position = viewDataTablefootersdocsBindingSource.Find("footersdocs_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            footersdocsBindingSource.CancelEdit();
            dataSet01S.footersdocs.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTablefootersdocsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            footersdocs_id = -1;

            footersdocsBindingSource.Filter = "footersdocs_id = -1";

            try
            {
                footersdocs_id = (int)((DataSet01V.viewDataTablefootersdocsRow)((DataRowView)viewDataTablefootersdocsBindingSource.Current).Row).footersdocs_id;
            }
            catch { }

            if (footersdocs_id != -1)
            {
                footersdocsTableAdapter.Fill(dataSet01S.footersdocs, footersdocs_id);

                footersdocsBindingSource.RemoveFilter();
                footersdocsBindingSource.Position = footersdocsBindingSource.Find("footersdocs_id", footersdocs_id);
            }
        }
    }
}
