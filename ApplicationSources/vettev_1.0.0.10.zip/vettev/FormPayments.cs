﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormPayments : Form
    {
        int payments_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormPayments()
        {
            InitializeComponent();
        }

        private void FormPayments_Load(object sender, EventArgs e)
        {
            this.viewDataTablepaymentsTableAdapter.Fill(this.dataSet01V.viewDataTablepayments);

            viewDataTablepaymentsBindingSource.Sort = "payments_name";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTablepaymentsBindingSource_CurrentChanged(null, null);
        }

        private void FormPayments_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormPayments_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormPayments_Load(sender, e);
        }

        private void FormPayments_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                payments_nameTextBox.ReadOnly = false;
                payments_descTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                payments_nameTextBox.ReadOnly = true;
                payments_descTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            paymentsBindingSource.AddNew();
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (payments_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (payments_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    paymentsBindingSource.RemoveCurrent();
                    paymentsTableAdapter.Update(dataSet01S.payments);
                    dataSet01S.payments.AcceptChanges();

                    viewDataTablepaymentsTableAdapter.Fill(dataSet01V.viewDataTablepayments);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (payments_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.paymentsTableAdapter t = new DataSet01STableAdapters.paymentsTableAdapter();
                if (t.GetDataBy1(payments_nameTextBox.Text).Select().Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy1(payments_nameTextBox.Text).Select("payments_id <> " + payments_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            paymentsBindingSource.EndEdit();
            paymentsTableAdapter.Update(dataSet01S.payments);
            dataSet01S.payments.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = paymentsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = payments_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTablepaymentsTableAdapter.Fill(dataSet01V.viewDataTablepayments);
            viewDataTablepaymentsBindingSource.Position = viewDataTablepaymentsBindingSource.Find("payments_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            paymentsBindingSource.CancelEdit();
            dataSet01S.payments.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTablepaymentsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            payments_id = -1;

            paymentsBindingSource.Filter = "payments_id = -1";

            try
            {
                payments_id = (int)((DataSet01V.viewDataTablepaymentsRow)((DataRowView)viewDataTablepaymentsBindingSource.Current).Row).payments_id;
            }
            catch { }

            if (payments_id != -1)
            {
                paymentsTableAdapter.Fill(dataSet01S.payments, payments_id);

                paymentsBindingSource.RemoveFilter();
                paymentsBindingSource.Position = paymentsBindingSource.Find("payments_id", payments_id);
            }
        }
    }
}
