﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;

namespace vettev
{
    public partial class FormBackup : Form
    {
        private delegate void DelegateGetExitvalue(int exitvalue);
        private DelegateGetExitvalue delegateGetExitvalue;
        private string command;
        private Thread workerThread = null;
        private bool workerThreadabort = false;

        public FormBackup()
        {
            InitializeComponent();

            delegateGetExitvalue = new DelegateGetExitvalue(this.GetExitvalue);
        }

        private void FormBackup_Load(object sender, EventArgs e)
        {
            workerThreadabort = false;

            run_backup();
        }

        private void FormBackup_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void run_backup()
        {
            textBox_info.Text = "Backup is running, please wait." + Environment.NewLine;
            textBox_info.Text += "This window will automatically close when done.";

            command = CLOptions.ReadValue("backupscript");
            workerThread = new Thread(new ThreadStart(this.DoWork));
            workerThread.Start();
        }

        private void button_Close_Click(object sender, EventArgs e)
        {
            workerThreadabort = true;
            Close();
        }

        private void GetExitvalue(int exitvalue)
        {
            Close();
        }

        private void DoWork()
        {
            if (command.CompareTo(string.Empty) != 0)
            {
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.CreateNoWindow = true;
                startInfo.UseShellExecute = false;
                startInfo.FileName = command;
                startInfo.WindowStyle = ProcessWindowStyle.Hidden;

                try
                {
                    Process exeProcess = Process.Start(startInfo);
                    exeProcess.WaitForExit();
                    if (workerThreadabort)
                        return;
                    Invoke(delegateGetExitvalue, new Object[] { exeProcess.ExitCode });
                    return;
                }
                catch
                {
                    if (workerThreadabort)
                        return;
                    Invoke(delegateGetExitvalue, new Object[] { -9 });
                    return;
                }
            }

            if (workerThreadabort)
                return;
            Invoke(delegateGetExitvalue, new Object[] { -9 });
        }
    }
}
