﻿namespace vettev
{
    partial class FormEstimates
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label customers_idLabel;
            System.Windows.Forms.Label users_idLabel2;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEstimates));
            this.estimates_numberLabel = new System.Windows.Forms.Label();
            this.estimates_dateLabel = new System.Windows.Forms.Label();
            this.estimates_paymentstextLabel = new System.Windows.Forms.Label();
            this.estimates_customerstextLabel = new System.Windows.Forms.Label();
            this.estimates_totalLabel = new System.Windows.Forms.Label();
            this.estimates_userstextLabel = new System.Windows.Forms.Label();
            this.estimatesitems_taxLabel = new System.Windows.Forms.Label();
            this.estimatesitems_descLabel = new System.Windows.Forms.Label();
            this.estimatesitems_codeLabel = new System.Windows.Forms.Label();
            this.estimatesitems_priceLabel = new System.Windows.Forms.Label();
            this.estimatesitems_idLabel = new System.Windows.Forms.Label();
            this.estimates_footerstextLabel = new System.Windows.Forms.Label();
            this.estimates_deductiontaxLabel = new System.Windows.Forms.Label();
            this.tabControl_main = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox_taxesdeduction = new System.Windows.Forms.ComboBox();
            this.estimates_deductiontaxTextBox = new System.Windows.Forms.TextBox();
            this.estimatesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01S = new vettev.DataSet01S();
            this.comboBox_fillfromfootersdocs = new System.Windows.Forms.ComboBox();
            this.button_fillfromfootersdocs = new System.Windows.Forms.Button();
            this.estimates_footerstextTextBox = new System.Windows.Forms.TextBox();
            this.button_fillfromusers = new System.Windows.Forms.Button();
            this.estimates_userstextTextBox = new System.Windows.Forms.TextBox();
            this.users_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTableusersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet01V = new vettev.DataSet01V();
            this.button_fillfromcustomers = new System.Windows.Forms.Button();
            this.customers_idComboBox = new System.Windows.Forms.ComboBox();
            this.comboviewDataTablecustomersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_fillfrompayments = new System.Windows.Forms.Button();
            this.comboBox_fillfrompayments = new System.Windows.Forms.ComboBox();
            this.estimates_totalTextBox = new System.Windows.Forms.TextBox();
            this.estimates_customerstextTextBox = new System.Windows.Forms.TextBox();
            this.estimates_paymentstextTextBox = new System.Windows.Forms.TextBox();
            this.estimates_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.estimates_numberTextBox = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel14 = new System.Windows.Forms.Panel();
            this.dataGridView_estimatesitemsmain = new System.Windows.Forms.DataGridView();
            this.estimatesitemsidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estimatesitemscodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estimatesitemsdescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estimatesitemspriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subviewDataTableestimatesitemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.panel13 = new System.Windows.Forms.Panel();
            this.button_estimatesitemsAddcomputedrowsdocs = new System.Windows.Forms.Button();
            this.comboBox_estimatesitemscomputedrowsdocs = new System.Windows.Forms.ComboBox();
            this.estimatesitems_idTextBox = new System.Windows.Forms.TextBox();
            this.estimatesitemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_estimatesitemstotalnotax = new System.Windows.Forms.TextBox();
            this.textBox_estimatesitemstotal = new System.Windows.Forms.TextBox();
            this.comboBox_estimatesitemstaxes = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_estimatesitemstotaltax = new System.Windows.Forms.TextBox();
            this.estimatesitems_priceTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.estimatesitems_codeTextBox = new System.Windows.Forms.TextBox();
            this.textBox_estimatesitemstotaldeductiontax = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.estimatesitems_descTextBox = new System.Windows.Forms.TextBox();
            this.button_estimatesitemsDelete = new System.Windows.Forms.Button();
            this.button_estimatesitemsEdit = new System.Windows.Forms.Button();
            this.estimatesitems_taxTextBox = new System.Windows.Forms.TextBox();
            this.button_estimatesitemsNew = new System.Windows.Forms.Button();
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments = new System.Windows.Forms.GroupBox();
            this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id = new System.Windows.Forms.ComboBox();
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name = new System.Windows.Forms.TextBox();
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code = new System.Windows.Forms.TextBox();
            this.dataGridView_estimatesitemsfillfromtreatmentsmain = new System.Windows.Forms.DataGridView();
            this.comboviewDataTabletreatmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_estimatesitemsfillfromtreatments = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Edit = new System.Windows.Forms.Button();
            this.button_New = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox_total = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button_Print = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox_filter_year = new System.Windows.Forms.ComboBox();
            this.button_Undo = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel_filter = new System.Windows.Forms.Panel();
            this.textBox_filter_customers = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_filter_users_id = new System.Windows.Forms.ComboBox();
            this.textBox_filter_number = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView_main = new System.Windows.Forms.DataGridView();
            this.estimatesnumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estimatesdateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customersaliasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estimatestotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewDataTableestimatesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_Save = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button_Stopedit = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.viewDataTableestimatesTableAdapter = new vettev.DataSet01VTableAdapters.viewDataTableestimatesTableAdapter();
            this.comboviewDataTablecustomersTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablecustomersTableAdapter();
            this.comboviewDataTablepaymentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTablepaymentsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablepaymentsTableAdapter();
            this.estimatesitemsTableAdapter = new vettev.DataSet01STableAdapters.estimatesitemsTableAdapter();
            this.comboviewDataTableusersTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTableusersTableAdapter();
            this.comboviewDataTabletaxesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTabletaxesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletaxesTableAdapter();
            this.subviewDataTableestimatesitemsTableAdapter = new vettev.DataSet01VTableAdapters.subviewDataTableestimatesitemsTableAdapter();
            this.comboviewDataTabletreatmentscategoriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTabletreatmentscategoriesTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletreatmentscategoriesTableAdapter();
            this.comboviewDataTablefootersdocsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTablefootersdocsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablefootersdocsTableAdapter();
            this.comboviewDataTabletaxesdeductionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTabletaxesdeductionTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletaxesdeductionTableAdapter();
            this.comboviewDataTablecomputedrowsdocsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboviewDataTablecomputedrowsdocsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTablecomputedrowsdocsTableAdapter();
            this.estimatesTableAdapter = new vettev.DataSet01STableAdapters.estimatesTableAdapter();
            this.treatmentsdescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentscategoriesnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.treatmentscodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comboviewDataTabletreatmentsTableAdapter = new vettev.DataSet01VTableAdapters.comboviewDataTabletreatmentsTableAdapter();
            customers_idLabel = new System.Windows.Forms.Label();
            users_idLabel2 = new System.Windows.Forms.Label();
            this.tabControl_main.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.estimatesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableusersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecustomersBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_estimatesitemsmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableestimatesitemsBindingSource)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.estimatesitemsBindingSource)).BeginInit();
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_estimatesitemsfillfromtreatmentsmain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentsBindingSource)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel_filter.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableestimatesBindingSource)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablepaymentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentscategoriesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablefootersdocsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesdeductionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecomputedrowsdocsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // customers_idLabel
            // 
            customers_idLabel.AutoSize = true;
            customers_idLabel.Location = new System.Drawing.Point(9, 160);
            customers_idLabel.Name = "customers_idLabel";
            customers_idLabel.Size = new System.Drawing.Size(53, 13);
            customers_idLabel.TabIndex = 14;
            customers_idLabel.Text = "customer:";
            // 
            // users_idLabel2
            // 
            users_idLabel2.AutoSize = true;
            users_idLabel2.Location = new System.Drawing.Point(10, 51);
            users_idLabel2.Name = "users_idLabel2";
            users_idLabel2.Size = new System.Drawing.Size(30, 13);
            users_idLabel2.TabIndex = 17;
            users_idLabel2.Text = "user:";
            // 
            // estimates_numberLabel
            // 
            this.estimates_numberLabel.AutoSize = true;
            this.estimates_numberLabel.Location = new System.Drawing.Point(10, 12);
            this.estimates_numberLabel.Name = "estimates_numberLabel";
            this.estimates_numberLabel.Size = new System.Drawing.Size(45, 13);
            this.estimates_numberLabel.TabIndex = 0;
            this.estimates_numberLabel.Text = "number:";
            // 
            // estimates_dateLabel
            // 
            this.estimates_dateLabel.AutoSize = true;
            this.estimates_dateLabel.Location = new System.Drawing.Point(127, 12);
            this.estimates_dateLabel.Name = "estimates_dateLabel";
            this.estimates_dateLabel.Size = new System.Drawing.Size(31, 13);
            this.estimates_dateLabel.TabIndex = 2;
            this.estimates_dateLabel.Text = "date:";
            // 
            // estimates_paymentstextLabel
            // 
            this.estimates_paymentstextLabel.AutoSize = true;
            this.estimates_paymentstextLabel.Location = new System.Drawing.Point(10, 269);
            this.estimates_paymentstextLabel.Name = "estimates_paymentstextLabel";
            this.estimates_paymentstextLabel.Size = new System.Drawing.Size(104, 13);
            this.estimates_paymentstextLabel.TabIndex = 4;
            this.estimates_paymentstextLabel.Text = "payment description:";
            // 
            // estimates_customerstextLabel
            // 
            this.estimates_customerstextLabel.AutoSize = true;
            this.estimates_customerstextLabel.Location = new System.Drawing.Point(10, 200);
            this.estimates_customerstextLabel.Name = "estimates_customerstextLabel";
            this.estimates_customerstextLabel.Size = new System.Drawing.Size(107, 13);
            this.estimates_customerstextLabel.TabIndex = 6;
            this.estimates_customerstextLabel.Text = "customer description:";
            // 
            // estimates_totalLabel
            // 
            this.estimates_totalLabel.AutoSize = true;
            this.estimates_totalLabel.Location = new System.Drawing.Point(514, 12);
            this.estimates_totalLabel.Name = "estimates_totalLabel";
            this.estimates_totalLabel.Size = new System.Drawing.Size(30, 13);
            this.estimates_totalLabel.TabIndex = 10;
            this.estimates_totalLabel.Text = "total:";
            // 
            // estimates_userstextLabel
            // 
            this.estimates_userstextLabel.AutoSize = true;
            this.estimates_userstextLabel.Location = new System.Drawing.Point(9, 91);
            this.estimates_userstextLabel.Name = "estimates_userstextLabel";
            this.estimates_userstextLabel.Size = new System.Drawing.Size(84, 13);
            this.estimates_userstextLabel.TabIndex = 19;
            this.estimates_userstextLabel.Text = "user description:";
            // 
            // estimatesitems_taxLabel
            // 
            this.estimatesitems_taxLabel.AutoSize = true;
            this.estimatesitems_taxLabel.Location = new System.Drawing.Point(122, 198);
            this.estimatesitems_taxLabel.Name = "estimatesitems_taxLabel";
            this.estimatesitems_taxLabel.Size = new System.Drawing.Size(24, 13);
            this.estimatesitems_taxLabel.TabIndex = 20;
            this.estimatesitems_taxLabel.Text = "tax:";
            // 
            // estimatesitems_descLabel
            // 
            this.estimatesitems_descLabel.AutoSize = true;
            this.estimatesitems_descLabel.Location = new System.Drawing.Point(11, 129);
            this.estimatesitems_descLabel.Name = "estimatesitems_descLabel";
            this.estimatesitems_descLabel.Size = new System.Drawing.Size(61, 13);
            this.estimatesitems_descLabel.TabIndex = 22;
            this.estimatesitems_descLabel.Text = "description:";
            // 
            // estimatesitems_codeLabel
            // 
            this.estimatesitems_codeLabel.AutoSize = true;
            this.estimatesitems_codeLabel.Location = new System.Drawing.Point(10, 91);
            this.estimatesitems_codeLabel.Name = "estimatesitems_codeLabel";
            this.estimatesitems_codeLabel.Size = new System.Drawing.Size(34, 13);
            this.estimatesitems_codeLabel.TabIndex = 23;
            this.estimatesitems_codeLabel.Text = "code:";
            // 
            // estimatesitems_priceLabel
            // 
            this.estimatesitems_priceLabel.AutoSize = true;
            this.estimatesitems_priceLabel.Location = new System.Drawing.Point(11, 198);
            this.estimatesitems_priceLabel.Name = "estimatesitems_priceLabel";
            this.estimatesitems_priceLabel.Size = new System.Drawing.Size(33, 13);
            this.estimatesitems_priceLabel.TabIndex = 24;
            this.estimatesitems_priceLabel.Text = "price:";
            // 
            // estimatesitems_idLabel
            // 
            this.estimatesitems_idLabel.AutoSize = true;
            this.estimatesitems_idLabel.Location = new System.Drawing.Point(10, 45);
            this.estimatesitems_idLabel.Name = "estimatesitems_idLabel";
            this.estimatesitems_idLabel.Size = new System.Drawing.Size(18, 13);
            this.estimatesitems_idLabel.TabIndex = 31;
            this.estimatesitems_idLabel.Text = "id:";
            // 
            // estimates_footerstextLabel
            // 
            this.estimates_footerstextLabel.AutoSize = true;
            this.estimates_footerstextLabel.Location = new System.Drawing.Point(10, 365);
            this.estimates_footerstextLabel.Name = "estimates_footerstextLabel";
            this.estimates_footerstextLabel.Size = new System.Drawing.Size(62, 13);
            this.estimates_footerstextLabel.TabIndex = 22;
            this.estimates_footerstextLabel.Text = "footers text:";
            // 
            // estimates_deductiontaxLabel
            // 
            this.estimates_deductiontaxLabel.AutoSize = true;
            this.estimates_deductiontaxLabel.Location = new System.Drawing.Point(9, 461);
            this.estimates_deductiontaxLabel.Name = "estimates_deductiontaxLabel";
            this.estimates_deductiontaxLabel.Size = new System.Drawing.Size(74, 13);
            this.estimates_deductiontaxLabel.TabIndex = 26;
            this.estimates_deductiontaxLabel.Text = "deduction tax:";
            // 
            // tabControl_main
            // 
            this.tabControl_main.Controls.Add(this.tabPage1);
            this.tabControl_main.Controls.Add(this.tabPage2);
            this.tabControl_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl_main.Location = new System.Drawing.Point(0, 0);
            this.tabControl_main.Name = "tabControl_main";
            this.tabControl_main.SelectedIndex = 0;
            this.tabControl_main.Size = new System.Drawing.Size(600, 622);
            this.tabControl_main.TabIndex = 0;
            this.tabControl_main.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl_main_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.comboBox_taxesdeduction);
            this.tabPage1.Controls.Add(this.estimates_deductiontaxLabel);
            this.tabPage1.Controls.Add(this.estimates_deductiontaxTextBox);
            this.tabPage1.Controls.Add(this.comboBox_fillfromfootersdocs);
            this.tabPage1.Controls.Add(this.button_fillfromfootersdocs);
            this.tabPage1.Controls.Add(this.estimates_footerstextLabel);
            this.tabPage1.Controls.Add(this.estimates_footerstextTextBox);
            this.tabPage1.Controls.Add(this.button_fillfromusers);
            this.tabPage1.Controls.Add(this.estimates_userstextLabel);
            this.tabPage1.Controls.Add(this.estimates_userstextTextBox);
            this.tabPage1.Controls.Add(users_idLabel2);
            this.tabPage1.Controls.Add(this.users_idComboBox);
            this.tabPage1.Controls.Add(this.button_fillfromcustomers);
            this.tabPage1.Controls.Add(customers_idLabel);
            this.tabPage1.Controls.Add(this.customers_idComboBox);
            this.tabPage1.Controls.Add(this.button_fillfrompayments);
            this.tabPage1.Controls.Add(this.comboBox_fillfrompayments);
            this.tabPage1.Controls.Add(this.estimates_totalLabel);
            this.tabPage1.Controls.Add(this.estimates_totalTextBox);
            this.tabPage1.Controls.Add(this.estimates_customerstextLabel);
            this.tabPage1.Controls.Add(this.estimates_customerstextTextBox);
            this.tabPage1.Controls.Add(this.estimates_paymentstextLabel);
            this.tabPage1.Controls.Add(this.estimates_paymentstextTextBox);
            this.tabPage1.Controls.Add(this.estimates_dateLabel);
            this.tabPage1.Controls.Add(this.estimates_dateDateTimePicker);
            this.tabPage1.Controls.Add(this.estimates_numberLabel);
            this.tabPage1.Controls.Add(this.estimates_numberTextBox);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(592, 596);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Info";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox_taxesdeduction
            // 
            this.comboBox_taxesdeduction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_taxesdeduction.FormattingEnabled = true;
            this.comboBox_taxesdeduction.Location = new System.Drawing.Point(89, 476);
            this.comboBox_taxesdeduction.Name = "comboBox_taxesdeduction";
            this.comboBox_taxesdeduction.Size = new System.Drawing.Size(100, 21);
            this.comboBox_taxesdeduction.TabIndex = 28;
            this.comboBox_taxesdeduction.SelectedIndexChanged += new System.EventHandler(this.comboBox_taxesdeduction_SelectedIndexChanged);
            // 
            // estimates_deductiontaxTextBox
            // 
            this.estimates_deductiontaxTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesBindingSource, "estimates_deductiontax", true));
            this.estimates_deductiontaxTextBox.Location = new System.Drawing.Point(13, 477);
            this.estimates_deductiontaxTextBox.MaxLength = 5;
            this.estimates_deductiontaxTextBox.Name = "estimates_deductiontaxTextBox";
            this.estimates_deductiontaxTextBox.Size = new System.Drawing.Size(70, 20);
            this.estimates_deductiontaxTextBox.TabIndex = 27;
            this.estimates_deductiontaxTextBox.Leave += new System.EventHandler(this.estimates_deductiontaxTextBox_Leave);
            // 
            // estimatesBindingSource
            // 
            this.estimatesBindingSource.DataMember = "estimates";
            this.estimatesBindingSource.DataSource = this.dataSet01S;
            // 
            // dataSet01S
            // 
            this.dataSet01S.DataSetName = "DataSet01S";
            this.dataSet01S.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox_fillfromfootersdocs
            // 
            this.comboBox_fillfromfootersdocs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_fillfromfootersdocs.FormattingEnabled = true;
            this.comboBox_fillfromfootersdocs.Location = new System.Drawing.Point(13, 381);
            this.comboBox_fillfromfootersdocs.Name = "comboBox_fillfromfootersdocs";
            this.comboBox_fillfromfootersdocs.Size = new System.Drawing.Size(250, 21);
            this.comboBox_fillfromfootersdocs.TabIndex = 25;
            // 
            // button_fillfromfootersdocs
            // 
            this.button_fillfromfootersdocs.Location = new System.Drawing.Point(450, 379);
            this.button_fillfromfootersdocs.Name = "button_fillfromfootersdocs";
            this.button_fillfromfootersdocs.Size = new System.Drawing.Size(136, 23);
            this.button_fillfromfootersdocs.TabIndex = 24;
            this.button_fillfromfootersdocs.Text = "fill from footers";
            this.button_fillfromfootersdocs.UseVisualStyleBackColor = true;
            this.button_fillfromfootersdocs.Click += new System.EventHandler(this.button_fillfromfootersdocs_Click);
            // 
            // estimates_footerstextTextBox
            // 
            this.estimates_footerstextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesBindingSource, "estimates_footerstext", true));
            this.estimates_footerstextTextBox.Location = new System.Drawing.Point(13, 408);
            this.estimates_footerstextTextBox.Multiline = true;
            this.estimates_footerstextTextBox.Name = "estimates_footerstextTextBox";
            this.estimates_footerstextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.estimates_footerstextTextBox.Size = new System.Drawing.Size(569, 50);
            this.estimates_footerstextTextBox.TabIndex = 23;
            // 
            // button_fillfromusers
            // 
            this.button_fillfromusers.Location = new System.Drawing.Point(448, 81);
            this.button_fillfromusers.Name = "button_fillfromusers";
            this.button_fillfromusers.Size = new System.Drawing.Size(136, 23);
            this.button_fillfromusers.TabIndex = 21;
            this.button_fillfromusers.Text = "fill from user";
            this.button_fillfromusers.UseVisualStyleBackColor = true;
            this.button_fillfromusers.Click += new System.EventHandler(this.button_fillfromusers_Click);
            // 
            // estimates_userstextTextBox
            // 
            this.estimates_userstextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesBindingSource, "estimates_userstext", true));
            this.estimates_userstextTextBox.Location = new System.Drawing.Point(12, 107);
            this.estimates_userstextTextBox.Multiline = true;
            this.estimates_userstextTextBox.Name = "estimates_userstextTextBox";
            this.estimates_userstextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.estimates_userstextTextBox.Size = new System.Drawing.Size(572, 50);
            this.estimates_userstextTextBox.TabIndex = 20;
            // 
            // users_idComboBox
            // 
            this.users_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.estimatesBindingSource, "users_id", true));
            this.users_idComboBox.DataSource = this.comboviewDataTableusersBindingSource;
            this.users_idComboBox.DisplayMember = "users_alias";
            this.users_idComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.users_idComboBox.Enabled = false;
            this.users_idComboBox.FormattingEnabled = true;
            this.users_idComboBox.Location = new System.Drawing.Point(13, 67);
            this.users_idComboBox.Name = "users_idComboBox";
            this.users_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.users_idComboBox.TabIndex = 18;
            this.users_idComboBox.ValueMember = "users_id";
            // 
            // comboviewDataTableusersBindingSource
            // 
            this.comboviewDataTableusersBindingSource.DataMember = "comboviewDataTableusers";
            this.comboviewDataTableusersBindingSource.DataSource = this.dataSet01V;
            // 
            // dataSet01V
            // 
            this.dataSet01V.DataSetName = "DataSet01V";
            this.dataSet01V.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button_fillfromcustomers
            // 
            this.button_fillfromcustomers.Location = new System.Drawing.Point(448, 187);
            this.button_fillfromcustomers.Name = "button_fillfromcustomers";
            this.button_fillfromcustomers.Size = new System.Drawing.Size(136, 23);
            this.button_fillfromcustomers.TabIndex = 16;
            this.button_fillfromcustomers.Text = "fill from customer";
            this.button_fillfromcustomers.UseVisualStyleBackColor = true;
            this.button_fillfromcustomers.Click += new System.EventHandler(this.button_fillfromcustomers_Click);
            // 
            // customers_idComboBox
            // 
            this.customers_idComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.customers_idComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.customers_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.estimatesBindingSource, "customers_id", true));
            this.customers_idComboBox.DataSource = this.comboviewDataTablecustomersBindingSource;
            this.customers_idComboBox.DisplayMember = "customers_alias";
            this.customers_idComboBox.FormattingEnabled = true;
            this.customers_idComboBox.Location = new System.Drawing.Point(12, 176);
            this.customers_idComboBox.Name = "customers_idComboBox";
            this.customers_idComboBox.Size = new System.Drawing.Size(121, 21);
            this.customers_idComboBox.TabIndex = 15;
            this.customers_idComboBox.ValueMember = "customers_id";
            // 
            // comboviewDataTablecustomersBindingSource
            // 
            this.comboviewDataTablecustomersBindingSource.DataMember = "comboviewDataTablecustomers";
            this.comboviewDataTablecustomersBindingSource.DataSource = this.dataSet01V;
            // 
            // button_fillfrompayments
            // 
            this.button_fillfrompayments.Location = new System.Drawing.Point(448, 283);
            this.button_fillfrompayments.Name = "button_fillfrompayments";
            this.button_fillfrompayments.Size = new System.Drawing.Size(136, 23);
            this.button_fillfrompayments.TabIndex = 13;
            this.button_fillfrompayments.Text = "fill from payment";
            this.button_fillfrompayments.UseVisualStyleBackColor = true;
            this.button_fillfrompayments.Click += new System.EventHandler(this.button_fillfrompayments_Click);
            // 
            // comboBox_fillfrompayments
            // 
            this.comboBox_fillfrompayments.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_fillfrompayments.FormattingEnabled = true;
            this.comboBox_fillfrompayments.Location = new System.Drawing.Point(13, 285);
            this.comboBox_fillfrompayments.Name = "comboBox_fillfrompayments";
            this.comboBox_fillfrompayments.Size = new System.Drawing.Size(250, 21);
            this.comboBox_fillfrompayments.TabIndex = 12;
            // 
            // estimates_totalTextBox
            // 
            this.estimates_totalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesBindingSource, "estimates_total", true));
            this.estimates_totalTextBox.Location = new System.Drawing.Point(514, 28);
            this.estimates_totalTextBox.Name = "estimates_totalTextBox";
            this.estimates_totalTextBox.ReadOnly = true;
            this.estimates_totalTextBox.Size = new System.Drawing.Size(70, 20);
            this.estimates_totalTextBox.TabIndex = 11;
            // 
            // estimates_customerstextTextBox
            // 
            this.estimates_customerstextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesBindingSource, "estimates_customerstext", true));
            this.estimates_customerstextTextBox.Location = new System.Drawing.Point(13, 216);
            this.estimates_customerstextTextBox.Multiline = true;
            this.estimates_customerstextTextBox.Name = "estimates_customerstextTextBox";
            this.estimates_customerstextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.estimates_customerstextTextBox.Size = new System.Drawing.Size(571, 50);
            this.estimates_customerstextTextBox.TabIndex = 7;
            // 
            // estimates_paymentstextTextBox
            // 
            this.estimates_paymentstextTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesBindingSource, "estimates_paymentstext", true));
            this.estimates_paymentstextTextBox.Location = new System.Drawing.Point(15, 312);
            this.estimates_paymentstextTextBox.Multiline = true;
            this.estimates_paymentstextTextBox.Name = "estimates_paymentstextTextBox";
            this.estimates_paymentstextTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.estimates_paymentstextTextBox.Size = new System.Drawing.Size(571, 50);
            this.estimates_paymentstextTextBox.TabIndex = 5;
            // 
            // estimates_dateDateTimePicker
            // 
            this.estimates_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.estimatesBindingSource, "estimates_date", true));
            this.estimates_dateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.estimates_dateDateTimePicker.Location = new System.Drawing.Point(130, 28);
            this.estimates_dateDateTimePicker.Name = "estimates_dateDateTimePicker";
            this.estimates_dateDateTimePicker.Size = new System.Drawing.Size(100, 20);
            this.estimates_dateDateTimePicker.TabIndex = 3;
            // 
            // estimates_numberTextBox
            // 
            this.estimates_numberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesBindingSource, "estimates_number", true));
            this.estimates_numberTextBox.Location = new System.Drawing.Point(13, 28);
            this.estimates_numberTextBox.MaxLength = 11;
            this.estimates_numberTextBox.Name = "estimates_numberTextBox";
            this.estimates_numberTextBox.Size = new System.Drawing.Size(70, 20);
            this.estimates_numberTextBox.TabIndex = 1;
            this.estimates_numberTextBox.Leave += new System.EventHandler(this.estimates_numberTextBox_Leave);
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.panel14);
            this.tabPage2.Controls.Add(this.panel13);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(592, 596);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Items";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.dataGridView_estimatesitemsmain);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(3, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(586, 197);
            this.panel14.TabIndex = 3;
            // 
            // dataGridView_estimatesitemsmain
            // 
            this.dataGridView_estimatesitemsmain.AllowUserToAddRows = false;
            this.dataGridView_estimatesitemsmain.AllowUserToDeleteRows = false;
            this.dataGridView_estimatesitemsmain.AllowUserToResizeColumns = false;
            this.dataGridView_estimatesitemsmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_estimatesitemsmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView_estimatesitemsmain.AutoGenerateColumns = false;
            this.dataGridView_estimatesitemsmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_estimatesitemsmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.estimatesitemsidDataGridViewTextBoxColumn,
            this.estimatesitemscodeDataGridViewTextBoxColumn,
            this.estimatesitemsdescDataGridViewTextBoxColumn,
            this.estimatesitemspriceDataGridViewTextBoxColumn});
            this.dataGridView_estimatesitemsmain.DataSource = this.subviewDataTableestimatesitemsBindingSource;
            this.dataGridView_estimatesitemsmain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_estimatesitemsmain.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_estimatesitemsmain.MultiSelect = false;
            this.dataGridView_estimatesitemsmain.Name = "dataGridView_estimatesitemsmain";
            this.dataGridView_estimatesitemsmain.ReadOnly = true;
            this.dataGridView_estimatesitemsmain.RowHeadersVisible = false;
            this.dataGridView_estimatesitemsmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_estimatesitemsmain.Size = new System.Drawing.Size(586, 197);
            this.dataGridView_estimatesitemsmain.TabIndex = 1;
            // 
            // estimatesitemsidDataGridViewTextBoxColumn
            // 
            this.estimatesitemsidDataGridViewTextBoxColumn.DataPropertyName = "estimatesitems_id";
            this.estimatesitemsidDataGridViewTextBoxColumn.HeaderText = "Id";
            this.estimatesitemsidDataGridViewTextBoxColumn.Name = "estimatesitemsidDataGridViewTextBoxColumn";
            this.estimatesitemsidDataGridViewTextBoxColumn.ReadOnly = true;
            this.estimatesitemsidDataGridViewTextBoxColumn.Width = 50;
            // 
            // estimatesitemscodeDataGridViewTextBoxColumn
            // 
            this.estimatesitemscodeDataGridViewTextBoxColumn.DataPropertyName = "estimatesitems_code";
            this.estimatesitemscodeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.estimatesitemscodeDataGridViewTextBoxColumn.Name = "estimatesitemscodeDataGridViewTextBoxColumn";
            this.estimatesitemscodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.estimatesitemscodeDataGridViewTextBoxColumn.Width = 70;
            // 
            // estimatesitemsdescDataGridViewTextBoxColumn
            // 
            this.estimatesitemsdescDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.estimatesitemsdescDataGridViewTextBoxColumn.DataPropertyName = "estimatesitems_desc";
            this.estimatesitemsdescDataGridViewTextBoxColumn.HeaderText = "Desc";
            this.estimatesitemsdescDataGridViewTextBoxColumn.Name = "estimatesitemsdescDataGridViewTextBoxColumn";
            this.estimatesitemsdescDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // estimatesitemspriceDataGridViewTextBoxColumn
            // 
            this.estimatesitemspriceDataGridViewTextBoxColumn.DataPropertyName = "estimatesitems_price";
            this.estimatesitemspriceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.estimatesitemspriceDataGridViewTextBoxColumn.Name = "estimatesitemspriceDataGridViewTextBoxColumn";
            this.estimatesitemspriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.estimatesitemspriceDataGridViewTextBoxColumn.Width = 70;
            // 
            // subviewDataTableestimatesitemsBindingSource
            // 
            this.subviewDataTableestimatesitemsBindingSource.DataMember = "subviewDataTableestimatesitems";
            this.subviewDataTableestimatesitemsBindingSource.DataSource = this.dataSet01V;
            this.subviewDataTableestimatesitemsBindingSource.CurrentChanged += new System.EventHandler(this.subviewDataTableestimatesitemsBindingSource_CurrentChanged);
            // 
            // panel13
            // 
            this.panel13.AutoScroll = true;
            this.panel13.Controls.Add(this.button_estimatesitemsAddcomputedrowsdocs);
            this.panel13.Controls.Add(this.comboBox_estimatesitemscomputedrowsdocs);
            this.panel13.Controls.Add(this.estimatesitems_idLabel);
            this.panel13.Controls.Add(this.estimatesitems_idTextBox);
            this.panel13.Controls.Add(this.label5);
            this.panel13.Controls.Add(this.textBox_estimatesitemstotalnotax);
            this.panel13.Controls.Add(this.textBox_estimatesitemstotal);
            this.panel13.Controls.Add(this.comboBox_estimatesitemstaxes);
            this.panel13.Controls.Add(this.label4);
            this.panel13.Controls.Add(this.estimatesitems_priceLabel);
            this.panel13.Controls.Add(this.textBox_estimatesitemstotaltax);
            this.panel13.Controls.Add(this.estimatesitems_priceTextBox);
            this.panel13.Controls.Add(this.label3);
            this.panel13.Controls.Add(this.estimatesitems_codeLabel);
            this.panel13.Controls.Add(this.estimatesitems_codeTextBox);
            this.panel13.Controls.Add(this.textBox_estimatesitemstotaldeductiontax);
            this.panel13.Controls.Add(this.estimatesitems_descLabel);
            this.panel13.Controls.Add(this.label2);
            this.panel13.Controls.Add(this.estimatesitems_descTextBox);
            this.panel13.Controls.Add(this.button_estimatesitemsDelete);
            this.panel13.Controls.Add(this.estimatesitems_taxLabel);
            this.panel13.Controls.Add(this.button_estimatesitemsEdit);
            this.panel13.Controls.Add(this.estimatesitems_taxTextBox);
            this.panel13.Controls.Add(this.button_estimatesitemsNew);
            this.panel13.Controls.Add(this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel13.Location = new System.Drawing.Point(3, 200);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(586, 393);
            this.panel13.TabIndex = 2;
            // 
            // button_estimatesitemsAddcomputedrowsdocs
            // 
            this.button_estimatesitemsAddcomputedrowsdocs.Location = new System.Drawing.Point(135, 65);
            this.button_estimatesitemsAddcomputedrowsdocs.Name = "button_estimatesitemsAddcomputedrowsdocs";
            this.button_estimatesitemsAddcomputedrowsdocs.Size = new System.Drawing.Size(110, 23);
            this.button_estimatesitemsAddcomputedrowsdocs.TabIndex = 34;
            this.button_estimatesitemsAddcomputedrowsdocs.Text = "Add computed row";
            this.button_estimatesitemsAddcomputedrowsdocs.UseVisualStyleBackColor = true;
            this.button_estimatesitemsAddcomputedrowsdocs.Click += new System.EventHandler(this.button_estimatesitemsAddcomputedrowsdocs_Click);
            // 
            // comboBox_estimatesitemscomputedrowsdocs
            // 
            this.comboBox_estimatesitemscomputedrowsdocs.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_estimatesitemscomputedrowsdocs.FormattingEnabled = true;
            this.comboBox_estimatesitemscomputedrowsdocs.Location = new System.Drawing.Point(251, 66);
            this.comboBox_estimatesitemscomputedrowsdocs.Name = "comboBox_estimatesitemscomputedrowsdocs";
            this.comboBox_estimatesitemscomputedrowsdocs.Size = new System.Drawing.Size(100, 21);
            this.comboBox_estimatesitemscomputedrowsdocs.TabIndex = 33;
            // 
            // estimatesitems_idTextBox
            // 
            this.estimatesitems_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesitemsBindingSource, "estimatesitems_id", true));
            this.estimatesitems_idTextBox.Location = new System.Drawing.Point(13, 68);
            this.estimatesitems_idTextBox.Name = "estimatesitems_idTextBox";
            this.estimatesitems_idTextBox.ReadOnly = true;
            this.estimatesitems_idTextBox.Size = new System.Drawing.Size(100, 20);
            this.estimatesitems_idTextBox.TabIndex = 32;
            // 
            // estimatesitemsBindingSource
            // 
            this.estimatesitemsBindingSource.DataMember = "estimatesitems";
            this.estimatesitemsBindingSource.DataSource = this.dataSet01S;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(445, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 29;
            this.label5.Text = "total no tax";
            // 
            // textBox_estimatesitemstotalnotax
            // 
            this.textBox_estimatesitemstotalnotax.Location = new System.Drawing.Point(513, 9);
            this.textBox_estimatesitemstotalnotax.Name = "textBox_estimatesitemstotalnotax";
            this.textBox_estimatesitemstotalnotax.ReadOnly = true;
            this.textBox_estimatesitemstotalnotax.Size = new System.Drawing.Size(61, 20);
            this.textBox_estimatesitemstotalnotax.TabIndex = 28;
            // 
            // textBox_estimatesitemstotal
            // 
            this.textBox_estimatesitemstotal.Location = new System.Drawing.Point(513, 93);
            this.textBox_estimatesitemstotal.Name = "textBox_estimatesitemstotal";
            this.textBox_estimatesitemstotal.ReadOnly = true;
            this.textBox_estimatesitemstotal.Size = new System.Drawing.Size(61, 20);
            this.textBox_estimatesitemstotal.TabIndex = 16;
            // 
            // comboBox_estimatesitemstaxes
            // 
            this.comboBox_estimatesitemstaxes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_estimatesitemstaxes.FormattingEnabled = true;
            this.comboBox_estimatesitemstaxes.Location = new System.Drawing.Point(201, 214);
            this.comboBox_estimatesitemstaxes.Name = "comboBox_estimatesitemstaxes";
            this.comboBox_estimatesitemstaxes.Size = new System.Drawing.Size(80, 21);
            this.comboBox_estimatesitemstaxes.TabIndex = 26;
            this.comboBox_estimatesitemstaxes.SelectedIndexChanged += new System.EventHandler(this.comboBox_estimatesitemstaxes_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(413, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "total deduction tax";
            // 
            // textBox_estimatesitemstotaltax
            // 
            this.textBox_estimatesitemstotaltax.Location = new System.Drawing.Point(513, 38);
            this.textBox_estimatesitemstotaltax.Name = "textBox_estimatesitemstotaltax";
            this.textBox_estimatesitemstotaltax.ReadOnly = true;
            this.textBox_estimatesitemstotaltax.Size = new System.Drawing.Size(61, 20);
            this.textBox_estimatesitemstotaltax.TabIndex = 14;
            // 
            // estimatesitems_priceTextBox
            // 
            this.estimatesitems_priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesitemsBindingSource, "estimatesitems_price", true));
            this.estimatesitems_priceTextBox.Location = new System.Drawing.Point(14, 214);
            this.estimatesitems_priceTextBox.MaxLength = 11;
            this.estimatesitems_priceTextBox.Name = "estimatesitems_priceTextBox";
            this.estimatesitems_priceTextBox.Size = new System.Drawing.Size(70, 20);
            this.estimatesitems_priceTextBox.TabIndex = 25;
            this.estimatesitems_priceTextBox.Leave += new System.EventHandler(this.estimatesitems_priceTextBox_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(480, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "total";
            // 
            // estimatesitems_codeTextBox
            // 
            this.estimatesitems_codeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesitemsBindingSource, "estimatesitems_code", true));
            this.estimatesitems_codeTextBox.Location = new System.Drawing.Point(13, 107);
            this.estimatesitems_codeTextBox.MaxLength = 15;
            this.estimatesitems_codeTextBox.Name = "estimatesitems_codeTextBox";
            this.estimatesitems_codeTextBox.Size = new System.Drawing.Size(100, 20);
            this.estimatesitems_codeTextBox.TabIndex = 24;
            // 
            // textBox_estimatesitemstotaldeductiontax
            // 
            this.textBox_estimatesitemstotaldeductiontax.Location = new System.Drawing.Point(513, 67);
            this.textBox_estimatesitemstotaldeductiontax.Name = "textBox_estimatesitemstotaldeductiontax";
            this.textBox_estimatesitemstotaldeductiontax.ReadOnly = true;
            this.textBox_estimatesitemstotaldeductiontax.Size = new System.Drawing.Size(61, 20);
            this.textBox_estimatesitemstotaldeductiontax.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(460, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "total tax";
            // 
            // estimatesitems_descTextBox
            // 
            this.estimatesitems_descTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesitemsBindingSource, "estimatesitems_desc", true));
            this.estimatesitems_descTextBox.Location = new System.Drawing.Point(13, 145);
            this.estimatesitems_descTextBox.Multiline = true;
            this.estimatesitems_descTextBox.Name = "estimatesitems_descTextBox";
            this.estimatesitems_descTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.estimatesitems_descTextBox.Size = new System.Drawing.Size(568, 50);
            this.estimatesitems_descTextBox.TabIndex = 23;
            // 
            // button_estimatesitemsDelete
            // 
            this.button_estimatesitemsDelete.Location = new System.Drawing.Point(165, 6);
            this.button_estimatesitemsDelete.Name = "button_estimatesitemsDelete";
            this.button_estimatesitemsDelete.Size = new System.Drawing.Size(75, 23);
            this.button_estimatesitemsDelete.TabIndex = 8;
            this.button_estimatesitemsDelete.Text = "Delete";
            this.button_estimatesitemsDelete.UseVisualStyleBackColor = true;
            this.button_estimatesitemsDelete.Click += new System.EventHandler(this.button_estimatesitemsDelete_Click);
            // 
            // button_estimatesitemsEdit
            // 
            this.button_estimatesitemsEdit.Location = new System.Drawing.Point(84, 6);
            this.button_estimatesitemsEdit.Name = "button_estimatesitemsEdit";
            this.button_estimatesitemsEdit.Size = new System.Drawing.Size(75, 23);
            this.button_estimatesitemsEdit.TabIndex = 7;
            this.button_estimatesitemsEdit.Text = "Edit";
            this.button_estimatesitemsEdit.UseVisualStyleBackColor = true;
            this.button_estimatesitemsEdit.Click += new System.EventHandler(this.button_estimatesitemsEdit_Click);
            // 
            // estimatesitems_taxTextBox
            // 
            this.estimatesitems_taxTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.estimatesitemsBindingSource, "estimatesitems_tax", true));
            this.estimatesitems_taxTextBox.Location = new System.Drawing.Point(125, 214);
            this.estimatesitems_taxTextBox.MaxLength = 5;
            this.estimatesitems_taxTextBox.Name = "estimatesitems_taxTextBox";
            this.estimatesitems_taxTextBox.Size = new System.Drawing.Size(70, 20);
            this.estimatesitems_taxTextBox.TabIndex = 21;
            this.estimatesitems_taxTextBox.Leave += new System.EventHandler(this.estimatesitems_taxTextBox_Leave);
            // 
            // button_estimatesitemsNew
            // 
            this.button_estimatesitemsNew.Location = new System.Drawing.Point(3, 6);
            this.button_estimatesitemsNew.Name = "button_estimatesitemsNew";
            this.button_estimatesitemsNew.Size = new System.Drawing.Size(75, 23);
            this.button_estimatesitemsNew.TabIndex = 6;
            this.button_estimatesitemsNew.Text = "New";
            this.button_estimatesitemsNew.UseVisualStyleBackColor = true;
            this.button_estimatesitemsNew.Click += new System.EventHandler(this.button_estimatesitemsNew_Click);
            // 
            // groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments
            // 
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id);
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name);
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code);
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.dataGridView_estimatesitemsfillfromtreatmentsmain);
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Controls.Add(this.button_estimatesitemsfillfromtreatments);
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Location = new System.Drawing.Point(13, 241);
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Name = "groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments";
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Size = new System.Drawing.Size(567, 115);
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.TabIndex = 17;
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.TabStop = false;
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.Text = "fill from treatments";
            // 
            // comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id
            // 
            this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.FormattingEnabled = true;
            this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.Location = new System.Drawing.Point(69, 18);
            this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.Name = "comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id";
            this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.Size = new System.Drawing.Size(74, 21);
            this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.TabIndex = 6;
            this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id_SelectedIndexChanged);
            // 
            // textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name
            // 
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name.Location = new System.Drawing.Point(149, 19);
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name.Name = "textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name";
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name.Size = new System.Drawing.Size(113, 20);
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name.TabIndex = 5;
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name.TextChanged += new System.EventHandler(this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name_TextChanged);
            // 
            // textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code
            // 
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code.Location = new System.Drawing.Point(7, 19);
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code.Name = "textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code";
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code.Size = new System.Drawing.Size(58, 20);
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code.TabIndex = 3;
            this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code.TextChanged += new System.EventHandler(this.textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code_TextChanged);
            // 
            // dataGridView_estimatesitemsfillfromtreatmentsmain
            // 
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.AllowUserToAddRows = false;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.AllowUserToDeleteRows = false;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.AllowUserToResizeColumns = false;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.AutoGenerateColumns = false;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.treatmentscodeDataGridViewTextBoxColumn,
            this.treatmentscategoriesnameDataGridViewTextBoxColumn,
            this.treatmentsnameDataGridViewTextBoxColumn,
            this.treatmentsdescDataGridViewTextBoxColumn});
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.DataSource = this.comboviewDataTabletreatmentsBindingSource;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.Location = new System.Drawing.Point(6, 40);
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.MultiSelect = false;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.Name = "dataGridView_estimatesitemsfillfromtreatmentsmain";
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.ReadOnly = true;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.RowHeadersVisible = false;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.Size = new System.Drawing.Size(473, 68);
            this.dataGridView_estimatesitemsfillfromtreatmentsmain.TabIndex = 2;
            // 
            // comboviewDataTabletreatmentsBindingSource
            // 
            this.comboviewDataTabletreatmentsBindingSource.DataMember = "comboviewDataTabletreatments";
            this.comboviewDataTabletreatmentsBindingSource.DataSource = this.dataSet01V;
            // 
            // button_estimatesitemsfillfromtreatments
            // 
            this.button_estimatesitemsfillfromtreatments.Location = new System.Drawing.Point(486, 85);
            this.button_estimatesitemsfillfromtreatments.Name = "button_estimatesitemsfillfromtreatments";
            this.button_estimatesitemsfillfromtreatments.Size = new System.Drawing.Size(75, 23);
            this.button_estimatesitemsfillfromtreatments.TabIndex = 1;
            this.button_estimatesitemsfillfromtreatments.Text = "Fill";
            this.button_estimatesitemsfillfromtreatments.UseVisualStyleBackColor = true;
            this.button_estimatesitemsfillfromtreatments.Click += new System.EventHandler(this.button_estimatesitemsfillfromtreatments_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(174, 6);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 2;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Edit
            // 
            this.button_Edit.Location = new System.Drawing.Point(93, 6);
            this.button_Edit.Name = "button_Edit";
            this.button_Edit.Size = new System.Drawing.Size(75, 23);
            this.button_Edit.TabIndex = 1;
            this.button_Edit.Text = "Edit";
            this.button_Edit.UseVisualStyleBackColor = true;
            this.button_Edit.Click += new System.EventHandler(this.button_Edit_Click);
            // 
            // button_New
            // 
            this.button_New.Location = new System.Drawing.Point(12, 6);
            this.button_New.Name = "button_New";
            this.button_New.Size = new System.Drawing.Size(75, 23);
            this.button_New.TabIndex = 0;
            this.button_New.Text = "New";
            this.button_New.UseVisualStyleBackColor = true;
            this.button_New.Click += new System.EventHandler(this.button_New_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox_total);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.button_Print);
            this.panel4.Controls.Add(this.button_Delete);
            this.panel4.Controls.Add(this.button_Edit);
            this.panel4.Controls.Add(this.button_New);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 597);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(384, 65);
            this.panel4.TabIndex = 1;
            // 
            // textBox_total
            // 
            this.textBox_total.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_total.Location = new System.Drawing.Point(308, 6);
            this.textBox_total.Name = "textBox_total";
            this.textBox_total.ReadOnly = true;
            this.textBox_total.Size = new System.Drawing.Size(70, 20);
            this.textBox_total.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(275, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "total";
            // 
            // button_Print
            // 
            this.button_Print.Location = new System.Drawing.Point(12, 35);
            this.button_Print.Name = "button_Print";
            this.button_Print.Size = new System.Drawing.Size(75, 23);
            this.button_Print.TabIndex = 4;
            this.button_Print.Text = "Print";
            this.button_Print.UseVisualStyleBackColor = true;
            this.button_Print.Click += new System.EventHandler(this.button_Print_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "year";
            // 
            // comboBox_filter_year
            // 
            this.comboBox_filter_year.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_filter_year.FormattingEnabled = true;
            this.comboBox_filter_year.Location = new System.Drawing.Point(43, 12);
            this.comboBox_filter_year.Name = "comboBox_filter_year";
            this.comboBox_filter_year.Size = new System.Drawing.Size(70, 21);
            this.comboBox_filter_year.TabIndex = 4;
            this.comboBox_filter_year.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_year_SelectedIndexChanged);
            // 
            // button_Undo
            // 
            this.button_Undo.Location = new System.Drawing.Point(87, 6);
            this.button_Undo.Name = "button_Undo";
            this.button_Undo.Size = new System.Drawing.Size(75, 23);
            this.button_Undo.TabIndex = 1;
            this.button_Undo.Text = "Undo";
            this.button_Undo.UseVisualStyleBackColor = true;
            this.button_Undo.Click += new System.EventHandler(this.button_Undo_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel_filter);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(384, 60);
            this.panel7.TabIndex = 3;
            // 
            // panel_filter
            // 
            this.panel_filter.Controls.Add(this.textBox_filter_customers);
            this.panel_filter.Controls.Add(this.label1);
            this.panel_filter.Controls.Add(this.comboBox_filter_users_id);
            this.panel_filter.Controls.Add(this.textBox_filter_number);
            this.panel_filter.Controls.Add(this.comboBox_filter_year);
            this.panel_filter.Controls.Add(this.label6);
            this.panel_filter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_filter.Location = new System.Drawing.Point(0, 0);
            this.panel_filter.Name = "panel_filter";
            this.panel_filter.Size = new System.Drawing.Size(384, 60);
            this.panel_filter.TabIndex = 1;
            // 
            // textBox_filter_customers
            // 
            this.textBox_filter_customers.Location = new System.Drawing.Point(110, 37);
            this.textBox_filter_customers.Name = "textBox_filter_customers";
            this.textBox_filter_customers.Size = new System.Drawing.Size(130, 20);
            this.textBox_filter_customers.TabIndex = 9;
            this.textBox_filter_customers.TextChanged += new System.EventHandler(this.textBox_filter_customers_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(119, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "user";
            // 
            // comboBox_filter_users_id
            // 
            this.comboBox_filter_users_id.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox_filter_users_id.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox_filter_users_id.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_filter_users_id.FormattingEnabled = true;
            this.comboBox_filter_users_id.Location = new System.Drawing.Point(152, 12);
            this.comboBox_filter_users_id.Name = "comboBox_filter_users_id";
            this.comboBox_filter_users_id.Size = new System.Drawing.Size(121, 21);
            this.comboBox_filter_users_id.TabIndex = 6;
            this.comboBox_filter_users_id.SelectedIndexChanged += new System.EventHandler(this.comboBox_filter_users_id_SelectedIndexChanged);
            // 
            // textBox_filter_number
            // 
            this.textBox_filter_number.Location = new System.Drawing.Point(3, 37);
            this.textBox_filter_number.Name = "textBox_filter_number";
            this.textBox_filter_number.Size = new System.Drawing.Size(45, 20);
            this.textBox_filter_number.TabIndex = 3;
            this.textBox_filter_number.TextChanged += new System.EventHandler(this.textBox_filter_number_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(384, 662);
            this.panel1.TabIndex = 6;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView_main);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 60);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(384, 537);
            this.panel5.TabIndex = 2;
            // 
            // dataGridView_main
            // 
            this.dataGridView_main.AllowUserToAddRows = false;
            this.dataGridView_main.AllowUserToDeleteRows = false;
            this.dataGridView_main.AllowUserToResizeColumns = false;
            this.dataGridView_main.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView_main.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView_main.AutoGenerateColumns = false;
            this.dataGridView_main.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_main.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.estimatesnumberDataGridViewTextBoxColumn,
            this.estimatesdateDataGridViewTextBoxColumn,
            this.customersaliasDataGridViewTextBoxColumn,
            this.estimatestotalDataGridViewTextBoxColumn});
            this.dataGridView_main.DataSource = this.viewDataTableestimatesBindingSource;
            this.dataGridView_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView_main.Location = new System.Drawing.Point(0, 0);
            this.dataGridView_main.MultiSelect = false;
            this.dataGridView_main.Name = "dataGridView_main";
            this.dataGridView_main.ReadOnly = true;
            this.dataGridView_main.RowHeadersVisible = false;
            this.dataGridView_main.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_main.Size = new System.Drawing.Size(384, 537);
            this.dataGridView_main.TabIndex = 0;
            // 
            // estimatesnumberDataGridViewTextBoxColumn
            // 
            this.estimatesnumberDataGridViewTextBoxColumn.DataPropertyName = "estimates_number";
            this.estimatesnumberDataGridViewTextBoxColumn.HeaderText = "Num.";
            this.estimatesnumberDataGridViewTextBoxColumn.Name = "estimatesnumberDataGridViewTextBoxColumn";
            this.estimatesnumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.estimatesnumberDataGridViewTextBoxColumn.Width = 40;
            // 
            // estimatesdateDataGridViewTextBoxColumn
            // 
            this.estimatesdateDataGridViewTextBoxColumn.DataPropertyName = "estimates_date";
            this.estimatesdateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.estimatesdateDataGridViewTextBoxColumn.Name = "estimatesdateDataGridViewTextBoxColumn";
            this.estimatesdateDataGridViewTextBoxColumn.ReadOnly = true;
            this.estimatesdateDataGridViewTextBoxColumn.Width = 70;
            // 
            // customersaliasDataGridViewTextBoxColumn
            // 
            this.customersaliasDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.customersaliasDataGridViewTextBoxColumn.DataPropertyName = "customers_alias";
            this.customersaliasDataGridViewTextBoxColumn.HeaderText = "Customer";
            this.customersaliasDataGridViewTextBoxColumn.Name = "customersaliasDataGridViewTextBoxColumn";
            this.customersaliasDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // estimatestotalDataGridViewTextBoxColumn
            // 
            this.estimatestotalDataGridViewTextBoxColumn.DataPropertyName = "estimates_total";
            this.estimatestotalDataGridViewTextBoxColumn.HeaderText = "Total";
            this.estimatestotalDataGridViewTextBoxColumn.Name = "estimatestotalDataGridViewTextBoxColumn";
            this.estimatestotalDataGridViewTextBoxColumn.ReadOnly = true;
            this.estimatestotalDataGridViewTextBoxColumn.Width = 50;
            // 
            // viewDataTableestimatesBindingSource
            // 
            this.viewDataTableestimatesBindingSource.DataMember = "viewDataTableestimates";
            this.viewDataTableestimatesBindingSource.DataSource = this.dataSet01V;
            this.viewDataTableestimatesBindingSource.CurrentChanged += new System.EventHandler(this.viewDataTableestimatesBindingSource_CurrentChanged);
            // 
            // button_Save
            // 
            this.button_Save.Location = new System.Drawing.Point(6, 6);
            this.button_Save.Name = "button_Save";
            this.button_Save.Size = new System.Drawing.Size(75, 23);
            this.button_Save.TabIndex = 0;
            this.button_Save.Text = "Save";
            this.button_Save.UseVisualStyleBackColor = true;
            this.button_Save.Click += new System.EventHandler(this.button_Save_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Stopedit);
            this.panel3.Controls.Add(this.button_Undo);
            this.panel3.Controls.Add(this.button_Save);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 622);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(600, 40);
            this.panel3.TabIndex = 0;
            // 
            // button_Stopedit
            // 
            this.button_Stopedit.Location = new System.Drawing.Point(168, 5);
            this.button_Stopedit.Name = "button_Stopedit";
            this.button_Stopedit.Size = new System.Drawing.Size(75, 23);
            this.button_Stopedit.TabIndex = 2;
            this.button_Stopedit.Text = "End Edit";
            this.button_Stopedit.UseVisualStyleBackColor = true;
            this.button_Stopedit.Click += new System.EventHandler(this.button_Stopedit_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(384, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(600, 662);
            this.panel2.TabIndex = 7;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.tabControl_main);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(600, 622);
            this.panel6.TabIndex = 1;
            // 
            // viewDataTableestimatesTableAdapter
            // 
            this.viewDataTableestimatesTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablecustomersTableAdapter
            // 
            this.comboviewDataTablecustomersTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablepaymentsBindingSource
            // 
            this.comboviewDataTablepaymentsBindingSource.DataMember = "comboviewDataTablepayments";
            this.comboviewDataTablepaymentsBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTablepaymentsTableAdapter
            // 
            this.comboviewDataTablepaymentsTableAdapter.ClearBeforeFill = true;
            // 
            // estimatesitemsTableAdapter
            // 
            this.estimatesitemsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTableusersTableAdapter
            // 
            this.comboviewDataTableusersTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletaxesBindingSource
            // 
            this.comboviewDataTabletaxesBindingSource.DataMember = "comboviewDataTabletaxes";
            this.comboviewDataTabletaxesBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTabletaxesTableAdapter
            // 
            this.comboviewDataTabletaxesTableAdapter.ClearBeforeFill = true;
            // 
            // subviewDataTableestimatesitemsTableAdapter
            // 
            this.subviewDataTableestimatesitemsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletreatmentscategoriesBindingSource
            // 
            this.comboviewDataTabletreatmentscategoriesBindingSource.DataMember = "comboviewDataTabletreatmentscategories";
            this.comboviewDataTabletreatmentscategoriesBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTabletreatmentscategoriesTableAdapter
            // 
            this.comboviewDataTabletreatmentscategoriesTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablefootersdocsBindingSource
            // 
            this.comboviewDataTablefootersdocsBindingSource.DataMember = "comboviewDataTablefootersdocs";
            this.comboviewDataTablefootersdocsBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTablefootersdocsTableAdapter
            // 
            this.comboviewDataTablefootersdocsTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTabletaxesdeductionBindingSource
            // 
            this.comboviewDataTabletaxesdeductionBindingSource.DataMember = "comboviewDataTabletaxesdeduction";
            this.comboviewDataTabletaxesdeductionBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTabletaxesdeductionTableAdapter
            // 
            this.comboviewDataTabletaxesdeductionTableAdapter.ClearBeforeFill = true;
            // 
            // comboviewDataTablecomputedrowsdocsBindingSource
            // 
            this.comboviewDataTablecomputedrowsdocsBindingSource.DataMember = "comboviewDataTablecomputedrowsdocs";
            this.comboviewDataTablecomputedrowsdocsBindingSource.DataSource = this.dataSet01V;
            // 
            // comboviewDataTablecomputedrowsdocsTableAdapter
            // 
            this.comboviewDataTablecomputedrowsdocsTableAdapter.ClearBeforeFill = true;
            // 
            // estimatesTableAdapter
            // 
            this.estimatesTableAdapter.ClearBeforeFill = true;
            // 
            // treatmentsdescDataGridViewTextBoxColumn
            // 
            this.treatmentsdescDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.treatmentsdescDataGridViewTextBoxColumn.DataPropertyName = "treatments_desc";
            this.treatmentsdescDataGridViewTextBoxColumn.HeaderText = "Desc";
            this.treatmentsdescDataGridViewTextBoxColumn.Name = "treatmentsdescDataGridViewTextBoxColumn";
            this.treatmentsdescDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // treatmentsnameDataGridViewTextBoxColumn
            // 
            this.treatmentsnameDataGridViewTextBoxColumn.DataPropertyName = "treatments_name";
            this.treatmentsnameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.treatmentsnameDataGridViewTextBoxColumn.Name = "treatmentsnameDataGridViewTextBoxColumn";
            this.treatmentsnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentsnameDataGridViewTextBoxColumn.Width = 70;
            // 
            // treatmentscategoriesnameDataGridViewTextBoxColumn
            // 
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.DataPropertyName = "treatmentscategories_name";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.HeaderText = "Category";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.Name = "treatmentscategoriesnameDataGridViewTextBoxColumn";
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentscategoriesnameDataGridViewTextBoxColumn.Width = 70;
            // 
            // treatmentscodeDataGridViewTextBoxColumn
            // 
            this.treatmentscodeDataGridViewTextBoxColumn.DataPropertyName = "treatments_code";
            this.treatmentscodeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.treatmentscodeDataGridViewTextBoxColumn.Name = "treatmentscodeDataGridViewTextBoxColumn";
            this.treatmentscodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.treatmentscodeDataGridViewTextBoxColumn.Width = 70;
            // 
            // comboviewDataTabletreatmentsTableAdapter
            // 
            this.comboviewDataTabletreatmentsTableAdapter.ClearBeforeFill = true;
            // 
            // FormEstimates
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormEstimates";
            this.Text = "Estimates";
            this.Activated += new System.EventHandler(this.FormEstimates_Activated);
            this.Deactivate += new System.EventHandler(this.FormEstimates_Deactivate);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormEstimates_FormClosing);
            this.Load += new System.EventHandler(this.FormEstimates_Load);
            this.tabControl_main.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.estimatesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01S)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTableusersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet01V)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecustomersBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_estimatesitemsmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subviewDataTableestimatesitemsBindingSource)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.estimatesitemsBindingSource)).EndInit();
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.ResumeLayout(false);
            this.groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_estimatesitemsfillfromtreatmentsmain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentsBindingSource)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel_filter.ResumeLayout(false);
            this.panel_filter.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewDataTableestimatesBindingSource)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablepaymentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletreatmentscategoriesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablefootersdocsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTabletaxesdeductionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboviewDataTablecomputedrowsdocsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_main;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.DataGridView dataGridView_estimatesitemsmain;
        private System.Windows.Forms.Panel panel13;
        private DataSet01S dataSet01S;
        private DataSet01V dataSet01V;
        private System.Windows.Forms.GroupBox groupBox_estimatesitemsfillfromtreatmentsfillfromtreatments;
        private System.Windows.Forms.ComboBox comboBox_estimatesitemsfillfromtreatmentsfilter_treatmentscategories_id;
        private System.Windows.Forms.TextBox textBox_estimatesitemsfillfromtreatmentsfilter_treatments_name;
        private System.Windows.Forms.TextBox textBox_estimatesitemsfillfromtreatmentsfilter_treatments_code;
        private System.Windows.Forms.Button button_estimatesitemsfillfromtreatments;
        private System.Windows.Forms.Button button_estimatesitemsDelete;
        private System.Windows.Forms.Button button_estimatesitemsEdit;
        private System.Windows.Forms.Button button_estimatesitemsNew;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Edit;
        private System.Windows.Forms.Button button_New;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox comboBox_filter_year;
        private System.Windows.Forms.Button button_Undo;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView_main;
        private System.Windows.Forms.Button button_Save;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_Print;
        private System.Windows.Forms.TextBox textBox_total;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.BindingSource viewDataTableestimatesBindingSource;
        private DataSet01VTableAdapters.viewDataTableestimatesTableAdapter viewDataTableestimatesTableAdapter;
        private System.Windows.Forms.BindingSource estimatesBindingSource;
        private System.Windows.Forms.TextBox estimates_totalTextBox;
        private System.Windows.Forms.TextBox estimates_customerstextTextBox;
        private System.Windows.Forms.TextBox estimates_paymentstextTextBox;
        private System.Windows.Forms.DateTimePicker estimates_dateDateTimePicker;
        private System.Windows.Forms.TextBox estimates_numberTextBox;
        private System.Windows.Forms.Button button_fillfrompayments;
        private System.Windows.Forms.ComboBox comboBox_fillfrompayments;
        private System.Windows.Forms.Button button_fillfromcustomers;
        private System.Windows.Forms.ComboBox customers_idComboBox;
        private System.Windows.Forms.BindingSource comboviewDataTablecustomersBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablecustomersTableAdapter comboviewDataTablecustomersTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTablepaymentsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablepaymentsTableAdapter comboviewDataTablepaymentsTableAdapter;
        private System.Windows.Forms.BindingSource estimatesitemsBindingSource;
        private DataSet01STableAdapters.estimatesitemsTableAdapter estimatesitemsTableAdapter;
        private System.Windows.Forms.ComboBox users_idComboBox;
        private System.Windows.Forms.TextBox estimates_userstextTextBox;
        private System.Windows.Forms.Button button_fillfromusers;
        private System.Windows.Forms.BindingSource comboviewDataTableusersBindingSource;
        private DataSet01VTableAdapters.comboviewDataTableusersTableAdapter comboviewDataTableusersTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView_estimatesitemsfillfromtreatmentsmain;
        private System.Windows.Forms.TextBox estimatesitems_priceTextBox;
        private System.Windows.Forms.TextBox estimatesitems_codeTextBox;
        private System.Windows.Forms.TextBox estimatesitems_descTextBox;
        private System.Windows.Forms.TextBox estimatesitems_taxTextBox;
        private System.Windows.Forms.ComboBox comboBox_estimatesitemstaxes;
        private System.Windows.Forms.TextBox textBox_estimatesitemstotal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_estimatesitemstotaltax;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_estimatesitemstotaldeductiontax;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.BindingSource comboviewDataTabletaxesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletaxesTableAdapter comboviewDataTabletaxesTableAdapter;
        private System.Windows.Forms.BindingSource subviewDataTableestimatesitemsBindingSource;
        private DataSet01VTableAdapters.subviewDataTableestimatesitemsTableAdapter subviewDataTableestimatesitemsTableAdapter;
        private System.Windows.Forms.BindingSource comboviewDataTabletreatmentsBindingSource;
        private System.Windows.Forms.BindingSource comboviewDataTabletreatmentscategoriesBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletreatmentscategoriesTableAdapter comboviewDataTabletreatmentscategoriesTableAdapter;
        private System.Windows.Forms.Panel panel_filter;
        private System.Windows.Forms.ComboBox comboBox_filter_users_id;
        private System.Windows.Forms.TextBox textBox_filter_number;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_estimatesitemstotalnotax;
        private System.Windows.Forms.TextBox estimatesitems_idTextBox;
        private System.Windows.Forms.ComboBox comboBox_fillfromfootersdocs;
        private System.Windows.Forms.Button button_fillfromfootersdocs;
        private System.Windows.Forms.TextBox estimates_footerstextTextBox;
        private System.Windows.Forms.BindingSource comboviewDataTablefootersdocsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablefootersdocsTableAdapter comboviewDataTablefootersdocsTableAdapter;
        private System.Windows.Forms.ComboBox comboBox_taxesdeduction;
        private System.Windows.Forms.TextBox estimates_deductiontaxTextBox;
        private System.Windows.Forms.ComboBox comboBox_estimatesitemscomputedrowsdocs;
        private System.Windows.Forms.BindingSource comboviewDataTabletaxesdeductionBindingSource;
        private DataSet01VTableAdapters.comboviewDataTabletaxesdeductionTableAdapter comboviewDataTabletaxesdeductionTableAdapter;
        private System.Windows.Forms.Button button_estimatesitemsAddcomputedrowsdocs;
        private System.Windows.Forms.DataGridViewTextBoxColumn estimatesitemsidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estimatesitemscodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estimatesitemsdescDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estimatesitemspriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource comboviewDataTablecomputedrowsdocsBindingSource;
        private DataSet01VTableAdapters.comboviewDataTablecomputedrowsdocsTableAdapter comboviewDataTablecomputedrowsdocsTableAdapter;
        private System.Windows.Forms.Button button_Stopedit;
        private System.Windows.Forms.Label estimates_numberLabel;
        private System.Windows.Forms.Label estimates_dateLabel;
        private System.Windows.Forms.Label estimates_paymentstextLabel;
        private System.Windows.Forms.Label estimates_customerstextLabel;
        private System.Windows.Forms.Label estimates_totalLabel;
        private System.Windows.Forms.Label estimates_userstextLabel;
        private System.Windows.Forms.Label estimatesitems_taxLabel;
        private System.Windows.Forms.Label estimatesitems_descLabel;
        private System.Windows.Forms.Label estimatesitems_codeLabel;
        private System.Windows.Forms.Label estimatesitems_priceLabel;
        private System.Windows.Forms.Label estimatesitems_idLabel;
        private System.Windows.Forms.Label estimates_footerstextLabel;
        private System.Windows.Forms.Label estimates_deductiontaxLabel;
        private DataSet01STableAdapters.estimatesTableAdapter estimatesTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn estimatesnumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estimatesdateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customersaliasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn estimatestotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox_filter_customers;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentscategoriesnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn treatmentsdescDataGridViewTextBoxColumn;
        private DataSet01VTableAdapters.comboviewDataTabletreatmentsTableAdapter comboviewDataTabletreatmentsTableAdapter;

    }
}