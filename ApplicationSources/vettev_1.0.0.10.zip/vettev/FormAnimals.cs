﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Resources;
using System.Reflection;
using Gettext;

namespace vettev
{
    public partial class FormAnimals : Form
    {
        int animals_id = -1;
        int animalsnotes_id = -1;
        int animalstreatments_id = -1;

        private static int IS_ACTION = 0;
        private static int IS_ACTIONSUB = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormAnimals()
        {
            InitializeComponent();
        }

        private void FormAnimals_Load(object sender, EventArgs e)
        {
            this.comboviewDataTabletreatmentsTableAdapter.Fill(this.dataSet01V.comboviewDataTabletreatments);
            this.comboviewDataTablepaystatusTableAdapter.Fill(this.dataSet01V.comboviewDataTablepaystatus);
            this.comboviewDataTabletreatmentscategoriesTableAdapter.Fill(this.dataSet01V.comboviewDataTabletreatmentscategories);
            this.comboviewDataTableusersTableAdapter.Fill(this.dataSet01V.comboviewDataTableusers);
            this.comboviewDataTableanimalsnotestypesTableAdapter.Fill(this.dataSet01V.comboviewDataTableanimalsnotestypes);
            this.comboviewDataTablecustomersTableAdapter.Fill(this.dataSet01V.comboviewDataTablecustomers);
            this.comboviewDataTablebreedsTableAdapter.Fill(this.dataSet01V.comboviewDataTablebreeds);

            viewDataTableanimalsBindingSource.Sort = "animals_name";

            subviewDataTableanimalsnotesBindingSource.Sort = "animalsnotes_date DESC";
            subviewDataTableanimalstreatmentsBindingSource.Sort = "animalstreatments_date DESC";
            comboviewDataTabletreatmentsBindingSource.Sort = "treatments_name";

            comboBox_filter_customers_id.Items.Clear();
            comboBox_filter_customers_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablecustomersRow r in dataSet01V.comboviewDataTablecustomers.Select("", "customers_alias"))
            {
                comboBox_filter_customers_id.Items.Add(new CLItemA(r.customers_id.ToString(), r.customers_alias.ToString()));
            }
            comboBox_filter_customers_id.SelectedIndex = 0;

            comboBox_animalsnotesfilter_animalsnotestypes_id.Items.Clear();
            comboBox_animalsnotesfilter_animalsnotestypes_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTableanimalsnotestypesRow r in dataSet01V.comboviewDataTableanimalsnotestypes.Select("", "animalsnotestypes_name"))
            {
                comboBox_animalsnotesfilter_animalsnotestypes_id.Items.Add(new CLItemA(r.animalsnotestypes_id.ToString(), r.animalsnotestypes_name.ToString()));
            }
            comboBox_animalsnotesfilter_animalsnotestypes_id.SelectedIndex = 0;

            comboBox_animalstreatmentsfilter_treamtentscategories_id.Items.Clear();
            comboBox_animalstreatmentsfilter_treamtentscategories_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletreatmentscategoriesRow r in dataSet01V.comboviewDataTabletreatmentscategories.Select("", "treatmentscategories_name"))
            {
                comboBox_animalstreatmentsfilter_treamtentscategories_id.Items.Add(new CLItemA(r.treatmentscategories_id.ToString(), r.treatmentscategories_name.ToString()));
            }
            comboBox_animalstreatmentsfilter_treamtentscategories_id.SelectedIndex = 0;

            comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.Items.Clear();
            comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTabletreatmentscategoriesRow r in dataSet01V.comboviewDataTabletreatmentscategories.Select("", "treatmentscategories_name"))
            {
                comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.Items.Add(new CLItemA(r.treatmentscategories_id.ToString(), r.treatmentscategories_name.ToString()));
            }
            comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex = 0;
                        
            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            tabControl_main.SelectedIndex = 0;

            loading = 0;
            reload_animals();
        }

        private void FormAnimals_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormAnimals_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormAnimals_Load(sender, e);
        }

        private void FormAnimals_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        #region main

        private void setEditingMode(bool editing_mode)
        {
            if (IS_ACTION == IS_EDIT)
            {
                setEditingMode_animalsnotes(false, true);
                setEditingMode_animalstreatments(false, true);
            }
            else
            {
                setEditingMode_animalsnotes(false, false);
                setEditingMode_animalstreatments(false, false);
            }

            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;
                button_Print.Enabled = false;

                if (tabControl_main.SelectedTab == tabPage1)
                {
                    button_Save.Enabled = true;
                    button_Undo.Enabled = true;
                    button_Stopedit.Enabled = false;
                }
                else
                {
                    button_Save.Enabled = false;
                    button_Undo.Enabled = false;
                    button_Stopedit.Enabled = true;
                }

                animals_nameTextBox.ReadOnly = false;
                animals_tagTextBox.ReadOnly = false;
                animals_notesTextBox.ReadOnly = false;
                animals_sex_UradioButton.Enabled = true;
                animals_sex_MradioButton.Enabled = true;
                animals_sex_FradioButton.Enabled = true;
                animals_sterilized_UradioButton.Enabled = true;
                animals_sterilized_YradioButton.Enabled = true;
                animals_sterilized_NradioButton.Enabled = true;
                breeds_idComboBox.Enabled = true;
                animals_birthDateTimePicker.Enabled = true;
                animals_deathDateTimePicker.Enabled = true;
                animals_birthunknowncheckBox.Enabled = true;
                checkBox_isdeath.Enabled = true;
                
                dataGridView_main.Enabled = false;

                panel_filter.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;
                button_Print.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = false;

                animals_nameTextBox.ReadOnly = true;
                animals_tagTextBox.ReadOnly = true;
                animals_notesTextBox.ReadOnly = true;
                animals_sex_UradioButton.Enabled = false;
                animals_sex_MradioButton.Enabled = false;
                animals_sex_FradioButton.Enabled = false;
                animals_sterilized_UradioButton.Enabled = false;
                animals_sterilized_YradioButton.Enabled = false;
                animals_sterilized_NradioButton.Enabled = false;
                breeds_idComboBox.Enabled = false;
                animals_birthDateTimePicker.Enabled = false;
                animals_deathDateTimePicker.Enabled = false;
                animals_birthunknowncheckBox.Enabled = false;
                checkBox_isdeath.Enabled = false;

                dataGridView_main.Enabled = true;

                panel_filter.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            if (comboBox_filter_customers_id.SelectedIndex != -1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = false;
                tabPage1.Enabled = true;
                tabControl_main.SelectedIndex = 0;

                IS_ACTION = IS_NEW;
                setEditingMode(true);

                animalsBindingSource.AddNew();

                customers_idTextBox.Text = ((CLItemA)comboBox_filter_customers_id.SelectedItem).id;

                breeds_idComboBox.SelectedIndex = 0;

                animals_birthDateTimePicker.Value = DateTime.Now;
                animals_dateDateTimePicker.Value = DateTime.Now;
                checkBox_isdeath.Checked = false;

                animals_birthunknowncheckBox.Checked = false;
                animals_sex_UradioButton.Checked = true;
                animals_sterilized_UradioButton.Checked = true;

                button_Opendatadir.Enabled = false;
            }
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (animals_id != -1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                {
                    if (tabControl_main.SelectedTab == tp)
                        tp.Enabled = true;
                    else
                        tp.Enabled = false;
                }

                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (animals_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    {
                        DataSet01STableAdapters.animalsnotesTableAdapter t = new DataSet01STableAdapters.animalsnotesTableAdapter();
                        DataSet01S.animalsnotesDataTable d = t.GetDataBy2(animals_id);
                        foreach (DataSet01S.animalsnotesRow r in d.Select())
                        {
                            r.Delete();
                        }
                        t.Update(d);
                    }

                    {
                        DataSet01STableAdapters.animalstreatmentsTableAdapter t = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                        DataSet01S.animalstreatmentsDataTable d = t.GetDataBy2(animals_id);
                        foreach (DataSet01S.animalstreatmentsRow r in d.Select())
                        {
                            r.Delete();
                        }
                        t.Update(d);
                    }

                    string opendatalocation = CLOptions.ReadValue("opendatalocation");
                    string opendatalocationprod = opendatalocation + "\\" + animals_id;
                    if (CLOptions.ReadValue("secdel").CompareTo(string.Empty) != 0)
                    {
                        try
                        {
                            ProcessStartInfo startInfo = new ProcessStartInfo();
                            startInfo.CreateNoWindow = true;
                            startInfo.UseShellExecute = false;
                            startInfo.FileName = CLOptions.ReadValue("secdel");
                            startInfo.Arguments = "-r -s " + opendatalocationprod;
                            startInfo.WindowStyle = ProcessWindowStyle.Hidden;
                            Process exeProcess = Process.Start(startInfo);
                            exeProcess.WaitForExit();
                        }
                        catch { }
                    }
                    else
                    {
                        try
                        {
                            Directory.Delete(opendatalocationprod, true);
                        }
                        catch { }
                    }
                    
                    animalsBindingSource.RemoveCurrent();
                    animalsTableAdapter.Update(dataSet01S.animals);
                    dataSet01S.animals.AcceptChanges();

                    reload_animals();
                }
            }
        }

        private void button_Print_Click(object sender, EventArgs e)
        {
            if (animals_id != -1)
            {
                List<int> animalstreatments_idl = new List<int>();
                foreach (DataGridViewRow r in dataGridView_animalstreatmentsmain.Rows)
                {
                    try
                    {
                        animalstreatments_idl.Add(Int32.Parse(r.Cells["animalstreatmentsidDataGridViewTextBoxColumn"].Value.ToString()));
                    }
                    catch { }
                }
                print_animals(animals_id, animalstreatments_idl);
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (animals_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            if (breeds_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a breed" + Environment.NewLine;
            }
            if (Int32.Parse(customers_idTextBox.Text) == -1)
            {
                valid_b = false;
                valid_s += "select a customer" + Environment.NewLine;
            }
            if (!animals_sex_UradioButton.Checked && !animals_sex_MradioButton.Checked && !animals_sex_FradioButton.Checked)
            {
                valid_b = false;
                valid_s += "select a sex" + Environment.NewLine;
            }
            if (!animals_sterilized_UradioButton.Checked && !animals_sterilized_YradioButton.Checked && !animals_sterilized_NradioButton.Checked)
            {
                valid_b = false;
                valid_s += "select a sterilization status" + Environment.NewLine;
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            if (tabControl_main.SelectedTab == tabPage1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;

                string valid_s = string.Empty;
                if (!validateUpdate(ref valid_s))
                {
                    MessageBox.Show(valid_s);
                    return;
                }

                if (animals_sex_UradioButton.Checked)
                    ((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sex = "U";
                else if (animals_sex_MradioButton.Checked)
                    ((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sex = "M";
                else if (animals_sex_FradioButton.Checked)
                    ((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sex = "F";

                if (animals_sterilized_UradioButton.Checked)
                    ((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sterilized = "U";
                else if (animals_sterilized_NradioButton.Checked)
                    ((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sterilized = "N";
                else if (animals_sterilized_YradioButton.Checked)
                    ((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sterilized = "Y";

                if(!animals_deathDateTimePicker.Visible)
                    ((DataRowView)animalsBindingSource.Current).Row["animals_death"] = DBNull.Value;

                animalsBindingSource.EndEdit();
                animalsTableAdapter.Update(dataSet01S.animals);
                dataSet01S.animals.AcceptChanges();
            
                int sel_id = -1;
                switch (IS_ACTION)
                {
                    case IS_NEW:
                        sel_id = animalsTableAdapter.ScalarQuery().Value;
                        break;
                    case IS_EDIT:
                        sel_id = animals_id;
                        break;
                }

                IS_ACTION = IS_VIEW;
                setEditingMode(false);

                reload_animals();
                viewDataTableanimalsBindingSource.Position = viewDataTableanimalsBindingSource.Find("animals_id", sel_id);
            }
            else if (tabControl_main.SelectedTab == tabPage2)
            {
                animalstreatments_Save();
            }
            else if (tabControl_main.SelectedTab == tabPage3)
            {
                animalsnotes_Save();
            }
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            if (tabControl_main.SelectedTab == tabPage1)
            {
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;

                animalsBindingSource.CancelEdit();
                dataSet01S.animals.RejectChanges();

                IS_ACTION = IS_VIEW;
                setEditingMode(false);
            }
            else if (tabControl_main.SelectedTab == tabPage2)
            {
                animalstreatments_Undo();
            }
            else if (tabControl_main.SelectedTab == tabPage3)
            {
                animalsnotes_Undo();
            }

            button_Opendatadir.Enabled = true;
        }

        private void button_Stopedit_Click(object sender, EventArgs e)
        {
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = true;

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            button_Opendatadir.Enabled = true;
        }

        #region pdf

        private void print_animals(int animals_id, List<int> animalstreatments_idl)
        {
            //delete old temp
            string tmplocation = "tmp";
            if (!Directory.Exists(tmplocation))
            {
                Directory.CreateDirectory(tmplocation);
            }
            DirectoryInfo di = new DirectoryInfo(tmplocation);
            FileInfo[] fis = di.GetFiles("*.*");
            foreach (FileInfo fi in fis)
            {
                try
                {
                    if (fi.LastWriteTime < DateTime.Now.AddDays(-1))
                        fi.Delete();
                }
                catch { }
            }

            //make new filename
            string pdffilename = string.Empty;
            do
            {
                pdffilename = tmplocation + "\\animals_" + animals_id.ToString() + "_" + CLGeneric.make_random_string(12) + ".pdf";
            } while (File.Exists(pdffilename));

            //fill pdf
            DataSet01STableAdapters.animalsTableAdapter t = new DataSet01STableAdapters.animalsTableAdapter();
            DataSet01S.animalsRow r = t.GetData(animals_id).First();
            DataSet01STableAdapters.customersTableAdapter tttt = new DataSet01STableAdapters.customersTableAdapter();
            DataSet01S.customersRow rrrr = tttt.GetData(r.customers_id).First();
            DataSet01STableAdapters.breedsTableAdapter ttttt = new DataSet01STableAdapters.breedsTableAdapter();
            DataSet01S.breedsRow rrrrr = ttttt.GetData(r.breeds_id).First();
            DataSet01STableAdapters.familiesTableAdapter tttttt = new DataSet01STableAdapters.familiesTableAdapter();
            DataSet01S.familiesRow rrrrrr = tttttt.GetData(rrrrr.families_id).First();

            Document document = new Document(PageSize.A4);
            PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(pdffilename, FileMode.Create));
            writer.ViewerPreferences = PdfWriter.PageModeUseOutlines;
            PrintPageN printPageN = new PrintPageN();
            writer.PageEvent = printPageN;
            document.Open();

            iTextSharp.text.Font b10Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font b12Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font n10Font = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL);

            PdfPTable aTable = null;
            PdfPCell aCell = null;
            Phrase phrase = null;

            //info
            aTable = new PdfPTable(new float[] { 1, 1, 1 });
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;
            aTable.SetTotalWidth(new float[] { 250, aTable.TotalWidth - 500, 250 });
            phrase = new Phrase();
            phrase.Add(new Chunk(CLOptions.ReadValue("docintest").Replace("\\n", Environment.NewLine), n10Font));
            aTable.AddCell(phrase);
            aTable.AddCell(new Paragraph(" "));
            phrase = new Phrase();
            phrase.Add(new Chunk(Strings.T("animals_pdf_customersalias") + ": ", b10Font));
            phrase.Add(new Chunk(rrrr.customers_alias, n10Font));
            phrase.Add(new Chunk("\n"));
            phrase.Add(new Chunk("\n"));
            phrase.Add(new Chunk(Strings.T("animals_pdf_animalsname") + ": ", b10Font));
            phrase.Add(new Chunk(r.animals_name, n10Font));
            phrase.Add(new Chunk("\n"));
            phrase.Add(new Chunk(Strings.T("animals_pdf_animalsbreed") + ": ", b10Font));
            phrase.Add(new Chunk(rrrrrr.families_name + " - " + rrrrr.breeds_name, n10Font));
            phrase.Add(new Chunk("\n"));
            phrase.Add(new Chunk(Strings.T("animals_pdf_animalssex") + ": ", b10Font));
            phrase.Add(new Chunk(r.animals_sex, n10Font));
            phrase.Add(new Chunk("\n"));
            phrase.Add(new Chunk(Strings.T("animals_pdf_animalssterilized") + ": ", b10Font));
            phrase.Add(new Chunk(r.animals_sterilized, n10Font));
            phrase.Add(new Chunk("\n"));
            phrase.Add(new Chunk(Strings.T("animals_pdf_animalsbirthdate") + ": ", b10Font));
            phrase.Add(new Chunk(r.animals_birth.ToShortDateString(), n10Font));
            if (r["animals_tag"].ToString().CompareTo(string.Empty) != 0)
            {
                phrase.Add(new Chunk("\n"));
                phrase.Add(new Chunk(Strings.T("animals_pdf_animalstag") + ": ", b10Font));
                phrase.Add(new Chunk(r.animals_tag, n10Font));
            }
            aTable.AddCell(phrase);
            document.Add(aTable);
            
            document.Add(new Paragraph(" "));

            aTable = new PdfPTable(new float[] { 1 });
            aTable.TotalWidth = PageSize.A4.Width - document.RightMargin - document.LeftMargin;
            aTable.DefaultCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
            aTable.DefaultCell.HorizontalAlignment = Element.ALIGN_LEFT;

            foreach (int animalstreatments_id in animalstreatments_idl)
            {
                DataSet01STableAdapters.animalstreatmentsTableAdapter tt = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                DataSet01S.animalstreatmentsDataTable dd = tt.GetData(animalstreatments_id);
                DataSet01S.animalstreatmentsRow rr = dd.First();

                DataSet01STableAdapters.treatmentscategoriesTableAdapter ttt = new DataSet01STableAdapters.treatmentscategoriesTableAdapter();

                phrase = new Phrase();
                phrase.Add(new Chunk("[ " + rr.animalstreatments_date.ToShortDateString() + " ] " + ttt.GetData(rr.treatmentscategories_id).First().treatmentscategories_name, n10Font));
                aCell = new PdfPCell(phrase);
                aCell.Border = iTextSharp.text.Rectangle.BOTTOM_BORDER;
                aCell.PaddingBottom = 5;
                aTable.AddCell(aCell);

                phrase = new Phrase();
                phrase.Add(new Chunk(rr.animalstreatments_desc, n10Font));
                aCell = new PdfPCell(phrase);
                aCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                aCell.PaddingBottom = 15;
                aCell.PaddingLeft = 20;
                aTable.AddCell(aCell);
            }
            document.Add(aTable);
            document.Add(new Paragraph(" "));

            document.Close();

            try
            {
                Process.Start(pdffilename);
            }
            catch { }
        }

        #endregion

        private void viewDataTableanimalsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            animals_id = -1;

            animalsBindingSource.Filter = "animals_id = -1";

            try
            {
                animals_id = (int)((DataSet01V.viewDataTableanimalsRow)((DataRowView)viewDataTableanimalsBindingSource.Current).Row).animals_id;
            }
            catch { }

            checkBox_isdeath.Checked = false;
            checkBox_isdeath_CheckedChanged(null, null);
            animals_birthDateTimePicker.Value = DateTime.Now;
            animals_dateDateTimePicker.Value = DateTime.Now;
            animals_birthunknowncheckBox.Checked = false;
            animals_sex_UradioButton.Checked = true;
            animals_sterilized_UradioButton.Checked = true;
            breeds_idComboBox.SelectedIndex = -1;

            if (animals_id != -1)
            {
                animalsTableAdapter.Fill(dataSet01S.animals, animals_id);

                animalsBindingSource.RemoveFilter();
                animalsBindingSource.Position = animalsBindingSource.Find("animals_id", animals_id);

                if(((DataRowView)animalsBindingSource.Current).Row["animals_death"].ToString().CompareTo(string.Empty) == 0)
                    checkBox_isdeath.Checked = false;
                else
                    checkBox_isdeath.Checked = true;
                checkBox_isdeath_CheckedChanged(null, null);

                if (((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sex.CompareTo("U") == 0)
                    animals_sex_UradioButton.Checked = true;
                else if (((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sex.CompareTo("M") == 0)
                    animals_sex_MradioButton.Checked = true;
                else if (((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sex.CompareTo("F") == 0)
                    animals_sex_FradioButton.Checked = true;

                if (((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sterilized.CompareTo("U") == 0)
                    animals_sterilized_UradioButton.Checked = true;
                else if (((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sterilized.CompareTo("Y") == 0)
                    animals_sterilized_YradioButton.Checked = true;
                else if (((DataSet01S.animalsRow)((DataRowView)animalsBindingSource.Current).Row).animals_sterilized.CompareTo("N") == 0)
                    animals_sterilized_NradioButton.Checked = true;

                button_Opendatadir.Enabled = true;
            }
            else
            {
                button_Opendatadir.Enabled = false;
            }

            loading = 1;
            subviewDataTableanimalsnotesTableAdapter.Fill(dataSet01V.subviewDataTableanimalsnotes, animals_id);
            loading = 0;
            subviewDataTableanimalsnotesBindingSource_CurrentChanged(null, null);

            loading = 1;
            subviewDataTableanimalstreatmentsTableAdapter.Fill(dataSet01V.subviewDataTableanimalstreatments, animals_id);
            loading = 0;
            subviewDataTableanimalstreatmentsBindingSource_CurrentChanged(null, null);
        }

        private void reload_animals()
        {
            if (comboBox_filter_customers_id.SelectedIndex != -1)
                comboBox_filter_customers_id_SelectedIndexChanged(null, null);
            else if (textBox_filter_animals.Text.Trim().CompareTo(string.Empty) != 0)
                textBox_filter_animals_TextChanged(null, null);
        }

        private void comboBox_filter_customers_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;
            
            button_New.Enabled = false;
            button_Edit.Enabled = false;
            button_Delete.Enabled = false;
            button_Print.Enabled = false;
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = false;
            loading = 1;
            textBox_filter_animals.Text = string.Empty;
            this.dataSet01V.viewDataTableanimals.Rows.Clear();
            if (comboBox_filter_customers_id.SelectedIndex != -1 && comboBox_filter_customers_id.SelectedIndex != 0)
            {
                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;
                button_Print.Enabled = true;
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;
                this.viewDataTableanimalsTableAdapter.Fill(this.dataSet01V.viewDataTableanimals, Convert.ToInt32(((CLItemA)comboBox_filter_customers_id.SelectedItem).id));
            }
            loading = 0;
            viewDataTableanimalsBindingSource_CurrentChanged(null, null);
        }
        
        private void textBox_filter_animals_TextChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            button_New.Enabled = false;
            button_Edit.Enabled = false;
            button_Delete.Enabled = false;
            button_Print.Enabled = false;
            foreach (TabPage tp in tabControl_main.TabPages)
                tp.Enabled = false;
            loading = 1;
            comboBox_filter_customers_id.SelectedIndex = 0;
            this.dataSet01V.viewDataTableanimals.Rows.Clear();
            if (textBox_filter_animals.Text.Trim().CompareTo(string.Empty) != 0)
            {
                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;
                button_Print.Enabled = true;
                foreach (TabPage tp in tabControl_main.TabPages)
                    tp.Enabled = true;

                int search_id = 0;
                try
                {
                    int.TryParse(textBox_filter_animals.Text, out search_id);
                }
                catch { }
                if (search_id != 0)
                    this.viewDataTableanimalsTableAdapter.FillBy(this.dataSet01V.viewDataTableanimals, search_id);
                else
                    this.viewDataTableanimalsTableAdapter.FillBy1(this.dataSet01V.viewDataTableanimals, "%" + textBox_filter_animals.Text + "%", "%" + textBox_filter_animals.Text + "%");   
            }
            loading = 0;
            viewDataTableanimalsBindingSource_CurrentChanged(null, null);
        }
        
        private void button_Opendatadir_Click(object sender, EventArgs e)
        {
            if (animals_id != -1)
            {
                string opendatalocation = CLOptions.ReadValue("opendatalocation");
                if (!Directory.Exists(opendatalocation))
                {
                    Directory.CreateDirectory(opendatalocation);
                }
                string opendatalocationprod = opendatalocation + "\\" + animals_id;
                if (!Directory.Exists(opendatalocationprod))
                {
                    Directory.CreateDirectory(opendatalocationprod);
                }
                Process.Start("explorer.exe", opendatalocationprod);
            }
        }

        private void checkBox_isdeath_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_isdeath.Checked)
            {
                animals_deathDateTimePicker.Visible = true;
                if (Program.is_editing_mode)
                {
                    animals_deathDateTimePicker.Value = DateTime.Now;
                }

            }
            else
            {
                animals_deathDateTimePicker.Visible = false;
            }
        }

        private void customers_idtextBox_TextChanged(object sender, EventArgs e)
        {
            customers_aliasTextBox.Text = "";

            int customers_id = -1;
            try
            {
                customers_id = Int32.Parse(customers_idTextBox.Text);
            }
            catch {}

            if(customers_id != -1)
            {
                DataSet01STableAdapters.customersTableAdapter t = new DataSet01STableAdapters.customersTableAdapter();
                customers_aliasTextBox.Text = t.GetData(customers_id).First().customers_alias;
            }
        }

        private void tabControl_main_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (!e.TabPage.Enabled)
                e.Cancel = true;
        }

        #endregion


        #region animalsnotes

        private void setEditingMode_animalsnotes(bool editing_mode, bool subediting_mode)
        {
            if (editing_mode)
            {
                button_animalsnotesNew.Enabled = false;
                button_animalsnotesEdit.Enabled = false;
                button_animalsnotesDelete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;
                button_Stopedit.Enabled = false;

                animalsnotes_notesTextBox.ReadOnly = false;
                animalsnotestypes_idComboBox.Enabled = true;
                animalsnotes_dateDateTimePicker.Enabled = true;
                animalsnotesusers_idComboBox.Enabled = true;

                dataGridView_animalsnotesmain.Enabled = false;

                panel_animalsnotesfilter.Enabled = false;
            }
            else
            {
                if (subediting_mode)
                {
                    button_animalsnotesNew.Enabled = true;
                    button_animalsnotesEdit.Enabled = true;
                    button_animalsnotesDelete.Enabled = true;
                }
                else
                {
                    button_animalsnotesNew.Enabled = false;
                    button_animalsnotesEdit.Enabled = false;
                    button_animalsnotesDelete.Enabled = false;
                }

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = true;

                animalsnotes_notesTextBox.ReadOnly = true;
                animalsnotestypes_idComboBox.Enabled = false;
                animalsnotes_dateDateTimePicker.Enabled = false;
                animalsnotesusers_idComboBox.Enabled = false;

                dataGridView_animalsnotesmain.Enabled = true;

                panel_animalsnotesfilter.Enabled = true;
            }
        }

        private void subviewDataTableanimalsnotesBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            animalsnotes_id = -1;

            animalsnotesBindingSource.Filter = "animalsnotes_id = -1";

            try
            {
                animalsnotes_id = (int)((DataSet01V.subviewDataTableanimalsnotesRow)((DataRowView)subviewDataTableanimalsnotesBindingSource.Current).Row).animalsnotes_id;
            }
            catch { }

            animalsnotes_dateDateTimePicker.Value = DateTime.Now;

            if (animalsnotes_id != -1)
            {
                animalsnotesTableAdapter.Fill(dataSet01S.animalsnotes, animalsnotes_id);

                animalsnotesBindingSource.RemoveFilter();
                animalsnotesBindingSource.Position = animalsnotesBindingSource.Find("animalsnotes_id", animalsnotes_id);
            }
        }

        private void button_animalsnotesNew_Click(object sender, EventArgs e)
        {
            IS_ACTIONSUB = IS_NEW;
            setEditingMode_animalsnotes(true, true);

            animalsnotesBindingSource.AddNew();

            animalsnotes_dateDateTimePicker.Value = DateTime.Now;
        }

        private void button_animalsnotesEdit_Click(object sender, EventArgs e)
        {
            if (animalsnotes_id != -1)
            {
                IS_ACTIONSUB = IS_EDIT;
                setEditingMode_animalsnotes(true, true);
            }
        }

        private void button_animalsnotesDelete_Click(object sender, EventArgs e)
        {
            if (animalsnotes_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    animalsnotesBindingSource.RemoveCurrent();
                    animalsnotesTableAdapter.Update(dataSet01S.animalsnotes);
                    dataSet01S.animalsnotes.AcceptChanges();

                    subviewDataTableanimalsnotesTableAdapter.Fill(dataSet01V.subviewDataTableanimalsnotes, animals_id);
                }
            }
        }

        private bool validateUpdate_animalsnotes(ref string valid_s)
        {
            bool valid_b = true;

            if (animalsnotesusers_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a user" + Environment.NewLine;
            }
            if (animalsnotestypes_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a type" + Environment.NewLine;
            }
            if (animalsnotes_notesTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid note" + Environment.NewLine;
            }
            return valid_b;
        }

        private void animalsnotes_Save()
        {
            string valid_s = string.Empty;
            if (!validateUpdate_animalsnotes(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }

            ((DataSet01S.animalsnotesRow)((DataRowView)animalsnotesBindingSource.Current).Row).animals_id = animals_id;

            animalsnotesBindingSource.EndEdit();
            animalsnotesTableAdapter.Update(dataSet01S.animalsnotes);
            dataSet01S.animalsnotes.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTIONSUB)
            {
                case IS_NEW:
                    sel_id = animalsnotesTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = animalsnotes_id;
                    break;
            }

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_animalsnotes(false, true);

            subviewDataTableanimalsnotesTableAdapter.Fill(dataSet01V.subviewDataTableanimalsnotes, animals_id);
            subviewDataTableanimalsnotesBindingSource.Position = subviewDataTableanimalsnotesBindingSource.Find("animalsnotes_id", sel_id);
        }

        private void animalsnotes_Undo()
        {
            animalsnotesBindingSource.CancelEdit();
            dataSet01S.animalsnotes.RejectChanges();

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_animalsnotes(false, true);
        }

        private void setFilter_animalsnotes()
        {
            try
            {
                string filter_s = string.Empty;
                if (comboBox_animalsnotesfilter_animalsnotestypes_id.SelectedIndex != -1 && comboBox_animalsnotesfilter_animalsnotestypes_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "animalsnotestypes_id = '" + Convert.ToInt32(((CLItemA)comboBox_animalsnotesfilter_animalsnotestypes_id.SelectedItem).id) + "'";
                }

                subviewDataTableanimalsnotesBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void comboBox_animalsnotesfilter_animalsnotestypes_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            setFilter_animalsnotes();
        }


        #endregion


        #region animalstreatments

        private void setEditingMode_animalstreatments(bool editing_mode, bool subediting_mode)
        {
            if (editing_mode)
            {
                button_animalstreatmentsNew.Enabled = false;
                button_animalstreatmentsEdit.Enabled = false;
                button_animalstreatmentsDelete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;
                button_Stopedit.Enabled = false;

                groupBox_animalstreatments_fillfromtreatments.Enabled = true;
                groupBox_animalstreatments_fillfromtreatments.Visible = true;
                animalstreatments_expirationadviceCheckBox.Enabled = true;
                checkBox_animalstreatments_expirationdate.Enabled = true;
                animalstreatments_codeTextBox.ReadOnly = false;
                animalstreatments_priceTextBox.ReadOnly = false;
                animalstreatments_descTextBox.ReadOnly = false;
                animalstreatments_notesTextBox.ReadOnly = false;
                animalstreatmentsusers_idComboBox.Enabled = true;
                animalstreatmentspaystatus_idComboBox.Enabled = true;
                animalstreatmentstreatmentscategories_idComboBox.Enabled = true;
                animalstreatments_dateDateTimePicker.Enabled = true;
                animalstreatments_expirationDateTimePicker.Enabled = true;
                animalstreatments_invoiceableCheckBox.Enabled = true;
                                
                dataGridView_animalstreatmentsmain.Enabled = false;

                panel_animalstreatmentsfilter.Enabled = false;
            }
            else
            {
                if (subediting_mode)
                {
                    button_animalstreatmentsNew.Enabled = true;
                    button_animalstreatmentsEdit.Enabled = true;
                    button_animalstreatmentsDelete.Enabled = true;
                }
                else
                {
                    button_animalstreatmentsNew.Enabled = false;
                    button_animalstreatmentsEdit.Enabled = false;
                    button_animalstreatmentsDelete.Enabled = false;
                }

                button_Save.Enabled = false;
                button_Undo.Enabled = false;
                button_Stopedit.Enabled = true;

                groupBox_animalstreatments_fillfromtreatments.Enabled = false;
                groupBox_animalstreatments_fillfromtreatments.Visible = false;
                animalstreatments_expirationadviceCheckBox.Enabled = false;
                checkBox_animalstreatments_expirationdate.Enabled = false;
                animalstreatments_codeTextBox.ReadOnly = true;
                animalstreatments_priceTextBox.ReadOnly = true;
                animalstreatments_descTextBox.ReadOnly = true;
                animalstreatments_notesTextBox.ReadOnly = true;
                animalstreatmentsusers_idComboBox.Enabled = false;
                animalstreatmentspaystatus_idComboBox.Enabled = false;
                animalstreatmentstreatmentscategories_idComboBox.Enabled = false;
                animalstreatments_dateDateTimePicker.Enabled = false;
                animalstreatments_expirationDateTimePicker.Enabled = false;
                animalstreatments_invoiceableCheckBox.Enabled = false;

                dataGridView_animalstreatmentsmain.Enabled = true;

                panel_animalstreatmentsfilter.Enabled = true;
            }
        }

        private void subviewDataTableanimalstreatmentsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            animalstreatments_id = -1;

            animalstreatmentsBindingSource.Filter = "animalstreatments_id = -1";

            try
            {
                animalstreatments_id = (int)((DataSet01V.subviewDataTableanimalstreatmentsRow)((DataRowView)subviewDataTableanimalstreatmentsBindingSource.Current).Row).animalstreatments_id;
            }
            catch { }

            animalstreatments_dateDateTimePicker.Value = DateTime.Now;
            animalstreatments_expirationadviceCheckBox.Checked = false;
            checkBox_animalstreatments_expirationdate.Checked = false;
            checkBox_animalstreatments_expirationdate_CheckedChanged(null, null);
            textBox_animalstreatments_invoicesinfo.Text = "not invoiced";

            if (animalstreatments_id != -1)
            {
                animalstreatmentsTableAdapter.Fill(dataSet01S.animalstreatments, animalstreatments_id);

                animalstreatmentsBindingSource.RemoveFilter();
                animalstreatmentsBindingSource.Position = animalstreatmentsBindingSource.Find("animalstreatments_id", animalstreatments_id);

                string invoicesinfo = "not invoiced";
                if (((DataRowView)animalstreatmentsBindingSource.Current).Row["invoices_id"].ToString().CompareTo(string.Empty) != 0)
                {
                    DataSet01STableAdapters.invoicesTableAdapter t = new DataSet01STableAdapters.invoicesTableAdapter();
                    DataSet01S.invoicesRow r = t.GetData(((DataSet01S.animalstreatmentsRow)((DataRowView)animalstreatmentsBindingSource.Current).Row).invoices_id).First();
                    invoicesinfo = "invoice " + r.invoices_number + " - " + r.invoices_date.ToShortDateString();
                }
                textBox_animalstreatments_invoicesinfo.Text = invoicesinfo;

                if (((DataSet01S.animalstreatmentsRow)((DataRowView)animalstreatmentsBindingSource.Current).Row).animalstreatments_expirationadvice == 1)
                    animalstreatments_expirationadviceCheckBox.Checked = true;
                else
                    animalstreatments_expirationadviceCheckBox.Checked = false;

                if (((DataRowView)animalstreatmentsBindingSource.Current).Row["animalstreatments_expiration"].ToString().CompareTo(string.Empty) == 0)
                    checkBox_animalstreatments_expirationdate.Checked = false;
                else
                    checkBox_animalstreatments_expirationdate.Checked = true;
                checkBox_animalstreatments_expirationdate_CheckedChanged(null, null);
            }
        }

        private void button_animalstreatmentsNew_Click(object sender, EventArgs e)
        {
            IS_ACTIONSUB = IS_NEW;
            setEditingMode_animalstreatments(true, true);

            animalstreatmentsBindingSource.AddNew();

            textBox_animalstreatments_invoicesinfo.Text = "";
            animalstreatments_dateDateTimePicker.Value = DateTime.Now;
            checkBox_animalstreatments_expirationdate.Checked = false;
            checkBox_animalstreatments_expirationdate_CheckedChanged(null, null);
            animalstreatments_invoiceableCheckBox.Checked = false;
            animalstreatments_priceTextBox.Text = "0";
        }

        private void button_animalstreatmentsEdit_Click(object sender, EventArgs e)
        {
            if (animalstreatments_id != -1)
            {
                IS_ACTIONSUB = IS_EDIT;
                setEditingMode_animalstreatments(true, true);
            }
        }

        private void button_animalstreatmentsDelete_Click(object sender, EventArgs e)
        {
            if (animalstreatments_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    animalstreatmentsBindingSource.RemoveCurrent();
                    animalstreatmentsTableAdapter.Update(dataSet01S.animalstreatments);
                    dataSet01S.animalstreatments.AcceptChanges();

                    subviewDataTableanimalstreatmentsTableAdapter.Fill(dataSet01V.subviewDataTableanimalstreatments, animals_id);
                }
            }
        }

        private bool validateUpdate_animalstreatments(ref string valid_s)
        {
            bool valid_b = true;

            if (animalstreatmentsusers_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a user" + Environment.NewLine;
            }
            if (animalstreatmentspaystatus_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a paystatus" + Environment.NewLine;
            }
            if (animalstreatmentstreatmentscategories_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a category" + Environment.NewLine;
            }
            if (animalstreatments_priceTextBox.Text.CompareTo(string.Empty) != 0)
            {
                try
                {
                    decimal d = Convert.ToDecimal(animalstreatments_priceTextBox.Text);
                    if (d < 0)
                    {
                        valid_b = false;
                        valid_s += "invalid price" + Environment.NewLine;
                    }
                }
                catch
                {
                    valid_b = false;
                    valid_s += "invalid price" + Environment.NewLine;
                }
            }
            if (animalstreatments_descTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid description" + Environment.NewLine;
            }

            return valid_b;
        }

        private void animalstreatments_Save()
        {
            string valid_s = string.Empty;
            if (!validateUpdate_animalstreatments(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }

            ((DataSet01S.animalstreatmentsRow)((DataRowView)animalstreatmentsBindingSource.Current).Row).animals_id = animals_id;

            if (!animalstreatments_expirationDateTimePicker.Visible)
            {
                ((DataRowView)animalstreatmentsBindingSource.Current).Row["animalstreatments_expiration"] = DBNull.Value;
                ((DataSet01S.animalstreatmentsRow)((DataRowView)animalstreatmentsBindingSource.Current).Row).animalstreatments_expirationadvice = 0;
            }

            animalstreatmentsBindingSource.EndEdit();
            animalstreatmentsTableAdapter.Update(dataSet01S.animalstreatments);
            dataSet01S.animalstreatments.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTIONSUB)
            {
                case IS_NEW:
                    sel_id = animalstreatmentsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = animalstreatments_id;
                    break;
            }

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_animalstreatments(false, true);

            subviewDataTableanimalstreatmentsTableAdapter.Fill(dataSet01V.subviewDataTableanimalstreatments, animals_id);
            subviewDataTableanimalstreatmentsBindingSource.Position = subviewDataTableanimalstreatmentsBindingSource.Find("animalstreatments_id", sel_id);
        }

        private void animalstreatments_Undo()
        {
            animalstreatmentsBindingSource.CancelEdit();
            dataSet01S.animalstreatments.RejectChanges();

            IS_ACTIONSUB = IS_VIEW;
            setEditingMode_animalstreatments(false, true);
        }

        private void checkBox_animalstreatments_expirationdate_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_animalstreatments_expirationdate.Checked)
            {
                animalstreatments_expirationDateTimePicker.Visible = true;
                animalstreatments_expirationadviceCheckBox.Visible = true;
                if (Program.is_editing_mode && (IS_ACTIONSUB == IS_NEW || IS_ACTIONSUB == IS_EDIT))
                {
                    animalstreatments_expirationDateTimePicker.Value = DateTime.Now;
                    animalstreatments_expirationadviceCheckBox.Checked = false;
                }
            }
            else
            {
                animalstreatments_expirationDateTimePicker.Visible = false;
                animalstreatments_expirationadviceCheckBox.Visible = false;
            }
        }
        
        private void setFilter_animalstreatments()
        {
            try
            {
                string filter_s = string.Empty;
                if (comboBox_animalstreatmentsfilter_treamtentscategories_id.SelectedIndex != -1 && comboBox_animalstreatmentsfilter_treamtentscategories_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "treatmentscategories_id = '" + Convert.ToInt32(((CLItemA)comboBox_animalstreatmentsfilter_treamtentscategories_id.SelectedItem).id) + "'";
                }
                if (textBox_animalstreatmentsfilter_animalstreatments_code.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "animalstreatments_code LIKE '%" + textBox_animalstreatmentsfilter_animalstreatments_code.Text + "%'";
                }
                if (textBox_animalstreatmentsfilter_animalstreatments_date.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "animalstreatments_date = '" + textBox_animalstreatmentsfilter_animalstreatments_date.Text + "'";
                }

                subviewDataTableanimalstreatmentsBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void comboBox_animalstreatmentsfilter_treamtentscategories_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            setFilter_animalstreatments();
        }

        private void textBox_animalstreatmentsfilter_animalstreatments_code_TextChanged(object sender, EventArgs e)
        {
            setFilter_animalstreatments();
        }
        
        private void textBox_animalstreatmentsfilter_animalstreatments_date_TextChanged(object sender, EventArgs e)
        {
            setFilter_animalstreatments();
        }

        private void setFilter_animalstreatmentsfillfromtreatments()
        {
            try
            {
                string filter_s = string.Empty;
                if (textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "treatments_code LIKE '%" + textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code.Text + "%'";
                }
                if (comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex != -1 && comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s +=
                            "treatmentscategories_id = '" + Convert.ToInt32(((CLItemA)comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id.SelectedItem).id) + "'";
                }
                if (textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "treatments_name LIKE '%" + textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name.Text + "%'";
                }

                comboviewDataTabletreatmentsBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_code_TextChanged(object sender, EventArgs e)
        {
            setFilter_animalstreatmentsfillfromtreatments();
        }

        private void comboBox_animalstreatmentsfillfromtreatmentsfilter_treatmentscategories_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            setFilter_animalstreatmentsfillfromtreatments();
        }

        private void textBox_animalstreatmentsfillfromtreatmentsfilter_treatments_name_TextChanged(object sender, EventArgs e)
        {
            setFilter_animalstreatmentsfillfromtreatments();
        }

        private void button_animalstreatmentsfillfromtreatments_Click(object sender, EventArgs e)
        {
            int treatments_id = -1;
            try
            {
                treatments_id = ((DataSet01V.comboviewDataTabletreatmentsRow)((DataRowView)comboviewDataTabletreatmentsBindingSource.Current).Row).treatments_id;
            }
            catch { }

            if (treatments_id != -1)
            {
                DataSet01STableAdapters.treatmentsTableAdapter t = new DataSet01STableAdapters.treatmentsTableAdapter();
                DataSet01S.treatmentsRow r = t.GetData(treatments_id).First();
                if (r["treatments_code"].ToString().CompareTo(string.Empty) != 0)
                {
                    animalstreatments_codeTextBox.Text = r.treatments_code.ToString();
                }
                if (r["treatments_desc"].ToString().CompareTo(string.Empty) != 0)
                {
                    animalstreatments_descTextBox.Text = r.treatments_desc.ToString();
                }
                animalstreatmentstreatmentscategories_idComboBox.SelectedIndex = -1;
                if (r["treatmentscategories_id"].ToString().CompareTo(string.Empty) != 0)
                {
                    foreach (Object item in animalstreatmentstreatmentscategories_idComboBox.Items)
                    {
                        if (((DataSet01V.comboviewDataTabletreatmentscategoriesRow)((DataRowView)item).Row).treatmentscategories_id == r.treatmentscategories_id)
                        {
                            animalstreatmentstreatmentscategories_idComboBox.SelectedItem = item;
                            break;
                        }
                    }
                }
                if (r["treatments_price"].ToString().CompareTo(string.Empty) != 0)
                {
                    if (r.treatments_price > 0)
                    {
                        animalstreatmentspaystatus_idComboBox.SelectedIndex = 1;
                        animalstreatments_priceTextBox.Text = r.treatments_price.ToString();
                    }
                }
                if (r["treatments_duration"].ToString().CompareTo(string.Empty) != 0)
                {
                    if (r.treatments_duration != 0)
                    {
                        checkBox_animalstreatments_expirationdate.Checked = true;
                        animalstreatments_expirationDateTimePicker.Value = DateTime.Now.AddMonths(r.treatments_duration);
                    }
                }              
            }
        }

        private void animalstreatmentspaystatus_idComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (IS_ACTIONSUB == IS_NEW || IS_ACTIONSUB == IS_EDIT)
            {
                if (((DataSet01V.comboviewDataTablepaystatusRow)((DataRowView)animalstreatmentspaystatus_idComboBox.SelectedItem).Row).paystatus_id == 1)
                {
                    animalstreatments_invoiceableCheckBox.Checked = false;
                    animalstreatments_invoiceableCheckBox.Enabled = false;
                }
                else
                {
                    animalstreatments_invoiceableCheckBox.Enabled = true;
                    animalstreatments_invoiceableCheckBox.Checked = true;
                }
            }  
        }

        private void animalstreatments_priceTextBox_Leave(object sender, EventArgs e)
        {
            if (!animalstreatments_priceTextBox.ReadOnly)
            {
                try
                {
                    Convert.ToDecimal(animalstreatments_priceTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("must be a numeric decimal value");
                }
            }
        }

        #endregion
        
    }

}
