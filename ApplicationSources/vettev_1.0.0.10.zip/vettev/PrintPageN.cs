﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using iTextSharp.text.pdf;
using iTextSharp.text;

namespace vettev
{
    public class PrintPageN : iTextSharp.text.pdf.PdfPageEventHelper
    {
        public override void OnOpenDocument(PdfWriter writer, Document document)
        {
        }

        public override void OnStartPage(PdfWriter writer, Document document)
        {
        }

        public override void OnEndPage(PdfWriter writer, Document document)
        {
            try
            {
                PdfContentByte contentunder = writer.DirectContentUnder;
                contentunder.SetRGBColorFill(100, 100, 100);

                base.OnEndPage(writer, document);

                contentunder.BeginText();
                contentunder.SetFontAndSize(BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 8);
                contentunder.SetTextMatrix(document.PageSize.GetLeft(40), document.PageSize.GetBottom(30));
                contentunder.ShowText("Page " + writer.PageNumber);
                contentunder.EndText();
            }
            catch { }
        }

        public override void OnCloseDocument(PdfWriter writer, Document document)
        {
        }
    }
}
