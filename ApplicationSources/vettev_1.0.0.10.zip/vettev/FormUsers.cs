﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace vettev
{
    public partial class FormUsers : Form
    {
        int users_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormUsers()
        {
            InitializeComponent();
        }

        private void FormUsers_Load(object sender, EventArgs e)
        {
            this.viewDataTableusersTableAdapter.Fill(this.dataSet01V.viewDataTableusers);

            viewDataTableusersBindingSource.Sort = "users_alias";

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTableusersBindingSource_CurrentChanged(null, null);
        }

        private void FormUsers_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormUsers_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormUsers_Load(sender, e);
        }

        private void FormUsers_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                users_aliasTextBox.ReadOnly = false;
                users_nameTextBox.ReadOnly = false;
                users_surnameTextBox.ReadOnly = false;
                users_stateTextBox.ReadOnly = false;
                users_cityTextBox.ReadOnly = false;
                users_zipcodeTextBox.ReadOnly = false;
                users_streetTextBox.ReadOnly = false;
                users_vatnumberTextBox.ReadOnly = false;
                users_taxcodeTextBox.ReadOnly = false;
                users_telTextBox.ReadOnly = false;
                users_faxTextBox.ReadOnly = false;
                users_emailTextBox.ReadOnly = false;
                users_websiteTextBox.ReadOnly = false;
                users_notesTextBox.ReadOnly = false;
                users_invoicestextTextBox.ReadOnly = false;

                dataGridView_main.Enabled = false;

                panel_filter.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                users_aliasTextBox.ReadOnly = true;
                users_nameTextBox.ReadOnly = true;
                users_surnameTextBox.ReadOnly = true;
                users_stateTextBox.ReadOnly = true;
                users_cityTextBox.ReadOnly = true;
                users_zipcodeTextBox.ReadOnly = true;
                users_streetTextBox.ReadOnly = true;
                users_vatnumberTextBox.ReadOnly = true;
                users_taxcodeTextBox.ReadOnly = true;
                users_telTextBox.ReadOnly = true;
                users_faxTextBox.ReadOnly = true;
                users_emailTextBox.ReadOnly = true;
                users_websiteTextBox.ReadOnly = true;
                users_notesTextBox.ReadOnly = true;
                users_invoicestextTextBox.ReadOnly = true;

                dataGridView_main.Enabled = true;

                panel_filter.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            usersBindingSource.AddNew();
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (users_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (users_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    bool candelete = true;
                    string candeletetxt = "";
                    
                    {
                        DataSet01STableAdapters.invoicesTableAdapter t = new DataSet01STableAdapters.invoicesTableAdapter();
                        if (t.GetDataBy6(users_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "invoices" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    {
                        DataSet01STableAdapters.estimatesTableAdapter t = new DataSet01STableAdapters.estimatesTableAdapter();
                        if (t.GetDataBy6(users_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "estimates" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    {
                        DataSet01STableAdapters.animalstreatmentsTableAdapter t = new DataSet01STableAdapters.animalstreatmentsTableAdapter();
                        if (t.GetDataBy4(users_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "animalstreatments" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    {
                        DataSet01STableAdapters.animalsnotesTableAdapter t = new DataSet01STableAdapters.animalsnotesTableAdapter();
                        if (t.GetDataBy3(users_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "animalsnotes" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    if (!candelete)
                    {
                        MessageBox.Show(candeletetxt);
                        return;
                    }

                    {
                        DataSet01STableAdapters.calendarsTableAdapter t = new DataSet01STableAdapters.calendarsTableAdapter();
                        DataSet01S.calendarsDataTable d = t.GetDataBy2(users_id);
                        foreach (DataSet01S.calendarsRow r in d.Select())
                        {
                            r.Delete();
                        }
                        t.Update(d);
                    }

                    usersBindingSource.RemoveCurrent();
                    usersTableAdapter.Update(dataSet01S.users);
                    dataSet01S.users.AcceptChanges();

                    viewDataTableusersTableAdapter.Fill(dataSet01V.viewDataTableusers);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            if (users_aliasTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid alias" + Environment.NewLine;
            }
            if (users_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            if (users_surnameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid surname" + Environment.NewLine;
            }
            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            usersBindingSource.EndEdit();
            usersTableAdapter.Update(dataSet01S.users);
            dataSet01S.users.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = usersTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = users_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTableusersTableAdapter.Fill(dataSet01V.viewDataTableusers);
            viewDataTableusersBindingSource.Position = viewDataTableusersBindingSource.Find("users_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            usersBindingSource.CancelEdit();
            dataSet01S.families.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTableusersBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            users_id = -1;

            usersBindingSource.Filter = "users_id = -1";

            try
            {
                users_id = (int)((DataSet01V.viewDataTableusersRow)((DataRowView)viewDataTableusersBindingSource.Current).Row).users_id;
            }
            catch { }

            if (users_id != -1)
            {
                usersTableAdapter.Fill(dataSet01S.users, users_id);

                usersBindingSource.RemoveFilter();
                usersBindingSource.Position = usersBindingSource.Find("users_id", users_id);
            }
        }

        private void setFilter()
        {
            try
            {
                string filter_s = string.Empty;
                if (textBox_filter_users.Text.CompareTo(string.Empty) != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    int search_id = 0;
                    try
                    {
                        int.TryParse(textBox_filter_users.Text, out search_id);
                    }
                    catch { }
                    if(search_id != 0)
                        filter_s += "users_id = '" + textBox_filter_users.Text + "'";
                    else
                        filter_s +=
                            "(users_alias LIKE '%" + textBox_filter_users.Text + "%' OR "+
                            "users_name LIKE '%" + textBox_filter_users.Text + "%' OR " +
                            "users_surname LIKE '%" + textBox_filter_users.Text + "%')";
                }

                viewDataTableusersBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void textBox_filter_users_TextChanged(object sender, EventArgs e)
        {
            setFilter();
        }
    }
}
