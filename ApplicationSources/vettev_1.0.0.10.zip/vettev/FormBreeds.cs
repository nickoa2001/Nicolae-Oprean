﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace vettev
{
    public partial class FormBreeds : Form
    {
        int breeds_id = -1;

        private static int IS_ACTION = 0;
        private const int IS_VIEW = 1;
        private const int IS_NEW = 2;
        private const int IS_EDIT = 3;
        private const int IS_DELETE = 4;

        private static int loading = 1;

        public FormBreeds()
        {
            InitializeComponent();
        }

        private void FormBreeds_Load(object sender, EventArgs e)
        {
            this.comboviewDataTablefamiliesTableAdapter.Fill(this.dataSet01V.comboviewDataTablefamilies);

            this.viewDataTablebreedsTableAdapter.Fill(this.dataSet01V.viewDataTablebreeds);

            viewDataTablebreedsBindingSource.Sort = "families_name, breeds_name";

            this.comboviewDataTablefamiliesTableAdapter.Fill(this.dataSet01V.comboviewDataTablefamilies);
            comboBox_filter_families_id.Items.Clear();
            comboBox_filter_families_id.Items.Add(new CLItemA("0", ""));
            foreach (DataSet01V.comboviewDataTablefamiliesRow r in dataSet01V.comboviewDataTablefamilies.Select("", "families_name"))
            {
                comboBox_filter_families_id.Items.Add(new CLItemA(r.families_id.ToString(), r.families_name.ToString()));
            }
            comboBox_filter_families_id.SelectedIndex = 0;

            comboBox_filter_families_id_SelectedIndexChanged(null, null);

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            loading = 0;
            viewDataTablebreedsBindingSource_CurrentChanged(null, null);
        }

        private void FormBreeds_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.is_editing_mode)
                e.Cancel = true;
        }

        private void FormBreeds_Activated(object sender, EventArgs e)
        {
            if (loading == 0)
                return;

            FormBreeds_Load(sender, e);
        }
        
        private void FormBreeds_Deactivate(object sender, EventArgs e)
        {
            loading = 1;
        }

        private void setEditingMode(bool editing_mode)
        {
            if (editing_mode)
            {
                Program.is_editing_mode = true;

                button_New.Enabled = false;
                button_Edit.Enabled = false;
                button_Delete.Enabled = false;

                button_Save.Enabled = true;
                button_Undo.Enabled = true;

                breeds_nameTextBox.ReadOnly = false;
                families_idComboBox.Enabled = true;

                dataGridView_main.Enabled = false;

                panel_filter.Enabled = false;
            }
            else
            {
                Program.is_editing_mode = false;

                button_New.Enabled = true;
                button_Edit.Enabled = true;
                button_Delete.Enabled = true;

                button_Save.Enabled = false;
                button_Undo.Enabled = false;

                breeds_nameTextBox.ReadOnly = true;
                families_idComboBox.Enabled = false;

                dataGridView_main.Enabled = true;

                panel_filter.Enabled = true;
            }
        }

        private void button_New_Click(object sender, EventArgs e)
        {
            IS_ACTION = IS_NEW;
            setEditingMode(true);

            breedsBindingSource.AddNew();

            if(comboBox_filter_families_id.SelectedIndex != -1 && comboBox_filter_families_id.SelectedIndex != 0)
                families_idComboBox.SelectedValue = Convert.ToInt32(((CLItemA)comboBox_filter_families_id.SelectedItem).id);
        }

        private void button_Edit_Click(object sender, EventArgs e)
        {
            if (breeds_id != -1)
            {
                IS_ACTION = IS_EDIT;
                setEditingMode(true);
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            if (breeds_id != -1)
            {
                if (MessageBox.Show("Do you really want to delete this item?", "Deleting", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                {
                    bool candelete = true;
                    string candeletetxt = "";

                    {
                        DataSet01STableAdapters.animalsTableAdapter t = new DataSet01STableAdapters.animalsTableAdapter();
                        if (t.GetDataBy1(breeds_id).Count() > 0)
                        {
                            candeletetxt += "Can not delete this item. Some records of " + "animals" + " are binded to this" + Environment.NewLine;
                            candelete = false;
                        }
                    }

                    if (!candelete)
                    {
                        MessageBox.Show(candeletetxt);
                        return;
                    }

                    breedsBindingSource.RemoveCurrent();
                    breedsTableAdapter.Update(dataSet01S.breeds);
                    dataSet01S.breeds.AcceptChanges();

                    comboBox_filter_families_id_SelectedIndexChanged(null, null);
                }
            }
        }

        private bool validateUpdate(ref string valid_s)
        {
            bool valid_b = true;

            
            if (families_idComboBox.SelectedIndex == -1)
            {
                valid_b = false;
                valid_s += "select a family" + Environment.NewLine;
                return valid_b;
            }
            if (breeds_nameTextBox.Text.CompareTo(string.Empty) == 0)
            {
                valid_b = false;
                valid_s += "invalid name" + Environment.NewLine;
            }
            else
            {
                DataSet01STableAdapters.breedsTableAdapter t = new DataSet01STableAdapters.breedsTableAdapter();
                if (t.GetDataBy2(breeds_nameTextBox.Text).Select("families_id = " + ((DataSet01V.comboviewDataTablefamiliesRow)((DataRowView)families_idComboBox.SelectedItem).Row).families_id).Count() > 0 && IS_ACTION == IS_NEW)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
                if (t.GetDataBy2(breeds_nameTextBox.Text).Select("families_id = " + ((DataSet01V.comboviewDataTablefamiliesRow)((DataRowView)families_idComboBox.SelectedItem).Row).families_id + " AND breeds_id <> " + breeds_id).Count() > 0 && IS_ACTION == IS_EDIT)
                {
                    valid_b = false;
                    valid_s += "name already exists" + Environment.NewLine;
                }
            }

            return valid_b;
        }

        private void button_Save_Click(object sender, EventArgs e)
        {
            string valid_s = string.Empty;
            if (!validateUpdate(ref valid_s))
            {
                MessageBox.Show(valid_s);
                return;
            }
            breedsBindingSource.EndEdit();
            breedsTableAdapter.Update(dataSet01S.breeds);
            dataSet01S.breeds.AcceptChanges();

            int sel_id = -1;
            switch (IS_ACTION)
            {
                case IS_NEW:
                    sel_id = breedsTableAdapter.ScalarQuery().Value;
                    break;
                case IS_EDIT:
                    sel_id = breeds_id;
                    break;
            }

            IS_ACTION = IS_VIEW;
            setEditingMode(false);

            viewDataTablebreedsTableAdapter.Fill(dataSet01V.viewDataTablebreeds);
            viewDataTablebreedsBindingSource.Position = viewDataTablebreedsBindingSource.Find("breeds_id", sel_id);
        }

        private void button_Undo_Click(object sender, EventArgs e)
        {
            breedsBindingSource.CancelEdit();
            dataSet01S.breeds.RejectChanges();

            IS_ACTION = IS_VIEW;
            setEditingMode(false);
        }

        private void viewDataTablebreedsBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (loading == 1)
                return;

            breeds_id = -1;

            breedsBindingSource.Filter = "breeds_id = -1";

            try
            {
                breeds_id = (int)((DataSet01V.viewDataTablebreedsRow)((DataRowView)viewDataTablebreedsBindingSource.Current).Row).breeds_id;
            }
            catch { }

            families_idComboBox.SelectedIndex = -1;

            if (breeds_id != -1)
            {
                breedsTableAdapter.Fill(dataSet01S.breeds, breeds_id);
            
                breedsBindingSource.RemoveFilter();
                breedsBindingSource.Position = breedsBindingSource.Find("breeds_id", breeds_id);
            }
        }

        private void setFilter()
        {
            try
            {
                string filter_s = string.Empty;
                if (comboBox_filter_families_id.SelectedIndex != -1 && comboBox_filter_families_id.SelectedIndex != 0)
                {
                    if (filter_s.CompareTo(string.Empty) != 0)
                        filter_s += " AND ";
                    filter_s += "families_id = '" + Convert.ToInt32(((CLItemA)comboBox_filter_families_id.SelectedItem).id) + "'";
                }

                viewDataTablebreedsBindingSource.Filter = filter_s;
            }
            catch { }
        }

        private void comboBox_filter_families_id_SelectedIndexChanged(object sender, EventArgs e)
        {
            setFilter();
        }
    }
}
